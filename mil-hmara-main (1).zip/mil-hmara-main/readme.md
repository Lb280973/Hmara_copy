# Introduction

This platform is built for staff management in a battalion. Main features:

- Track trips, vacations, sick-leaves and other events, related to staff.
- Track staff's positions and their changes. If you follow the daily changes based on orders, you will have the actual
  staff structure on a daily basis.
- Register reports and track their status, find specific report by its number, person, unit, etc.
- Generate documents based on the data in the system. For example, you can generate a trip or vacation tickets, signout
  ticket, order extract etc.
- Get report of currently departed or arrived staff by day. This report is used to edit a daily order.

# Installation

# 1. Setup environment variables

Make sure you have your environment variables set. You can see an example in `.env_example` file.

```
DB_NAME=
DB_USER=
DB_PASSWORD=
DB_HOST=host.docker.internal
DB_PORT=
SECRET_KEY=
DOCUMENTS_DIR=
```

`DB_HOST` is set to `host.docker.internal` because the platform is running in a docker container and this is the way to
make it connect to database, that is spinning up on the localhost.

`SECRET_KEY` is used for signing sessions and other internal Django stuff. You can generate it
with `openssl rand -base64 32`.

`DOCUMENTS_DIR` is the path to the directory where the documents will be stored. Better if we mount it as a
volume (https://docs.docker.com/storage/bind-mounts/).

docker run -p 8000:8000 --name uaf -v c:\uaf:/home/vol1 --rm --env-file uaf.env uaf

# 2. Setup the database We use PostgreSQL as a database. You can install it locally or use docker-compose to spin it up.

Make sure you have database name, user and password set in the environment variables and it matches the ones you create,
when setting up the database.

# 3. Build an image and run migrations.

Once you have the database set up, you can build the image and run migrations. There's a script for that: `./build.sh`.
It should do everything automatically, but here's a little breakdown of what it does:

- Build the image with name `uaf` from the Dockerfile in the current directory (that `.` in the end):

  `docker build -t uaf . `

- Run a named container from that image, called `uaf`:

  `docker run --rm --name uaf --env-file .env -d uaf`

    - `--rm` flag removes a container after it stops
    - `--name` flag names a container (same as image name in this case, but could be any name)
    - `--env-file` flag loads environment variables from a file
    - `-d` flag runs a container in detached mode (in the background)

- Run migrations:

  `docker exec -it uaf python manage.py migrate --noinput`

# 4. Run the server

`docker run -p 8000:8000 --name uaf --rm --env-file .env uaf`

# 5. You are all set.

The platform is now running on `127.0.0.1:8000`.

# Additional info:

1. Logging into a container

If you need to log into the container, you can do it with `docker exec -it uaf bash`.

2. Migrations

If you need to run a command inside the container, you can do it with `docker exec -it uaf <command>`. 
Django has two main commands related to the database migrations: `makemigrations` and `migrate`.
`makemigrations` creates a migration file, that you can then commit to the repository.
`migrate` runs the migrations. So, if you changed the models in models.py (each model represents a table in the
database), you need to run `makemigrations`. Then, you need to commit the migration file to the repository and
run `migrate` on the server.
`docker exec -it uaf python manage.py makemigrations`
`docker exec -it uaf python manage.py migrate`

3. Creating a superuser

If you need to create a superuser, you can do it with `docker exec -it uaf python manage.py createsuperuser`.

4. Changing templates

For now, we are using Jinja2 as a template engine. You can find the templates in `doc_templates` directory. Main templates
that you probably will change are `trip_template.docx`, `vacation_template.docx`,
`signout_template.docx` and `extract_template.docx`.

5. Adding new libraries to the project

To install new library (faker, for example) on the dev environment run:
`pip install faker`
And you can add corresponding line to the `requirements.txt` for docker container:
`faker==19.1.0`

<sub>
Made with love for Ukrainian people and hatred for russian occupiers
by corporal Ian Sokolskyi
</sub>