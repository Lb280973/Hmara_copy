#!/usr/bin/ bash
#docker run -p 8000:8000 --name uaf --rm --env-file uaf.env uaf
docker run -p 80:8000 --name uaf -v d:\uaf\docs:/home/docs --rm --env-file uaf.env uaf