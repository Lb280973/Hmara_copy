from django.contrib import admin
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import path, re_path, include

from documents.views import media


def favicon(request):
    with open('static/favicon.ico', 'rb') as f:
        return HttpResponse(f.read(), content_type='image/x-icon')


def robots(request):
    return HttpResponse("User-agent: *\nDisallow: /", content_type="text/plain")


def home_redirect(request):
    return HttpResponseRedirect('/admin/')


urlpatterns = [
    path('', home_redirect),
    path('favicon.ico', favicon),
    path('robots.txt', robots),
    path('admin/', admin.site.urls),
    path('documents/', include('documents.urls')),
    path('personnel/', include('personnel.urls')),
    re_path(r'^docs/(?P<file_path>.+)+', media, name='media'),
]
