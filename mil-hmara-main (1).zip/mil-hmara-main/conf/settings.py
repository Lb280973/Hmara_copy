import datetime
import locale
import os
from pathlib import Path

from django.utils.log import DEFAULT_LOGGING
from django.utils.translation import gettext_lazy as _
from environs import Env


# declare env for fetching config variables from environment
env = Env()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

# to add extra allowed hosts set environment variable ALLOWED_HOSTS
# export ALLOWED_HOSTS="hmara.local 0.0.0.0 hmara.mil.local"
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']
if os.environ.get("ALLOWED_HOSTS") is not None:
    for i in os.environ.get("ALLOWED_HOSTS").split(" "):
        ALLOWED_HOSTS.append(i)

print("ALLOWED HOSTS: " + ', '.join(ALLOWED_HOSTS))


LANGUAGE_CODE = 'uk'  # or other appropriate code
locale.setlocale(locale.LC_ALL, 'uk_UA.UTF-8')

LANGUAGES = [
    ('uk', _('Ukrainian'))
]
LOCALE_PATHS = [os.path.join(BASE_DIR, 'locale')]

USE_I18N = True
USE_L10N = False

env.read_env(path=os.path.join(BASE_DIR, 'uaf.env'))

DATA_UPLOAD_MAX_NUMBER_FIELDS = None
DOCUMENTS_DIR = env('DOCUMENTS_DIR')
SECRET_KEY = env('SECRET_KEY')

# print('env.path: '+env.path())
print('DOCUMENTS_DIR: '+DOCUMENTS_DIR)

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # apps
    'system',
    'personnel',
    'weapon',
    'documents',

    # third-party
    'django_extensions',
    'admin_auto_filters',
    'import_export',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',

]

ROOT_URLCONF = 'conf.urls'

MEDIA_ROOT = 'docs'
MEDIA_URL = 'docs/'
STATIC_ROOT = 'static'
STATIC_URL = 'static/'
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates']
        ,
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                # 'django.template.context_processors.media',
            ],
        },
    },
]

WSGI_APPLICATION = 'conf.wsgi.application'

# Database
# https://docs.djangoproject.com/en/4.0/ref/settings/#databases
print('DB_USER: ' + env('DB_USER'))
# print('DB_PASSWORD: ' + env('DB_PASSWORD'))
print('DB_NAME: ' + env('DB_NAME'))

DATABASES = {
    'default': {
        # 'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': env('DB_NAME'),
        'USER': env('DB_USER'),
        'PASSWORD': env('DB_PASSWORD'),
        'HOST': env('DB_HOST'),
        'PORT': '5432',
    }
}

# Password validation
# https://docs.djangoproject.com/en/4.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/4.0/topics/i18n/


TIME_ZONE = 'Europe/Kiev'

USE_TZ = True
DATE_FORMAT = "d.m.Y"
DATE_INPUT_FORMATS = ['%d.%m.%Y']

PAGE_SIZE = 20

LOGS_DIR = os.path.join(BASE_DIR, 'logs')
LOG_FILENAME = f'hmara_{datetime.date.today()}.log'
LOG_FULLNAME = os.path.join(LOGS_DIR, LOG_FILENAME)
print("LOGS: " + LOG_FULLNAME)
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {
            # exact format is not important, this is the minimum information
            'format': '[%(asctime)s] [%(name)-12s][%(funcName)s][%(levelname)-8s] %(message)s',
        },
        'django.server': DEFAULT_LOGGING['formatters']['django.server'],
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'default',
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': LOG_FULLNAME,
            'maxBytes': 1024 * 1024 * 5,  # 5 MB
            'backupCount': 5,
            'formatter': 'default',
        },

    },
    'root': {
        'handlers': ['console', 'file'],
        'level': 'INFO',
    },
}

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.0/howto/static-files/


# Default primary key field type
# https://docs.djangoproject.com/en/4.0/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
