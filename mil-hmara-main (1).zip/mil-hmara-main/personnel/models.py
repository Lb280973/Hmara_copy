import enum
import re
from datetime import datetime
from datetime import date

import django
from dateutil.relativedelta import relativedelta
from django.contrib import admin
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Count, Q
from django.urls import reverse
from django.utils.html import format_html
from django.forms import ModelChoiceField

from django.utils.translation import gettext_lazy as _
from javascript import require

from documents.models import Arrest, Vacation, Trip, Hospitalization
from personnel.views import get_staff_position_status, get_staff_position_color
from utils.docfiles import get_globals
from utils.helpers import get_verbose_date, get_month_duration, amount_to_words, get_fractional_part_as_text, \
    get_integer_part_as_text, int_amount_to_words, get_short_date


def get_serviceman_combat_mission_periods(sm):
    qs = MissionParticipant.objects.filter(serviceman=sm).order_by('start_date')
    qty = len(qs)
    result = ''
    for i, item in enumerate(qs):
        result += f'з {get_short_date(item.start_date)} ' \
                   f'по {get_short_date(item.end_date) if item.end_date else "??.??.????"}' \
                   f'{", " if i+1<qty else ""}'
    return result

def get_serviceman_combat_mission_places(sm):
    result = ''
    # qs = sm.mission_serviceman.all()
    qs = MissionParticipant.objects.filter(serviceman=sm).order_by('start_date')
    qty = len(qs)
    for i, item in enumerate(qs):
        result += f'{item.mission.place}' \
                  f'{", " if i + 1 < qty else ""}'
    return result

def get_serviceman_combat_mission_reasons(sm):
    result = ''
    # qs = sm.mission_serviceman.all()
    qs = MissionParticipant.objects.filter(serviceman=sm).order_by('start_date')
    qty = len(qs)
    for i, item in enumerate(qs):
        result += f'{item.mission.reason}' \
                  f'{", " if i + 1 < qty else ""}'
    return result


class Serviceman(models.Model):
    class Sex(models.TextChoices):
        MALE = '1', 'Чоловік'
        FEMALE = '2', 'Жінка'
    class BloodType(models.TextChoices):
        R1P = '0+', '0(I) Rh(+)'
        R1M = '0-', '0(I) Rh(-)'
        R2P = 'A+', 'A(II) Rh(+)'
        R2M = 'A-', 'A(II) Rh(-)'
        R3P = 'B+', 'B(III) Rh(+)'
        R3M = 'B-', 'B(III) Rh(-)'
        R4P = 'AB+', 'AB(IV) Rh(+)'
        R4M = 'AB-', 'AB(IV) Rh(-)'
    class MaritalStatus(models.TextChoices):
        UNMARRIED = 'UNM', 'неодружений'
        MARRIED = 'MAR', 'одружений'
        DIVORCED = 'DIV', 'розлучений'
        WIDOWER = 'WID', 'вдівець'
    class ServiceType(models.TextChoices):
        CONTRACTED = 'CNT', 'За контрактом'
        MOBILIZED = 'MOB', 'За мобілізацією'
        CONSCRIPT = 'CNS', 'Строкова'
    class MedicalRestrictions(models.TextChoices):
        SUITABLE = 'SUI', 'Придатний'
        PARTIALLY = 'PAR', 'Обмежено придатний'
        UNSUITABLE = 'UNS', 'Непридатний'

    class Meta:
        verbose_name_plural = 'військовослужбовці'
        verbose_name = 'військовослужбовець'
        ordering = ['last_name', 'first_name', 'second_name']

    serviceman_id = models.IntegerField(blank=True, null=True, verbose_name='№ з/п')
    acceptance_order = models.ForeignKey('documents.Order', verbose_name='Наказ про зарахування',
                                         related_name='sm_acceptance_order', on_delete=models.PROTECT,
                                         blank=True, null=True, limit_choices_to={'order_type': 1})
    rank = models.ForeignKey('Rank', on_delete=models.SET_NULL, null=True, verbose_name='звання')
    rank_order = models.ForeignKey('documents.Order', verbose_name='Наказ про присвоєння', related_name='sm_rank_order',
                                   on_delete=models.SET_NULL, blank=True, null=True, limit_choices_to={'order_type': 3})
    rank_order_ext = models.CharField(max_length=200, blank=True, null=True, verbose_name='Наказ про присвоєння (інша в/ч)')
    rank_order_ext_date = models.DateField(blank=True, null=True, verbose_name='Дата присвоєння (інша в/ч)')
    service_type = models.CharField(max_length=3, verbose_name='Вид служби', choices=ServiceType.choices,
                                    default=ServiceType.MOBILIZED)
    medical_restrictions = models.CharField(max_length=3, verbose_name='Придатність',
                                            choices=MedicalRestrictions.choices,
                                            default=MedicalRestrictions.SUITABLE)
    military_oath_date = models.DateField(blank=True, null=True, verbose_name='Дата присяги')
    service_term_start_date = models.DateField(blank=True, null=True, verbose_name='Розрахунок вислуги з дати')
    service_term_years = models.PositiveIntegerField(blank=True, null=True, verbose_name='Вислуга (роки)')
    service_term_months = models.PositiveIntegerField(blank=True, null=True, verbose_name='Вислуга (місяці)')
    service_term_days = models.PositiveIntegerField(blank=True, null=True, verbose_name='Вислуга (дні)')
    service_term_text = models.TextField(blank=True, null=True, verbose_name='Вислуга років (повністю)')
    service_periods = models.TextField(blank=True, null=True, verbose_name='Періоди служби')
    last_name = models.CharField(max_length=32, verbose_name='прізвище')
    first_name = models.CharField(max_length=32, verbose_name="ім'я")
    second_name = models.CharField(max_length=32, blank=True, verbose_name='по-батькові')
    callsign = models.CharField(max_length=32, blank=True, null=True, verbose_name='позивний')
    phone_number = models.CharField(max_length=32, blank=True, null=True, verbose_name='номер телефону')
    tax_id = models.PositiveBigIntegerField(unique=True, verbose_name='ІПН', blank=True, null=True)
    date_of_birth = models.DateField(null=True, verbose_name='дата народження', blank=True)
    birthplace = models.CharField(max_length=200, blank=True, null=True, verbose_name='місце народження')
    sex = models.CharField(max_length=1, verbose_name='стать', choices=Sex.choices, default=Sex.MALE)
    blood_type = models.CharField(max_length=3, verbose_name='група крові', choices=BloodType.choices,
                                  blank=True, null=True)
    location = models.ForeignKey('Location', blank=True, null=True, related_name='serviceman_location',
                                 on_delete=models.SET_NULL, verbose_name='локація')
    excluded = models.BooleanField(default=False, verbose_name='виключений')
    dismissal_date = models.DateField(blank=True, null=True, verbose_name='дата виключення')
    dismissal_order = models.ForeignKey('documents.Order', verbose_name='Наказ про виключення',
                                        related_name='sm_dismissal_order', on_delete=models.SET_NULL,
                                        blank=True, null=True)
    marital_status = models.CharField(max_length=3, verbose_name='сімейний стан', choices=MaritalStatus.choices,
                                      blank=True, null=True)
    passport = models.CharField(max_length=32, blank=True, null=True, verbose_name='паспорт')
    military_id = models.CharField(max_length=32, blank=True, null=True, verbose_name='військовий квиток')
    home_address = models.CharField(max_length=200, blank=True, null=True, verbose_name='Адреса')
    commissariat = models.CharField(max_length=200, blank=True, null=True, verbose_name='військомат')
    education = models.TextField(blank=True, null=True, verbose_name='освіта')
    relatives = models.TextField(blank=True, null=True, verbose_name='родичі')
    comment = models.TextField(blank=True, null=True, verbose_name='коментар')
    file = models.FileField(upload_to='Serviceman', blank=True, null=True, verbose_name='файл')
    file2 = models.FileField(upload_to='Serviceman', blank=True, null=True, verbose_name='файл (2)')

    def __str__(self):
        return f'{self.full_name_upper}, {self.rank}{" [ВИКЛЮЧЕНИЙ]" if self.excluded else ""}'

    @property
    def full_name(self):
        return f'{self.last_name.capitalize()} {self.first_name} {self.second_name}'.strip()

    full_name.fget.short_description = 'ПІБ'

    @property
    def full_name_upper(self):
        return f'{self.last_name.upper()} {self.first_name} {self.second_name}'.strip()

    full_name_upper.fget.short_description = 'ПІБ'

    @property
    def print_name(self):
        return f'{self.first_name} {self.last_name.upper()}'.strip()

    print_name.fget.short_description = 'ПІБ'

    @property
    def initials(self):
        return f'{self.first_name[:1]}.{self.second_name[:1]+"." if self.second_name else ""}'

    @property
    def short_name(self):
        return f'{self.last_name.capitalize()} {self.initials}'
    short_name.fget.short_description = 'ПІБ (скорочено)'

    @property
    def short_name_upper(self):
        return f'{self.last_name.upper()} {self.initials}'

    @property
    def title(self):
        return f'{self.rank.__str__() if self.rank else "-"} {self.full_name_upper}'

    @property
    def title2(self):
        return f'{self.rank.__str__() if self.rank else ""} {self.full_name_upper}'

    @property
    def short_title(self):
        return f'{self.rank.__str__() if self.rank else "-"} {self.short_name_upper}'

    @property
    def short_title2(self):
        return f'{self.rank.short if self.rank else "-"} {self.short_name_upper}'

    @property
    def full_title(self):
        return f'{self.title}, {self.staff_print_name2}'
        # return f'{self.title}, {self.staff_short_name}'

    @property
    def in_genitive_name(self):
        obj = {
            'gender': 'male' if self.sex == '1' else 'female',
            'firstName': self.first_name,
            'middleName': self.second_name,
            'lastName': self.last_name
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inGenitive(obj)
        last_name = res["lastName"].upper()
        # last_name = last_name.replace('КЛКА', 'КЛОКА')
        return f'{last_name} {res["firstName"]} {res["middleName"]}'.strip()

    @property
    def in_genitive(self):
        return f'{self.rank.in_genitive} {self.in_genitive_name}'

    @property
    def in_genitive_short(self):
        obj = {
            'gender': 'male' if self.sex == '1' else 'female',
            'firstName': self.first_name,
            'middleName': self.second_name,
            'lastName': self.last_name
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inGenitive(obj)
        return f'{self.rank.in_genitive} {res["lastName"].upper()} {self.initials}'

    @property
    def in_dative_name(self):
        obj = {
            'gender': 'male' if self.sex == '1' else 'female',
            'firstName': self.first_name,
            'middleName': self.second_name,
            'lastName': self.last_name
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inDative(obj)
        middle_name = res["middleName"].replace('Ілліч', 'Іллічу')
        last_name = res["lastName"].upper().replace('КЛКУ', 'КЛОКУ')
        return f'{last_name} {res["firstName"]} {middle_name}'.strip()

    @property
    def in_dative(self):
        return f'{self.rank.in_dative} {self.in_dative_name}'

    @property
    def in_dative_short(self):
        obj = {
            'gender': 'male' if self.sex == '1' else 'female',
            'firstName': self.first_name,
            'middleName': self.second_name,
            'lastName': self.last_name
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inDative(obj)
        last_name = res["lastName"].upper().replace('КЛКУ', 'КЛОКУ')
        return f'{self.rank.in_dative} {last_name.upper()} {self.initials}.'

    @property
    def in_accusative_name(self):
        obj = {
            'gender': 'male' if self.sex == '1' else 'female',
            'firstName': self.first_name,
            'middleName': self.second_name,
            'lastName': self.last_name
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inAccusative(obj)
        middle_name = res["middleName"].replace('Ілліч', 'Ілліча')
        last_name = res["lastName"].upper().replace('КЛКА', 'КЛОКА')
        return f'{last_name} {res["firstName"]} {middle_name}'.strip()

    @property
    def in_accusative(self):
        return f'{self.rank.in_accusative} {self.in_accusative_name}'

    @property
    def extended_name(self):
        return f'{self.serviceman_id}. {self.rank.__str__()} {self.full_name_upper()}, ' \
               f'{self.date_of_birth}, [{self.tax_id}]'

    @admin.display(boolean=True, description='У списку')  #, ordering='excluded')
    def in_list(self):
        if self.at_disposal == '+' or self.staff:
            return True
        elif self.excluded:
            return False
        else:
            return None

    @property
    def birthday(self):
        return f"{self.date_of_birth.strftime('%d.%m.%Y')}" if self.date_of_birth else ''

    birthday.fget.short_description = 'День народження'

    @property
    def age(self):
        today = datetime.now()  # date.today()
        return today.year - self.date_of_birth.year - ((today.month, today.day) <
                                                       (self.date_of_birth.month, self.date_of_birth.day)) \
            if self.date_of_birth else ''

    age.fget.short_description = 'Вік'

    @property
    def next_birthday(self):
        try:
            if self.date_of_birth:
                dob = self.date_of_birth
                today = datetime.now().date()
                next_birthday = datetime(today.year, dob.month, dob.day).date()
                if next_birthday < today:
                    next_birthday = datetime(today.year + 1, dob.month, dob.day).date()
                days_until = (next_birthday - today).days
                return days_until
            else:
                return ''
        except Exception as ex:
            return '?'

    next_birthday.fget.short_description = 'Наступний ДН'

    @property
    def at_disposal(self):
        res = ServicemanAtDisposal.objects.filter(serviceman=self,
                                                  order_out__isnull=False,
                                                  order_out__date__lt=datetime.today().date(),
                                                  order_in__isnull=True
                                                  ).count()
        return '+' if res > 0 else ''
    at_disposal.fget.short_description = 'У розпорядженні'

    @property
    def illegally_absent(self):
        res = ServicemanIllegallyAbsent.objects.filter(serviceman=self,
                                                       order_out__isnull=False,
                                                       order_out__date__lt=datetime.today().date(),
                                                       order_in__date=None
                                                       ).count()
        return format_html(f'<b><span style="color:red">+</span></b>') if res > 0 else ''
    illegally_absent.fget.short_description = 'СЗЧ'

    @property
    def loss(self):
        res = Losses.objects.filter(serviceman=self,
                                    order_daily__isnull=False,
                                    order_daily__date__lt=datetime.today().date(),
                                    order_daily_in__date=None
                                    ).count()
        return format_html(f'<b><span style="color:red">+</span></b>') if res > 0 else ''
    loss.fget.short_description = 'ВТРАТИ'

    @property
    def arrest(self):
        res = Arrest.objects.filter(serviceman=self,
                                    order_out__isnull=False,
                                    order_out__date__lt=datetime.today().date(),
                                    order_in__date=None
                                    ).count()
        return format_html(f'<b><span style="color:red">+</span></b>') if res > 0 else ''
    arrest.fget.short_description = 'Арешт'

    @property
    def staff(self):
        return self.staff_serviceman if hasattr(self, 'staff_serviceman') else None
    staff.fget.short_description = 'Штат'

    # @property
    # def staff_order_name(self):
    #     return f'{self.staff_serviceman.order_short_name if hasattr(self, "staff_serviceman") else "-"}'
    #
    # staff_order_name.fget.short_description = 'Наказ про призначення'
    #
    # @property
    # def staff_order_link(self):
    #     if hasattr(self, "staff_serviceman"):
    #         link = reverse("admin:personnel_staff_change", args=[self.staff_serviceman.id])
    #         return format_html('<a href="%s">%s</a>' % (link, self.staff_short_name))
    #     else:
    #         return '-'
    #
    # staff_order_link.fget.short_description = 'Наказ про призначення'

    @property
    def staff_link(self):
        if hasattr(self, "staff_serviceman"):
            link = reverse("admin:personnel_staff_change", args=[self.staff_serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, self.staff_short_name))
        else:
            return '-'

    staff_link.fget.short_description = 'Штат'

    @property
    def at_disposal_text(self):
        try:
            sm = ServicemanAtDisposal.objects.get(serviceman=self)
            return f'у розпорядженні {sm.at_disposal_verbose}' if sm else ''
        except Exception as ex:
            return ''

    @property
    def at_disposal_short(self):
        try:
            sm = ServicemanAtDisposal.objects.get(serviceman=self)
            return f'у розпорядженні командира' if sm else ''
        except Exception as ex:
            return ''

    @property
    def staff_name(self):
        return f'{self.staff_serviceman if hasattr(self, "staff_serviceman") else "-"}'

    staff_name.fget.short_description = 'Штат'

    @property
    def staff_short_name(self):
        return f'{self.staff_serviceman.short_name if hasattr(self, "staff_serviceman") else "-"}'

    @property
    def staff_full_name(self):
        return f'{self.staff_serviceman.full_name if hasattr(self, "staff_serviceman") else "-"}'

    staff_full_name.fget.short_description = 'Штат (повністю)'

    @property
    def staff_full_name2(self):
        return f'{self.staff_serviceman.full_name if hasattr(self, "staff_serviceman") else self.at_disposal_text}' #"у розпорядженні командира"}'

    staff_full_name2.fget.short_description = 'Штат (повністю)'

    @property
    def staff_full_name_rs(self):
        return f'{self.staff_serviceman.full_name_rs if hasattr(self, "staff_serviceman") else self.at_disposal_short}'

    staff_full_name_rs.fget.short_description = 'Штат (повністю)'

    @property
    def staff_print_name(self):
        return f'{self.staff_serviceman.print_name if hasattr(self, "staff_serviceman") else "-"}'

    staff_print_name.fget.short_description = 'Штат'

    @property
    def staff_print_name2(self):
        return f'{self.staff_serviceman.print_name if hasattr(self, "staff_serviceman") else self.at_disposal_text}'

    staff_print_name2.fget.short_description = 'Штат'

    @property
    def staff_print_name_in_accusative(self):
        return f'{self.staff_serviceman.full_name_in_accusative if hasattr(self, "staff_serviceman") else "-"}'

    staff_print_name_in_accusative.fget.short_description = 'Штат (знахідний)'

    @property
    def staff_print_name_in_accusative2(self):
        return f'{self.staff_serviceman.full_name_in_accusative if hasattr(self, "staff_serviceman") else self.at_disposal_text}'

    staff_print_name_in_accusative2.fget.short_description = 'Штат (знахідний)'

    @property
    def staff_print_name_in_dative(self):
        return f'{self.staff_serviceman.full_name_in_dative if hasattr(self, "staff_serviceman") else "-"}'

    staff_print_name_in_dative.fget.short_description = 'Штат (давальний)'

    @property
    def staff_print_name_in_dative2(self):
        return f'{self.staff_serviceman.full_name_in_dative if hasattr(self, "staff_serviceman") else self.at_disposal_text}'

    staff_print_name_in_dative2.fget.short_description = 'Штат (давальний)'

    @property
    def staff_link(self):
        if hasattr(self, "staff_serviceman"):
            link = reverse("admin:personnel_staff_change", args=[self.staff_serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, self.staff_short_name))
        else:
            return '-'

    staff_link.fget.short_description = 'Штат'

    @property
    def temporary_acting_short_name(self):
        return f'{self.staff_temporary_acting.short_name if hasattr(self, "staff_temporary_acting") else "-"}'

    temporary_acting_short_name.fget.short_description = 'ТВО'

    @property
    def temporary_acting_link(self):
        if hasattr(self, "staff_temporary_acting"):
            link = reverse("admin:personnel_staff_change", args=[self.staff_temporary_acting.id])
            return format_html('<a href="%s">%s</a>' % (link, self.temporary_acting_short_name))
        else:
            return '-'

    temporary_acting_link.fget.short_description = 'ТВО'

    @property
    def service_term(self):
        return f'станом на ' \
               f'{get_verbose_date(self.service_term_start_date) if self.service_term_start_date else "1 січня 2023"}' \
               f' складає {self.service_term_text}'\
            if self.service_term_years is not None \
            else 'не обчислювалась'

    service_term.fget.short_description = 'Вислуга років'

    @property
    def service_term_new(self):
        # Обчислення розрахункової вислуги станом на сьогодні
        try:
            start_date = self.service_term_start_date
            y = int(self.service_term_years if self.service_term_years else 0)
            m = int(self.service_term_months if self.service_term_months else 0)
            d = int(self.service_term_days if self.service_term_days else 0)

            today = datetime.now().date()
            delta = relativedelta(today, start_date)
            add_duration_years = delta.years
            add_duration_months = delta.months
            add_duration_days = delta.days

            new_duration_years = y + add_duration_years
            new_duration_months = m + add_duration_months
            new_duration_days = d + add_duration_days

            current_month_duration = get_month_duration() #30
            if new_duration_days > current_month_duration:
                new_duration_months += 1
                new_duration_days = new_duration_days % current_month_duration
            if new_duration_months > 12:
                new_duration_years += 1
                new_duration_months -= 12

            new_duration = today - start_date
            return f'+{new_duration} + [{add_duration_years} - {add_duration_months} - {add_duration_days}]' \
                   f' = [{new_duration_years} - {new_duration_months} - {new_duration_days}]' \
                   f' = {"більше" if new_duration_years >= 1 else "менше"} одного року'
        except Exception as x:
            print(f'error: {x}')
            return '---'

    service_term_new.fget.short_description = 'Вислуга років (new)'

    @property
    def service_term_years_new(self):
        start_date = self.service_term_start_date
        y = int(self.service_term_years if self.service_term_years else 0)
        m = int(self.service_term_months if self.service_term_months else 0)
        d = int(self.service_term_days if self.service_term_days else 0)

        today = datetime.now().date()
        delta = relativedelta(today, start_date)
        add_duration_years = delta.years
        add_duration_months = delta.months
        add_duration_days = delta.days

        new_duration_years = y + add_duration_years
        new_duration_months = m + add_duration_months
        new_duration_days = d + add_duration_days

        current_month_duration = get_month_duration() #30
        if new_duration_days > current_month_duration:
            new_duration_months += 1
            # new_duration_days = new_duration_days % current_month_duration
        if new_duration_months > 12:
            new_duration_years += 1
            new_duration_months -= 12

        return new_duration_years

    service_term_years_new.fget.short_description = 'Вислуга років (new)'

    @property
    def service_term_years_lt1(self):
        return self.service_term_years_new < 1
    service_term_years_lt1.fget.short_description = 'Вислуга менше 1 року'

    @property
    def service_term_years_gte1(self):
        return self.service_term_years_new >= 1
    service_term_years_gte1.fget.short_description = 'Вислуга більше 1 року'

    @property
    def combat_mission_periods(self):
        return get_serviceman_combat_mission_periods(self)
    combat_mission_periods.fget.short_description = 'Періоди участі у БД'

    @property
    def combat_mission_places(self):
        return get_serviceman_combat_mission_places(self)
    combat_mission_places.fget.short_description = 'Місця участі у БД'

    @property
    def combat_mission_reasons(self):
        return get_serviceman_combat_mission_reasons(self)
    combat_mission_reasons.fget.short_description = 'Підстави участі у БД'



class Rank(models.Model):
    class Meta:
        verbose_name = 'Довідник: Звання'
        verbose_name_plural = 'Довідник: Звання'
        ordering = ['rank_id', 'name']

    rank_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    name = models.CharField(max_length=100, verbose_name='звання')
    short_name = models.CharField(max_length=40, blank=True, null=True, verbose_name='скорочення')

    def __str__(self):
        return self.name.lower()

    @property
    def short(self):
        return (self.short_name if self.short_name else self.name).lower()

    short.fget.short_description = 'Скорочення'

    @property
    def in_genitive(self):
        s = self.name.split()
        obj = {
            'gender': 'male',
            'firstName': s[1] if len(s) > 1 else '',
            'lastName': s[0]
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inGenitive(obj)
        s[0] = res["lastName"].lower()
        if len(s) > 1:
            s[1] = res["firstName"]
        result = ' '.join(s)
        result = result.replace('майстра-', 'майстер-')
        result = result.replace('генерала-', 'генерал-')
        result = result.replace(' i ', ' I ')
        return result

    in_genitive.fget.short_description = 'У родовому'

    @property
    def in_dative(self):
        s = self.name.split()
        obj = {
            'gender': 'male',
            'firstName': s[1] if len(s) > 1 else '',
            'lastName': s[0]
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inDative(obj)
        s[0] = res["lastName"].lower()
        if len(s) > 1:
            s[1] = res["firstName"]
        result = ' '.join(s)
        result = result.replace('майстру-', 'майстер-')
        result = result.replace('генерала-', 'генерал-')
        result = result.replace(' i ', ' I ')
        return result

    in_dative.fget.short_description = 'У давальному'

    @property
    def in_accusative(self):
        s = self.name.split()
        obj = {
            'gender': 'male',
            'firstName': s[1] if len(s) > 1 else '',
            'lastName': s[0]
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inAccusative(obj)
        s[0] = res["lastName"].lower()
        if len(s) > 1:
            s[1] = res["firstName"]
        result = ' '.join(s)
        result = result.replace('штаба-', 'штаб-')
        result = result.replace('майстра-', 'майстер-')
        result = result.replace('генерала-', 'генерал-')
        result = result.replace(' i ', ' I ')
        return result.lower()

    in_accusative.fget.short_description = 'У знахідному'

    @property
    def rank_level(self):
        name = self.name.lower()
        if 'солдат' in name or 'рекрут' in name:
            return 'Солдати'
        elif 'сержант' in name or 'старшина' in name:
            return 'Сержанти'
        else:
            return 'Офіцери'

    rank_level.fget.short_description = 'Ранг'

    @property
    def rank_level2(self):
        name = self.name.lower()
        if 'солдат' in name or 'рекрут' in name:
            return 'рядового'
        elif 'сержант' in name or 'старшина' in name:
            return 'сержантського'
        else:
            return 'офіцерського'

    rank_level2.fget.short_description = 'Склад'


class PositionCategory(models.Model):
    class RankLevel(models.TextChoices):
        SOLDIER = "1", "Солдати"
        SERGEANT = "2", "Сержанти"
        OFFICER = "3", "Офіцери"

    class Meta:
        verbose_name = 'Довідник: ШПК'
        verbose_name_plural = 'Довідник: ШПК'
        ordering = ['position_category_id']

    position_category_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    name = models.CharField(max_length=64, verbose_name='ШПК')
    rank_level = models.CharField(max_length=1, verbose_name='ранг', choices=RankLevel.choices,
                                  default=RankLevel.SOLDIER, blank=True, null=True)

    def __str__(self):
        return self.name

    @property
    def rank_level_display(self):
        return self.get_rank_level_display if self.rank_level else '-'


def position_in_accusative(name):
    if not name:
        return None

    s = name.split()
    obj = {
        'gender': 'male',
        'firstName': s[1] if len(s) > 1 else '',
        'lastName': s[0]
    }
    sh = require('shevchenko', 'v2.1.1')
    res = sh.inAccusative(obj)
    s[0] = res["lastName"].lower()
    if len(s) > 1:
        s[1] = res["firstName"]
    result = ' '.join(s)
    result = result.replace('командир ', 'командира ')
    result = result.replace('командиру ', 'командира ')
    result = result.replace('бухгалтра', 'бухгалтера')
    result = result.replace('цивільну посада', 'цивільна посада')
    result = result.replace('медичнога', 'медичного')
    result = result.replace('відділенню', 'відділення')
    result = result.replace('господарчога', 'господарчого')
    result = result.replace('гранатометнога', 'гранатометного')
    result = result.replace('кулеметнога', 'кулеметного')
    result = result.replace('протитанковога', 'протитанкового')
    result = result.replace('ракетна-артилерійськога', 'ракетно-артилерійського')
    result = result.replace('ракетнога', 'ракетного')
    result = result.replace('артилерійськога', 'артилерійського')
    result = result.replace('зенітна-', 'зенітно-')
    result = result.replace('вузлу', 'вузла')
    result = result.replace('команднога', 'командного')
    result = result.replace('контрольна-технічнога', 'контрольно-технічного')
    result = result.replace('перший', 'першого')
    result = result.replace('першия', 'першого')
    result = result.replace('Заступник ', 'заступника ')
    result = result.replace('заступник ', 'заступника ')
    result = result.replace('черговия', 'чергового')
    result = result.replace('капелану', 'капелана')
    result = result.replace('іза ', 'із ')
    result = result.replace('за ', 'із ')
    result = result.replace('МТЗА', 'МТЗ')
    result = result.replace('бойовия медик', 'бойового медика')
    result = result.replace('гранатометнику', 'гранатометника')
    result = result.replace('- розвідник', '- розвідника')
    result = result.replace('-розвідник', '-розвідника')
    result = result.replace('інформаційна-', 'інформаційно-')
    result = result.replace('телекомунікаційнога', 'телекомунікаційного')
    result = result.replace('начальник ', 'начальника ')
    result = result.replace('начальнику ', 'начальника ')
    result = result.replace('стрілецька рота', 'стрілецької роти')
    result = result.replace('медичний пункт', 'медичного пункту')
    result = result.replace('міномета', 'міномету')
    result = result.replace('молодший спеціаліст', 'молодшого спеціаліста')
    result = result.replace('машиніст екскаватора', 'машиніста екскаватора')
    result = result.replace('навідник-оператор', 'навідника-оператора')
    result = result.replace('водія - лінійний наглядач', 'водія - лінійного наглядача')
    return result

def position_in_dative(name):
    if not name:
        return None

    s = name.split()
    obj = {
        'gender': 'male',
        'firstName': s[1] if len(s) > 1 else '',
        'lastName': s[0]
    }
    sh = require('shevchenko', 'v2.1.1')
    res = sh.inDative(obj)
    s[0] = res["lastName"].lower()
    if len(s) > 1:
        s[1] = res["firstName"]
    result = ' '.join(s)
    result = result.replace('командир ', 'командиру ')
    result = result.replace('командирі ', 'командира ')
    # result = result.replace('командиpі ', 'командира ')
    result = result.replace('начальник ', 'начальнику ')
    result = result.replace('бухгалтру', 'бухгалтеру')
    result = result.replace('цивільні посада', 'цивільна посада')
    result = result.replace('начальниці', 'начальника')
    result = result.replace('артилерійськогу ', 'артилерійського ')
    result = result.replace('відділенні', 'відділення')
    result = result.replace('господарчогу', 'господарчого')
    result = result.replace('гранатометногу', 'гранатометного')
    result = result.replace('кулеметногу', 'кулеметного')
    result = result.replace('протитанковогу', 'протитанкового')
    result = result.replace('ракетну-артилерійського', 'ракетно-артилерійського')
    result = result.replace('ракетногу', 'ракетного')
    result = result.replace('зенітну-кулеметного', 'зенітно-кулеметного')
    result = result.replace('вузлі', 'вузла')
    result = result.replace('командногу', 'командного')
    result = result.replace('контрольну-технічногу', 'контрольно-технічного')
    result = result.replace('Заступник ', 'заступнику ')
    result = result.replace('заступник ', 'заступнику ')
    result = result.replace('начальник ', 'начальнику ')
    result = result.replace('першию ', 'першому ')
    result = result.replace('перший ', 'першому ')
    result = result.replace('черговию', 'черговому')
    result = result.replace('капелані', 'капелана')
    result = result.replace('ізу ', 'із ')
    result = result.replace('зу ', 'із ')
    result = result.replace('МТЗА', 'МТЗ')
    result = result.replace('бойовию медик', 'бойовому медику')
    result = result.replace('гранатометниці', 'гранатометника')
    result = result.replace('- розвідник', '- розвіднику')
    result = result.replace('-розвідник', '-розвіднику')
    result = result.replace('медичногу пункту', 'медичного пункту')
    result = result.replace('мінометі', 'міномету')
    result = result.replace('міномета', 'міномету')
    result = result.replace('молодший спеціаліст', 'молодшому спеціалісту')
    result = result.replace('машиніст екскаватора', 'машиністу екскаватора')
    result = result.replace('навідник-оператор', 'навіднику-оператору')
    result = result.replace('водію - лінійний наглядач', 'водію - лінійному наглядачу')
    return result

def position_in_ablative(name):
    if not name:
        return None

    s = name.split()
    obj = {
        'gender': 'male',
        'firstName': s[1] if len(s) > 1 else '',
        'lastName': s[0]
    }
    sh = require('shevchenko', 'v2.1.1')
    res = sh.inAblative(obj)
    s[0] = res["lastName"].lower()
    if len(s) > 1:
        s[1] = res["firstName"]
    result = ' '.join(s)
    result = result.replace('командир ', 'командиром ')
    # result = result.replace('командирою ', 'командира ')
    result = result.replace('командирою ', 'командира ')
    result = result.replace('начальник служби', 'начальником служби')
    result = result.replace('бухгалтром', 'бухгалтером')
    result = result.replace('цивільною посада', 'цивільна посада')
    result = result.replace('начальникою', 'начальника')
    result = result.replace('артилерійськогом ', 'артилерійського ')
    result = result.replace('відділеннею', 'відділення')
    result = result.replace('господарчогом', 'господарчого')
    result = result.replace('гранатометногом', 'гранатометного')
    result = result.replace('кулеметногом', 'кулеметного')
    result = result.replace('протитанковогом', 'протитанкового')
    result = result.replace('ракетном-артилерійського', 'ракетно-артилерійського')
    result = result.replace('кухаром', 'кухарем')
    result = result.replace('лікаром', 'лікарем')
    result = result.replace('ракетногу', 'ракетного')
    result = result.replace('зенітном-кулеметного', 'зенітно-кулеметного')
    result = result.replace('вузлою', 'вузла')
    result = result.replace('командногом', 'командного')
    result = result.replace('контрольном-технічногом', 'контрольно-технічного')
    result = result.replace('Заступник ', 'заступником ')
    result = result.replace('заступник ', 'заступником ')
    result = result.replace('начальник ', 'начальником ')
    result = result.replace('першиєм ', 'першим ')
    result = result.replace('перший ', 'першим ')
    result = result.replace('черговиєм', 'черговим')
    result = result.replace('капеланою', 'капелана')
    result = result.replace('ізом ', 'із ')
    result = result.replace('зом ', 'із ')
    result = result.replace('МТЗОМ', 'МТЗ')
    result = result.replace('бойовиєм медик', 'бойовим медиком')
    result = result.replace('гранатометникою', 'гранатометника')
    result = result.replace('- розвідник', '- розвідником')
    result = result.replace('-розвідник', '-розвідником')
    result = result.replace('інформаційном-телекомунікаційногом', 'інформаційно-телекомунікаційного')
    result = result.replace('медичногом пункту', 'медичного пункту')
    result = result.replace('міномета', 'міномету')
    result = result.replace('молодший спеціаліст', 'молодшим спеціалістом')
    result = result.replace('машиніст екскаватора', 'машиністом екскаватора')
    result = result.replace('навідник-оператор', 'навідником-оператором')
    result = result.replace('водієм - лінійний наглядач', 'водієм - лінійним наглядачем')
    return result


class Position(models.Model):
    class Meta:
        verbose_name = 'Довідник: Посада'
        verbose_name_plural = 'Довідник: Посади'
        ordering = ['position_id', 'name']

    name = models.CharField(max_length=128, verbose_name='назва посади')
    position_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    tariff = models.ForeignKey('Tariff', on_delete=models.DO_NOTHING, blank=False, null=False,
                               verbose_name='тарифний розряд')
    milspec = models.CharField(default='100915А', max_length=10, blank=False, null=False, verbose_name='ВОС')
    position_category = models.ForeignKey('PositionCategory', on_delete=models.SET_NULL, null=True, blank=True,
                                          verbose_name='ШПК')

    def __str__(self):
        return f'{self.name.capitalize()} ({self.tariff.salary}/{self.tariff.tariff_no}) {self.milspec}'

    @property
    def in_accusative(self):
        return position_in_accusative(self.name)
    in_accusative.fget.short_description = 'У знахідному'

    @property
    def in_dative(self):
        return position_in_dative(self.name)
    in_dative.fget.short_description = 'У давальному'

    @property
    def in_ablative(self):
        return position_in_ablative(self.name)
    in_ablative.fget.short_description = 'У орудному'


class UnitGroup(models.Model):
    class Meta:
        verbose_name = 'Підрозділи: Категорії'
        verbose_name_plural = 'Підрозділи: Категорії'
        ordering = ['group_id']

    group_id = models.PositiveIntegerField(blank=False, null=False, verbose_name='номер')
    name = models.CharField(max_length=64, verbose_name='Назва групи')

    def __str__(self):
        return self.name

    def staff_all_count(self):
        # Отримуємо всі `UnitCombatGroup`, пов'язані з кожним `Unit` у `UnitGroup`
        unit_combat_groups = UnitCombatGroup.objects.filter(unit_group=self)

        # Отримуємо кількість працівників для кожної `UnitCombatGroup`
        staff_count = sum(group.staff_all_count() for group in unit_combat_groups)
        return staff_count

    def staff_list_count(self):
        # Отримуємо всі `UnitCombatGroup`, пов'язані з кожним `Unit` у `UnitGroup`
        unit_combat_groups = UnitCombatGroup.objects.filter(unit_group=self)

        # Отримуємо кількість працівників для кожної `UnitCombatGroup`
        staff_count = sum(group.staff_list_count() for group in unit_combat_groups)
        return staff_count

    @property
    def posture(self):
        all_count = self.staff_all_count()
        if all_count > 0:
            percentage = round((self.staff_list_count() / all_count * 100), 2)
        else:
            percentage = 0
        return format_html(
            '''
            <progress value="{0}" max="100"></progress>
            <span style="font-weight:bold">{0}%</span>
            ''',
            percentage
        )
    posture.fget.short_description = 'Укомплектованість'

    @property
    def unit_count_link(self):
        result = UnitCombatGroup.objects.filter(unit_group=self).count()
        link = f'/admin/personnel/unitcombatgroup/?unit_group={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    unit_count_link.fget.short_description = 'Кількість підрозділів'

    @property
    def staff_all_count_link(self):
        result = self.staff_all_count()
        link = f'/admin/personnel/staff/?staff_active=active&unit={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_all_count_link.fget.short_description = 'Посади (штат)'

    @property
    def staff_list_count_link(self):
        result = self.staff_list_count()
        link = f'/admin/personnel/staff/?in_staff=staff&staff_active=active&unit={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_list_count_link.fget.short_description = 'Посади (список)'


class UnitCombatGroup(models.Model):
    class Meta:
        verbose_name = 'Підрозділи: Групи (БЧС)'
        verbose_name_plural = 'Підрозділи: Групи (БЧС)'
        ordering = ['group_id']

    group_id = models.PositiveIntegerField(blank=False, null=False, verbose_name='номер')
    name = models.CharField(max_length=100, verbose_name='Назва групи')
    unit_group = models.ForeignKey('UnitGroup', on_delete=models.PROTECT, blank=False, null=False,
                                    verbose_name='Категорія')

    def __str__(self):
        return f'{self.unit_group}/{self.name}'

    def full_name(self):
        return self.__str__()

    def staff_all_count(self):
        # Отримуємо всі `Unit`, пов'язані з цією `UnitCombatGroup`
        units = self.unit_combat_group_rel.all()

        # Отримуємо всі `Staff`, пов'язані з кожним `Unit`
        # крім цивільних посад
        staff_count = sum(unit.staff_set.filter(Q(date_end__isnull=True) |
                                                Q(date_end__gte=datetime.today()), #|
                                                #Q(serviceman__isnull=False),
                                                date_start__lte=datetime.today()
                                                ).exclude(position__position_category__rank_level__isnull=True).count() for unit in units)

        return staff_count

    def staff_list_count(self):
        # Отримуємо всі `Unit`, пов'язані з цією `UnitCombatGroup`
        units = self.unit_combat_group_rel.all()

        # Отримуємо всі `Staff`, пов'язані з кожним `Unit`
        staff_count = sum(unit.staff_set.filter(Q(date_end__isnull=True) |
                                                Q(date_end__gte=datetime.today()),
                                                serviceman__isnull=False,
                                                date_start__lte=datetime.today()
                                                ).count() for unit in units)

        return staff_count

    @property
    def unit_group_link(self):
        link = f'/admin/personnel/unitgroup/{self.unit_group.id}/change'
        return format_html('<a href="%s">%s</a>' % (link, self.unit_group.name))

    unit_group_link.fget.short_description = 'Категорія'

    @property
    def unit_count_link(self):
        result = Unit.objects.filter(combat_group=self).count()
        link = f'/admin/personnel/unit/?combat_group__id__exact={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    unit_count_link.fget.short_description = 'Кількість підрозділів'

    @property
    def staff_all_count_link(self):
        result = self.staff_all_count()
        link = f'/admin/personnel/staff/?staff_active=active&unit_combat_group={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_all_count_link.fget.short_description = 'Посади (штат)'

    @property
    def staff_list_count_link(self):
        result = self.staff_list_count()
        link = f'/admin/personnel/staff/?in_staff=staff&staff_active=active&unit_combat_group={self.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_list_count_link.fget.short_description = 'Посади (список)'

    @property
    def posture(self):
        all_count = self.staff_all_count()
        if all_count > 0:
            percentage = round((self.staff_list_count() / all_count * 100), 2)
        else:
            percentage = 0
        return format_html(
            '''
            <progress value="{0}" max="100"></progress>
            <span style="font-weight:bold">{0}%</span>
            ''',
            percentage
        )
    posture.fget.short_description = 'Укомплектованість'


class Unit(models.Model):
    class Meta:
        verbose_name = 'Довідник: Підрозділ'
        verbose_name_plural = 'Довідник: Підрозділи'
        ordering = ['unit_id']

    unit_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    unit_code = models.CharField(max_length=20, verbose_name='код підрозділу', default='0000')
    name = models.CharField(max_length=128, verbose_name='назва підрозділу')
    full_name = models.CharField(max_length=256, blank=True, null=True, verbose_name='повна назва')
    group = models.ForeignKey('UnitGroup', on_delete=models.SET_NULL, null=True, blank=True, verbose_name='група')
    combat_group = models.ForeignKey('UnitCombatGroup', on_delete=models.SET_NULL, null=True, blank=True,
                                     related_name='unit_combat_group_rel',
                                     verbose_name='група (БЧС)')
    letter = models.CharField(max_length=10, blank=True, null=True, verbose_name='літера')
    parent_unit = models.ForeignKey('self',
                                    on_delete=models.SET_NULL,
                                    blank=True, null=True,
                                    related_name='parent',
                                    verbose_name='підпорядкування')


    def staff_all_count(self):
        result = Staff.objects.filter(Q(date_end__isnull=True) |
                                      Q(date_end__gte=datetime.today()) |
                                      Q(serviceman__isnull=False),
                                      date_start__lte=datetime.today(),
                                      unit=self,
                                      ).count()
        return result

    def staff_list_count(self):
        result = Staff.objects.filter(Q(date_end__isnull=True) |
                                      Q(date_end__gte=datetime.today()),
                                      serviceman__isnull=False,
                                      date_start__lte=datetime.today(),
                                      unit=self,
                                      ).count()
        return result

    @property
    def posture(self):
        all_count = self.staff_all_count()
        if all_count > 0:
            percentage = round((self.staff_list_count() / all_count * 100), 2)
        else:
            percentage = 0
        return format_html(
            '''
            <progress value="{0}" max="100"></progress>
            <span style="font-weight:bold">{0}%</span>
            ''',
            percentage
        )
    posture.fget.short_description = 'Укомплектованість'

    @property
    def in_genitive(self):
        if not self.full_name:
            return ''
        s = self.full_name.split()
        obj = {
            'gender': 'male',
            'firstName': s[1] if len(s) > 1 else '',
            'lastName': s[0]
        }
        sh = require('shevchenko', 'v2.1.1')
        res = sh.inGenitive(obj)
        s[0] = res["lastName"].lower()
        if len(s) > 1:
            s[1] = res["firstName"]
        result = ' '.join(s)

        if self.parent_unit and self.parent_unit.unit_id != 1 \
            and ((self.group and self.group.group_id == 1 and self.parent_unit.unit_id != 1) \
            or (self.group and self.group.group_id == 3 and self.parent_unit.unit_id != 1) \
            or (self.letter == 'В6') \
            or (self.letter == 'В7') \
        ):  #in {'B6', 'B7'}):
            result = f'{result} {self.parent_unit.in_genitive.lower()}'

        result = result.replace('командуванні', 'командування')
        result = result.replace('штаба', 'штабу')
        result = result.replace('плануванні', 'планування')
        result = result.replace('цивільна-військовога', 'цивільно-військового')
        result = result.replace('сила підтримки', 'сил підтримки')
        result = result.replace('командного пункта', 'командного пункту')
        result = result.replace('медични', 'медичної')
        result = result.replace('фінансово-економічни', 'фінансово-економічної')
        result = result.replace('ракетна-артилерійськога', 'ракетно-артилерійського')
        result = result.replace('автомобільни', 'автомобільної')
        result = result.replace('продовольчі', 'продовольчої')
        result = result.replace('речови', 'речової')
        result = result.replace('паливна-мастильних', 'паливно-мастильних')
        result = result.replace('інфраструктурнога', 'інфрастуктурного')
        result = result.replace('стрілецьки рота', 'стрілецької роти')
        result = result.replace('взвода', 'взводу')
        result = result.replace('відділенні', 'відділення')
        result = result.replace('гранатометне', 'гранатометного')
        result = result.replace('кулеметне', 'кулеметного')
        result = result.replace('протитанкове', 'протитанкового')
        result = result.replace('ракетна-артилерійськия взвод', 'ракетно-артилерійського взводу')
        result = result.replace('зенітне артилерійське', 'зенітного артилерійського')
        result = result.replace('зенітне ракетне відділення', 'зенітного ракетного відділення')
        result = result.replace('зенітне кулеметного', 'зенітного кулеметного')
        result = result.replace('мінометни батареї', 'мінометної батареї')
        result = result.replace('мінометния розрахунок', 'мінометного розрахунку')
        result = result.replace('снайперіва', 'снайперів')
        result = result.replace('мінометния взвод', 'мінометного взводу')
        result = result.replace('розвідувальне відділення', 'розвідувального відділення')
        result = result.replace('інженерна-саперного', 'інженерно-саперного')
        result = result.replace('інженерна-саперне', 'інженерно-саперного')
        result = result.replace('інформаційна-телекомунікаційного вузола', 'інформаційно-телекомунікаційного вузла')
        result = result.replace('електрозабезпеченні', 'електрозабезпечення')
        result = result.replace('матеріальна-технічнога', 'матеріально-технічного')
        result = result.replace('автомобільне відділення', 'автомобільного відділення')
        result = result.replace('технічнога', 'технічного')
        result = result.replace('склади', 'складів')
        result = result.replace('польови лазні', 'польової лазні')
        result = result.replace('медичного пункта', 'медичного пункту')
        result = result.replace('контрольна-технічного пункта', 'контрольно-технічного пункту')
        result = result.replace('ва розпорядженні', 'в розпорядженні')
        result = result.replace('управлінні ', 'управління ')
        result = result.replace('механізовани роти', 'механізованої роти')
        result = result.replace('механізования взвод', 'механізованого взводу')
        result = result.replace('механізоване відділення', 'механізованого відділення')
        result = result.replace('стрілецькия взвод', 'стрілецького взводу')
        result = result.replace('стрілецьке відділення', 'стрілецького відділення')
        result = result.replace('лінійна-кабельни', 'лінійно-кабельної')
        return result

    in_genitive.fget.short_description = 'У родовому'

    def __str__(self):
        return self.full_name


class ServicemanBase(models.Model):
    class Meta:
        abstract = True

    comment = models.TextField(blank=True, null=True, verbose_name='коментар')
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, verbose_name='Користувач')


class ServicemanOutStaffBase(ServicemanBase):
    class Meta:
        abstract = True

    date_from = models.DateField(verbose_name='Початок')
    date_to = models.DateField(verbose_name='Закінчення', blank=True, null=True)
    report_out = models.ForeignKey('documents.Report', on_delete=models.SET_NULL,
                                   blank=True, null=True,
                                   verbose_name='Рапорт (початок)',
                                   related_name='%(class)s_report_out')
    order_out = models.ForeignKey('documents.Order', verbose_name='Добовий наказ (початок)',
                                  on_delete=models.PROTECT,
                                  related_name='%(class)s_order_out',
                                  null=False, blank=False,
                                  limit_choices_to={'order_type': 1})
    report_in = models.ForeignKey('documents.Report', on_delete=models.SET_NULL,
                                  blank=True, null=True,
                                  verbose_name='Рапорт (закінчення)',
                                  related_name='%(class)s_report_in')
    order_in = models.ForeignKey('documents.Order', verbose_name='Добовий наказ (закінчення)',
                                 on_delete=models.SET_NULL,
                                 related_name='%(class)s_order_in',
                                 null=True, blank=True,
                                 limit_choices_to={'order_type': 1})

    @property
    def status(self):
        if self.order_in:
            return 'закритий'
        else:
            return format_html(f'<span style="color:blue">активний</span>')

    status.fget.short_description = 'Статус'

    @property
    def verbose_date_from(self):
        return self.date_from.strftime("%d.%m.%Y")

    @property
    def report_out_short_name(self):
        return self.report_out.short_name if self.report_out else '-'

    report_out_short_name.fget.short_description = 'Рапорт (початок)'

    def report_out_link(self):
        if self.report_out:
            link = reverse("admin:documents_report_change", args=[self.report_out.id])
            return format_html('<a href="%s">%s</a>' % (link, self.report_out_short_name))
        else:
            return '-'

    report_out_link.short_description = 'Рапорт (початок)'
    report_out_link.admin_order_field = 'report_out__input_id'

    @property
    def report_in_short_name(self):
        return self.report_in.short_name if self.report_in else '-'

    report_in_short_name.fget.short_description = 'Рапорт (закінчення)'

    @property
    def order_out_short_name(self):
        return self.order_out.short_name if self.order_out else '-'

    order_out_short_name.fget.short_description = 'Наказ (початок)'

    @property
    def order_out_link(self):
        if self.order_out:
            link = reverse("admin:documents_order_change", args=[self.order_out.id])
            return format_html('<a href="%s">%s</a>' % (link, self.order_out_short_name))
        else:
            return '-'

    order_out_link.fget.short_description = 'Наказ (початок)'
    order_out_link.fget.admin_order_field = 'order_out__order_id'

    @property
    def order_in_short_name(self):
        return self.order_in.short_name if self.order_in else '-'

    order_in_short_name.fget.short_description = 'Наказ (закінчення)'

    def order_in_link(self):
        if self.order_in:
            link = reverse("admin:documents_order_change", args=[self.order_in.id])
            return format_html('<a href="%s">%s</a>' % (link, self.order_in_short_name))
        else:
            return '-'

    order_in_link.short_description = 'Наказ (закінчення)'
    order_in_link.admin_order_field = 'order_in__order_id'

    @property
    def days(self):
        date_end = self.date_to if self.date_to else datetime.today().date()
        return abs((date_end - self.date_from).days) + 1 if self.date_from and date_end else 0

    days.fget.short_description = 'Дні'

    @property
    def date_from_short(self):
        return get_short_date(self.date_from) if self.date_from else ''

    @property
    def date_to_short(self):
        return get_short_date(self.date_to) if self.date_to else ''

    @property
    def date_to_verbose(self):
        return get_short_date(self.date_to) if self.date_to else get_short_date(self.order_in.date) if self.order_in else ''

    @property
    def period_verbose(self):
        if self.date_to:
            return f'на {self.days} діб з {self.date_from_short} по {self.date_to_short}'
        else:
            return f'з {self.date_from_short} до особливого розпорядження'

    @property
    def basis_out_verbose(self):
        result = f'{"рапорт "+self.report_out.short_info if self.report_out else ""}'
        if hasattr(self, "reason"):
            if len(result) > 0:
                result = f'{result}, {self.reason}'
            else:
                result = self.reason
        return result

    @property
    def basis_in_verbose(self):
        result = f'{"рапорт "+self.report_in.short_info if self.report_in else ""}'
        if hasattr(self, "reason"):
            if len(result) > 0:
                result = f'{result}, {self.reason}'
            else:
                result = self.reason
        return result

    @property
    def serviceman_staff_link(self):
        return self.serviceman.staff_link

    serviceman_staff_link.fget.short_description = 'Штат'
    # serviceman_staff_link.admin_order_field = '???'

    @property
    def serviceman_staff_full_name(self):
        return self.serviceman.staff_full_name2


class DisposalReason(models.TextChoices):
    ILLEGALLY = "ILLA", "СЗЧ"
    MISSING = "MISS", "ЗНИК БЕЗВІСТИ"
    HOSPITAL = "HOSP", "ДОВГОТРИВАЛЕ ЛІКУВАННЯ"
    DISPOSAL = "DISP", "МОБІЛІЗОВАНО У РОЗПОРЯДЖЕННЯ"
    DOWNSIZE = "DOWN", "СКОРОЧЕННЯ ШТАТУ"
    HEAD = "HEAD", "ПРИЗНАЧЕНІ НА ГОЛОВУ"
    OFFICER = "OFFI", "СОЛДАТ ПІДТВЕРДИВШИЙ ОФІЦЕРСЬКЕ"
    OTHER = "OTHE", "ІНШЕ"


class ServicemanAtDisposal(ServicemanOutStaffBase):
    class Meta:
        verbose_name = 'В/С у Розпорядженні'
        verbose_name_plural = 'В/С у Розпорядженні'

    serviceman = models.ForeignKey(Serviceman, on_delete=models.PROTECT, null=False, blank=False,
                                   related_name='serviceman_at_disposal',
                                   verbose_name='Військовослужбовець')
    unit = models.ForeignKey(Unit, on_delete=models.PROTECT, blank=True, null=True,
                             verbose_name='Підрозділ підпорядкування')
    at_disposal = models.CharField(max_length=256, verbose_name='у розпорядженні', blank=True, null=True)
    reason = models.CharField(max_length=4, verbose_name='Причина', choices=DisposalReason.choices,
                              default=DisposalReason.ILLEGALLY)

    def __str__(self):
        return f'{self.id}, {self.serviceman}, {self.unit_name}, {self.date_from} <-> {self.date_to}'

    @property
    def short_name(self):
        return f'{self.id}, {self.serviceman.short_name}, {self.unit_name}, {self.date_from}'

    @property
    def at_disposal_verbose(self):
        return self.at_disposal if self.at_disposal else f'командира військової частини {get_globals().military_unit_name_public}'

    at_disposal_verbose.fget.short_description = 'У розпорядженні'

    @property
    def unit_name(self):
        return self.unit.name if self.unit else '-'

    unit_name.fget.short_description = 'Підрозділ підпорядкування'

    # @property
    # def status_text(self):
    #     if not self.order_out:
    #         return '[відсутній наказ]'
    #     if self.order_out.date > datetime.today().date():
    #         return '[не почалося]'
    #     if self.order_out and self.order_out.date < datetime.today().date() and not self.order_in:
    #         return 'у розпорядженні'
    #     else:
    #         return 'закрито'
    #
    # @property
    # def status(self):
    #     if not self.order_out:
    #         return format_html(f'<span style="color:red">[відсутній наказ]</span>')
    #     if self.order_out.date > datetime.today().date():
    #         return format_html(f'<span style="color:red">[не почалося]</span>')
    #     if self.order_out and self.order_out.date < datetime.today().date() and not self.order_in:
    #         return format_html(f'<span style="color:blue">у розпорядженні</span>')
    #     else:
    #         return 'закрито'
    #
    # status.fget.short_description = 'Статус'


class ServicemanAttached(ServicemanOutStaffBase):
    class Meta:
        verbose_name = 'В/С Прикомандировані'
        verbose_name_plural = 'В/С Прикомандировані'

    serviceman = models.ForeignKey(Serviceman, on_delete=models.CASCADE, null=False, blank=False,
                                   related_name='serviceman_attached',
                                   verbose_name='Військовослужбовець')
    unit = models.ForeignKey(Unit, on_delete=models.PROTECT, blank=True, null=True,
                             verbose_name='Підрозділ')
    external_military_unit = models.CharField(max_length=256, verbose_name='Військова частина', blank=True, null=True)
    external_position = models.CharField(max_length=256, verbose_name='Посада', blank=True, null=True)
    reason = models.CharField(max_length=256, blank=True, null=True, verbose_name='Підстава')

    def __str__(self):
        return f'{self.id}, {self.serviceman}, {self.external_military_unit}, {self.date_from} <-> {self.date_to}'

    @property
    def unit_name(self):
        return self.unit.name if self.unit else '-'

    unit_name.fget.short_description = 'Підрозділ'

    @property
    def external_position_verbose(self):
        return f'{self.external_position}{" військової частини " + self.external_military_unit if self.external_military_unit else ""}'


class ServicemanIllegallyAbsent(ServicemanOutStaffBase):
    class Meta:
        verbose_name = 'В/С у СЗЧ'
        verbose_name_plural = 'В/С у СЗЧ'

    serviceman = models.ForeignKey(Serviceman, on_delete=models.PROTECT, null=False, blank=False,
                                   related_name='serviceman_illegally_absent',
                                   verbose_name='Військовослужбовець')

    def __str__(self):
        return f'{self.serviceman}, {self.date_from} - {self.date_to}'

    # @property
    # def status_text(self):
    #     if self.date_from and self.date_from > datetime.today().date():
    #         return '[не почалося]'
    #     if self.date_from and self.date_from <= datetime.today().date() and not self.date_to:
    #         return 'у СЗЧ'
    #     if self.date_to and self.date_to <= datetime.today().date():
    #         return 'закрито'
    #     else:
    #         return '[невизначений]'
    #
    # @property
    # def status(self):
    #     # if not self.order_out:
    #     #     return format_html(f'<span style="color:red">[відсутній наказ]</span>')
    #     if self.date_from and self.date_from > datetime.today().date():
    #         return format_html(f'<span style="color:red">[не почалося]</span>')
    #     if self.date_from and self.date_from <= datetime.today().date() and not self.date_to:
    #         return format_html(f'<span style="color:blue">у СЗЧ</span>')
    #     if self.date_to and self.date_to <= datetime.today().date():
    #         return 'закрито'
    #     else:
    #         return format_html(f'<span style="color:red">[невизначений]</span>')
    #
    # status.fget.short_description = 'Статус'


class Location(models.Model):
    class Meta:
        verbose_name = 'Довідник: Локація'
        verbose_name_plural = 'Довідник: Локації'
        ordering = ['location_id']

    location_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='Номер')
    name = models.CharField(max_length=256, verbose_name='Назва локації')
    description = models.TextField(verbose_name='Опис', blank=True, null=True)

    def __str__(self):
        return self.name


class Assignee(models.Model):
    class Meta:
        verbose_name = 'виконавець'
        verbose_name_plural = 'виконавці'
        ordering = ['assignee_id']

    assignee_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    name = models.CharField(max_length=128, verbose_name='виконавець')
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, verbose_name='Користувач')

    def __str__(self):
        return self.name


class Tariff(models.Model):
    class Meta:
        verbose_name = 'Довідник: Тарифний розряд'
        verbose_name_plural = 'Довідник: Тарифні розряди'
        ordering = ['tariff_id']

    tariff_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    salary = models.PositiveIntegerField(default=2730, blank=False, null=False, verbose_name='оклад')
    bonus1 = models.PositiveIntegerField(default=333, blank=False, null=False,
                                         verbose_name='пермія за вислугою до 1 року (%)')
    bonus2 = models.PositiveIntegerField(default=284, blank=False, null=False,
                                         verbose_name='премія за вислугою понад рік (%)')

    def __str__(self):
        return f'{self.tariff_id} - {self.salary} ({self.bonus1}% - {self.bonus2}%)'

    @property
    def tariff_no(self):
        return self.tariff_id

    @property
    def tariff_short_name(self):
        return f'{self.salary}/{self.tariff_id}'


# class StaffPositionStatus(enum.Enum):
#     ACTIVE = 1
#     CLOSED = 2
#     INACTIVE = 3

def get_serviceman_staff_bonus(serviceman, staff):
    return staff.position.tariff.bonus2\
        if serviceman.service_term_years_gte1\
        else staff.position.tariff.bonus1
    # return staff.position.tariff.bonus2\
    #     if serviceman.service_term_years and serviceman.service_term_years >= 1\
    #     else staff.position.tariff.bonus1


def fix_staff_full_name_rs(name):
    if 'стрілецької' in name:
        name = re.sub(r'\d+ відділення', 'стрілецького відділення', name)
        name = re.sub(r'\d+ стрілецького відділення', 'стрілецького відділення', name)
        name = re.sub(r'\d+ взводу', 'стрілецького взводу', name)
        name = re.sub(r'\d+ стрілецького взводу', 'стрілецького взводу', name)
        name = re.sub(r'\d+ роти', 'стрілецької роти', name)
        name = re.sub(r'\d+ стрілецької роти', 'стрілецької роти', name)
    if 'механізованої' in name:
        name = re.sub(r'\d+ механізованого', 'механізованого', name)
    if 'вогневої' in name:
        name = re.sub(r'\d+ гранатометного', 'гранатометного', name)
        name = re.sub(r'\d+ зенітного', 'зенітного', name)
    if 'мінометної' in name:
        name = re.sub(r'\d+ мінометного', 'мінометного', name)
    if 'розвідувального' in name:
        name = re.sub(r'\d+ розвідувального', 'розвідувального', name)
    if 'інженерно-саперного' in name:
        name = re.sub(r'\d+ інженерно-саперного', 'інженерно-саперного', name)
    return name


def fix_staff_full_name(name):
    result = name.replace('роти роти', 'роти')
    result = result.replace('взводу взводу', 'взводу')
    result = result.replace('взводу взводу', 'взводу')
    result = result.replace('відділення відділення', 'відділення')
    result = result.replace('радіостанції радіостанції', 'радіостанції')
    result = result.replace('їдальні їдальні', 'їдальні')
    result = result.replace('гранатометного відділення гранатометного відділення', 'гранатометного відділення')
    result = result.replace('протитанкового відділення протитанкового відділення', 'протитанкового відділення')
    result = result.replace('кулеметного відділення кулеметного відділення', 'кулеметного відділення')
    result = result.replace('взводу танка 1 танкового взводу', 'танкового взводу')
    result = re.sub('танка [1-9] ', '', result)
    return result



class StaffDefinition(models.Model):
    class Meta:
        verbose_name = 'Штат'
        verbose_name_plural = 'Штат'
        ordering = ['-date']

    date = models.DateField(verbose_name='Дата початку дії')
    description = models.TextField(verbose_name='Опис')
    daily_order = models.ForeignKey('documents.Order', verbose_name='Наказ про введення в дію',
                                    on_delete=models.SET_NULL, null=True, blank=True,
                                    limit_choices_to={'order_type': 1})
    file1 = models.FileField(upload_to='StaffDefinition', blank=True, null=True, verbose_name='Файл 1')
    file2 = models.FileField(upload_to='StaffDefinition', blank=True, null=True, verbose_name='Файл 2')


# class StaffManager(models.Manager):
#     def get_queryset(self):
#         return super(StaffManager, self).get_queryset().filter(
#             Q(date_end__isnull=True) |
#             Q(date_end__gte=datetime.today()) |
#             Q(serviceman__isnull=False),
#             date_start__lte=datetime.today())


class Staff(models.Model):
    class Meta:
        verbose_name = 'Штатна посада (ШПС)'
        verbose_name_plural = 'Штатні посади (ШПС)'
        ordering = ['staff_id', 'id', 'name']

    # objects = StaffManager()

    staff_id = models.PositiveIntegerField(blank=False, null=False, verbose_name='номер')
    date_start = models.DateField(verbose_name='дата початку дії', null=False, blank=False)
    date_end = models.DateField(verbose_name='дата закінчення дії', null=True, blank=True)
    name = models.CharField(max_length=128, verbose_name='назва штатної посади')
    unit = models.ForeignKey('Unit', on_delete=models.SET_NULL, blank=False, null=True, verbose_name='підрозділ')
    position = models.ForeignKey('Position', on_delete=models.DO_NOTHING, blank=False, null=False,
                                 verbose_name='посада')
    serviceman = models.OneToOneField('Serviceman', related_name='staff_serviceman', on_delete=models.SET_NULL,
                                      blank=True, null=True, verbose_name='військовослужбовець')
    candidate = models.ForeignKey('Serviceman', related_name='staff_candidate', on_delete=models.SET_NULL, blank=True,
                                  null=True, verbose_name='кандидат')
    temporary_acting = models.OneToOneField('Serviceman', related_name='staff_temporary_acting',
                                            on_delete=models.SET_NULL, blank=True, null=True, verbose_name='ТВО')
    comment = models.TextField(blank=True, null=True, verbose_name='коментар')

    def __str__(self):
        return f'{self.staff_id}. {self.unit.name}, {self.position.name}' \
               f' {self.serviceman if self.serviceman else "[ВАКАНТ]"}' \
               f' {" [НЕ АКТИВНА]" if self.date_start and self.date_start > datetime.today().date() else ""}' \
               f' {" [ЗАКРИТА]" if self.date_end and self.date_end <= datetime.today().date() else ""}'

    @admin.display(boolean=True, description='Активна')
    def is_active(self):
        if self.date_start and self.date_start > datetime.today().date():
            return None
        elif self.date_end and self.date_end <= datetime.today().date():
            return False
        else:
            return True

    @property
    def short_name(self):
        return f'{self.staff_id}. {self.unit.name}, {self.position.name}'

    short_name.fget.short_description = 'Штатна посада (скорочено)'

    @property
    def full_name(self):
        # return f'{self.position.name.lower()} {self.unit.full_name}'
        # result = self.position.name.lower()
        # result = self.name if self.unit.group.group_id == 1 else self.position.name.lower()
        result = self.name.lower()
        if self.unit.group is not None and self.unit.group.group_id != 1:
            result = f'{result} {self.unit.in_genitive.lower()}'
        return fix_staff_full_name(result)

    full_name.fget.short_description = 'Штатна посада (повна)'

    @property
    def full_name_rs(self):
        # result = self.name.lower()
        # if self.unit.group.group_id != 1:
        #     result = f'{result} {self.unit.in_genitive.lower()}'
        # result = fix_staff_full_name(result)
        result = self.full_name
        result = fix_staff_full_name_rs(result)
        return result

    full_name_rs.fget.short_description = 'Штатна посада (повна, для РС наказу)'

    @property
    def full_name_in_accusative(self):
        result = position_in_accusative(self.name)
        if self.unit.group.group_id != 1:  #
            result = f'{result} {self.unit.in_genitive.lower()}'
        return fix_staff_full_name(result)

    full_name_in_accusative.fget.short_description = 'Штатна посада (знахідний)'

    @property
    def full_name_rs_in_accusative(self):
        result = self.full_name_in_accusative
        result = fix_staff_full_name_rs(result)
        return result

    full_name_rs_in_accusative.fget.short_description = 'Штатна посада (знахідний, для РС наказу)'

    @property
    def full_name_in_dative(self):
        result = position_in_dative(self.name)
        if self.unit.group.group_id != 1:
            result = f'{result} {self.unit.in_genitive.lower()}'
        return fix_staff_full_name(result)

    full_name_in_dative.fget.short_description = 'Штатна посада (давальний)'

    @property
    def full_name_rs_in_dative(self):
        result = self.full_name_in_dative
        result = fix_staff_full_name_rs(result)
        return result

    full_name_rs_in_dative.fget.short_description = 'Штатна посада (давальний, для РС наказу)'

    @property
    def full_name_in_ablative(self):
        result = position_in_ablative(self.name)
        if self.unit.group.group_id != 1:
            result = f'{result} {self.unit.in_genitive.lower()}'
        result = fix_staff_full_name(result)
        return result

    full_name_in_ablative.fget.short_description = 'Штатна посада (орудний)'

    @property
    def full_name_rs_in_ablative(self):
        result = self.full_name_in_ablative
        result = fix_staff_full_name_rs(result)
        return result

    full_name_rs_in_ablative.fget.short_description = 'Штатна посада (орудний, для РС наказу)'

    @property
    def print_name(self):
        return f'{self.position.name} {self.unit.full_name}'.lower()

    print_name.fget.short_description = 'Штатна посада (скорочено)'

    @property
    def position_display_name(self):
        status = get_staff_position_status(self)
        if status == 1:  # StaffPositionStatus.CLOSED:
            return format_html(f'<b><span style="color:red">{self.position}</span></b>')
        elif status == 2:  # StaffPositionStatus.INACTIVE:
            return format_html(f'<b><span style="color:magenta">{self.position}</span></b>')
        else:
            return self.name

    position_display_name.fget.short_description = 'Назва штатної посади'

    @property
    def unit_link(self):
        link = reverse("admin:personnel_unit_change", args=[self.unit.id])
        return format_html('<a href="%s">%s</a>' % (link, self.unit))

    unit_link.fget.short_description = 'підрозділ'

    @property
    def serviceman_name(self):
        status = get_staff_position_status(self)
        if self.serviceman:
            if status == 1:  # StaffPositionStatus.CLOSED:
                return format_html(f'<b><span style="color:red">{self.serviceman}</span></b>')
            elif status == 2:  # StaffPositionStatus.INACTIVE:
                return format_html(f'<b><span style="color:magenta">{self.serviceman}</span></b>')
            else:
                link = reverse("admin:personnel_serviceman_change", args=[self.serviceman.id])
                return format_html('<a href="%s">%s</a>' % (link, self.serviceman))
        else:
            return format_html(f'<b><span style="color:{get_staff_position_color(status)}">ВАКАНТ</span></b>')

    serviceman_name.fget.short_description = 'Військовослужбовець'

    @property
    def serviceman_tax_id(self):
        return self.serviceman.tax_id if self.serviceman else '-'

    serviceman_tax_id.fget.short_description = 'ІПН'

    @property
    def serviceman_phone(self):
        return self.serviceman.phone_number if self.serviceman else '-'

    serviceman_phone.fget.short_description = 'Телефон'

    @property
    def temporary_acting_link(self):
        if self.temporary_acting:
            link = reverse("admin:personnel_serviceman_change", args=[self.temporary_acting.id])
            return format_html('<a href="%s">%s</a>' % (link, self.temporary_acting))
        else:
            return '-'

    temporary_acting_link.fget.short_description = 'ТВО'

    @property
    def candidate_link(self):
        if self.candidate:
            link = reverse("admin:personnel_serviceman_change", args=[self.candidate.id])
            return format_html('<a href="%s">%s</a>' % (link, self.candidate))
        else:
            return '-'

    candidate_link.fget.short_description = 'кандидат'

    @property
    def milspec(self):
        return self.position.milspec

    milspec.fget.short_description = 'ВОС'

    @property
    def position_category(self):
        return self.position.position_category

    position_category.fget.short_description = 'ШПК'

    @property
    def staff_order_qty(self):
        qsa = Acceptance.objects.filter(staff=self, status='2', order_daily__isnull=False)
        qsm = Movement.objects.filter(Q(staff_src=self) |
                                      Q(staff_dst=self), status='2', order_daily__isnull=False)
        qst = TakeOut.objects.filter(staff=self, status='2', order_daily__isnull=False)
        qsd = Dismissal.objects.filter(staff=self, status='2', order_daily__isnull=False)
        return qsa.count() + qsm.count() + qst.count() + qsd.count()

    staff_order_qty.fget.short_description = 'Наказів'

    @property
    def staff_order(self):
        if not self.serviceman:
            return None

        orders = []
        qsa = Acceptance.objects.filter(staff=self,
                                        status='2',
                                        order_daily__isnull=False).order_by('-order_daily__date')
        if qsa:
            orders.append(qsa.first().order_daily)
        qsm = Movement.objects.filter(Q(staff_src=self) |
                                      Q(staff_dst=self),
                                      status='2',
                                      order_daily__isnull=False).order_by('-order_daily__date')
        if qsm:
            orders.append(qsm.first().order_daily)
        qst = TakeOut.objects.filter(staff=self,
                                     status='2',
                                     order_daily__isnull=False).order_by('-order_daily__date')
        if qst:
            orders.append(qst.first().order_daily)
        qsd = Dismissal.objects.filter(staff=self,
                                       status='2',
                                       order_daily__isnull=False).order_by('-order_daily__date')
        if qsd:
            orders.append(qsd.first().order_daily)

        max_order = None
        if len(orders) > 0:
            max_order = max(orders, key=lambda order: order.date)

        return max_order

    staff_order.fget.short_description = 'Наказ на посаду'

    @property
    def staff_order_short_name(self):
        order = self.staff_order
        return order.short_name if order else '-'

    staff_order_short_name.fget.short_description = 'Наказ на посаду'


class ServicemanActionBase(models.Model):
    class Meta:
        abstract = True

    action_date = models.DateField(verbose_name='дата', default=django.utils.timezone.now, blank=False, null=False)
    report = models.ForeignKey('documents.Report', verbose_name='Рапорт', on_delete=models.SET_NULL,
                               blank=True, null=True)
    order_daily = models.ForeignKey('documents.Order', verbose_name='До добового наказу', on_delete=models.SET_NULL,
                                    blank=True, null=True,
                                    related_name='%(class)s_order_daily',
                                    # related_query_name='actions',
                                    limit_choices_to={'order_type': 1})
    serviceman = models.ForeignKey(Serviceman, on_delete=models.CASCADE, blank=False, null=True,
                                   verbose_name='військовослужбовець')
    comment = models.TextField(blank=True, null=True, verbose_name='коментар')
    user = models.ForeignKey(User, on_delete=models.PROTECT, blank=True, null=True, verbose_name='Користувач')

    @property
    def daily_order_short_name(self):
        return self.order_daily.short_name if self.order_daily else '-'

    daily_order_short_name.fget.short_description = 'Добовий наказ'

    @property
    def daily_order_link(self):
        if self.order_daily:
            link = reverse("admin:documents_order_change", args=[self.order_daily.id])
            return format_html('<a href="%s">%s</a>' % (link, self.daily_order_short_name))
        else:
            return '-'

    daily_order_link.fget.short_description = 'Добовий наказ'

    @property
    def daily_order_date(self):
        return self.order_daily.date_short if self.order_daily else self.action_date

    daily_order_date.fget.short_description = 'Дата добового наказу'


class StaffActionBase(ServicemanActionBase):
    class Meta:
        abstract = True

    class Status(models.TextChoices):
        NEW = "1", "НОВИЙ"
        DONE = "2", "ВИКОНАНО"
        CANCELED = "3", "СКАСОВАНО"

    order_rs = models.ForeignKey('documents.Order', verbose_name='РС Наказ (підстава)', on_delete=models.SET_NULL,
                                 blank=True, null=True, related_name='%(class)s_order_rs',
                                 limit_choices_to={'order_type': 3})
    status = models.CharField(max_length=2, verbose_name='статус', choices=Status.choices, default=Status.NEW)

    # def clean(self):
    #     print(f'StaffActionBase::clean, status={self.status}, pk={self.pk}')
    #     if self.status == StaffActionBase.Status.DONE and self.pk:
    #         raise ValidationError(f'Редагування запису зі статусом "{self.get_status_display()}" заборонено.')

    def clean(self):
        if not self.status == self.Status.NEW:  # allowed for NEW action only
            raise ValidationError('Редагування допускається лише у статусі "НОВИЙ"!')

    @property
    def report_short_name(self):
        return self.report.short_name if self.report else '-'

    report_short_name.fget.short_description = 'Рапорт'

    @property
    def saved_serviceman(self):
        return f'{self.serviceman}'

    saved_serviceman.fget.short_description = 'в/с (збережено)'  # 'військовослужбовець'

    @admin.display(boolean=True, description='РС наказ')
    def rs_present(self):
        return bool(self.order_rs)

    @property
    def rs_order_short_name(self):
        return self.order_rs.short_name if self.order_rs else '-'

    rs_order_short_name.fget.short_description = 'РС наказ'

    @property
    def daily_order_short_name(self):
        return self.order_daily.short_name if self.order_daily else '-'

    daily_order_short_name.fget.short_description = 'Добовий наказ'

    @property
    def daily_order_link(self):
        if self.order_daily:
            link = reverse("admin:documents_order_change", args=[self.order_daily.id])
            return format_html('<a href="%s">%s</a>' % (link, self.daily_order_short_name))
        else:
            return '-'

    daily_order_link.fget.short_description = 'Добовий наказ'

    @property
    def rs_order_link(self):
        if self.order_rs:
            link = reverse("admin:documents_order_change", args=[self.order_rs.id])
            return format_html('<a href="%s">%s</a>' % (link, self.rs_order_short_name))
        else:
            return '-'

    rs_order_link.fget.short_description = 'РС наказ'

    # @property
    # def daily_order_short_name(self):
    #     return self.order_daily.short_name if self.order_daily else '-'
    #
    # daily_order_short_name.fget.short_description = 'Добовий наказ'
    #
    # @property
    # def daily_order_link(self):
    #     if self.order_daily:
    #         link = reverse("admin:documents_order_change", args=[self.order_daily.id])
    #         return format_html('<a href="%s">%s</a>' % (link, self.daily_order_short_name))
    #     else:
    #         return '-'
    #
    # daily_order_link.fget.short_description = 'Добовий наказ'
    #
    # @property
    # def daily_order_date(self):
    #     return self.order_daily.date_short if self.order_daily else self.action_date
    #
    # daily_order_date.fget.short_description = 'Дата добового наказу'

    @property
    def status_rgb(self):
        if self.status == '1':
            return format_html(f'<b><span style="color:blue">{self.get_status_display()}</b>')
        elif self.status == '3':
            return format_html(f'<b><span style="color:red">{self.get_status_display()}</span></b>')
        else:
            return self.get_status_display()
        # return format_html("<b>{}</b>", self.get_status_display()) if self.status == '1' else self.get_status_display()

    status_rgb.fget.short_description = 'Статус'

    @property
    def basis(self):
        # return f'{self.order_rs if self.order_rs else ""}{", " if self.order_rs and self.report else ""}' \
        #        f'{"рапорт " + self.report.short_info if self.report else ""}'
        return f'{self.order_rs.name_verbose if self.order_rs else ""}' \
               f'{", " if self.order_rs else ""}' \
               f'рапорт {self.report.short_info if self.report else self.serviceman.in_genitive_short}'

    basis.fget.short_description = 'Підстава'

    @property
    def basis2(self):
        return f'{self.order_rs.name_verbose if self.order_rs else ""}' \
               f'{", " if self.order_rs and self.report else ""}' \
               f' {"рапорт " + self.report.short_info if self.report else ""}'

    basis2.fget.short_description = 'Підстава'

    @property
    def rs_order_in_ablative(self):
        result = f'{self.order_rs if self.order_rs else ""}'
        return result.replace('наказ', 'наказом')

    rs_order_in_ablative.fget.short_description = 'Підстава'


class Acceptance(StaffActionBase):
    class Meta:
        verbose_name = 'Прийом на посаду'
        verbose_name_plural = '1. Прийом на посаду'
        ordering = ['action_date']

    staff = models.ForeignKey('Staff', on_delete=models.SET_NULL, blank=True, null=True,
                              verbose_name='Штатна посада',
                              # limit_choices_to={'date_end__isnull': True}
                              # , limit_choices_to={'serviceman__isnull': True}
                              )
    reason = models.CharField(max_length=256, blank=True, null=True, verbose_name='Підстава')
    disposal = models.ForeignKey(ServicemanAtDisposal, on_delete=models.DO_NOTHING, blank=True, null=True,
                                 verbose_name='У розпорядження')

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, ' \
               f'{self.staff.short_name if self.staff else "у розпорядження"}'

    @property
    def staff_short_name(self):
        return f'{self.staff.short_name}'

    staff_short_name.fget.short_description = 'На штатну посаду/розпорядження'

    # @property
    # def staff_link(self):
    #     if self.staff:
    #         link = reverse("admin:personnel_staff_change", args=[self.staff.id])
    #         # return format_html('<a href="%s">%s</a>' % (link, self.staff_short_name))
    #         return format_html('<a href="%s">%s</a>' % (link,
    #                                                     self.staff if self.status == '1' else self.staff_short_name))
    #     else:
    #         return 'у розпорядження'
    #
    # staff_link.fget.short_description = 'На штатну посаду/розпорядження'

    @property
    def disposal_link(self):
        if self.disposal:
            link = reverse("admin:personnel_servicemanatdisposal_change", args=[self.disposal.id])
            return format_html('<a href="%s">%s</a>' % (link, self.disposal.short_name))
        else:
            return '-'

    disposal_link.fget.short_description = 'У розпорядження'

    @property
    def serviceman_staff_dst_bonus(self):
        return get_serviceman_staff_bonus(self.serviceman, self.staff)

    @property
    def basis(self):
        return f'{super().basis}{", " if super().basis and self.reason else ""}' \
               f'{self.reason if self.reason else ""}'

    basis.fget.short_description = 'Підстава'


class Movement(StaffActionBase):
    class Meta:
        verbose_name = 'Переміщення'
        verbose_name_plural = '2. Переміщення'
        ordering = ['action_date']

    staff_src = models.ForeignKey('Staff', related_name='movement_staff_src', on_delete=models.DO_NOTHING, blank=False,
                                  null=False, verbose_name='З штатної посади',
                                  limit_choices_to={'serviceman__isnull': False})
    staff_dst = models.ForeignKey('Staff', related_name='movement_staff_dst', on_delete=models.DO_NOTHING, blank=False,
                                  null=False, verbose_name='На штатну посаду'
                                  # , limit_choices_to={'serviceman__isnull': True}
                                  )

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.staff_src.short_name} -> ' \
               f'{self.staff_dst.short_name}'

    @property
    def staff_src_short_name(self):
        return f'{self.staff_src.short_name}'

    staff_src_short_name.fget.short_description = 'З штатної посади'

    @property
    def staff_dst_short_name(self):
        return f'{self.staff_dst.short_name}'

    staff_dst_short_name.fget.short_description = 'На штатної посади'

    @property
    def staff_src_link(self):
        link = reverse("admin:personnel_staff_change", args=[self.staff_src.id])
        return format_html('<a href="%s">%s</a>' % (link, self.staff_src_short_name))

    staff_src_link.fget.short_description = 'З штатної посади'

    @property
    def staff_dst_link(self):
        link = reverse("admin:personnel_staff_change", args=[self.staff_dst.id])
        return format_html('<a href="%s">%s</a>' % (link,
                                                    self.staff_dst if self.status=='1' else self.staff_dst_short_name))
        # return format_html('<a href="%s">%s</a>' % (link, self.staff_dst_short_name))

    staff_dst_link.fget.short_description = 'На штатну посаду'

    @property
    def serviceman_staff_dst_bonus(self):
        return get_serviceman_staff_bonus(self.serviceman, self.staff_dst)
        # return self.staff_dst.position.tariff.bonus2\
        #     if self.serviceman.service_term_years and self.serviceman.service_term_years >= 1\
        #     else self.staff_dst.position.tariff.bonus1


class TakeOut(StaffActionBase):
    class Meta:
        verbose_name = 'Поза штат'
        verbose_name_plural = '3. Поза штат'
        ordering = ['action_date']

    staff = models.ForeignKey('Staff', related_name='takeout_staff', on_delete=models.PROTECT, blank=False,
                              null=False, verbose_name='З штатної посади',
                              limit_choices_to={'serviceman__isnull': False})
    reason = models.CharField(max_length=4, verbose_name='Причина', choices=DisposalReason.choices,
                              default=DisposalReason.DOWNSIZE)
    disposal = models.ForeignKey(ServicemanAtDisposal, blank=True, null=True, on_delete=models.PROTECT,
                                 verbose_name='У розпорядженні')

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.staff_short_name}'

    @property
    def staff_short_name(self):
        return f'{self.staff.short_name}'

    staff_short_name.fget.short_description = 'З штатної посади'


    @property
    def disposal_link(self):
        if self.disposal:
            link = reverse("admin:personnel_servicemanatdisposal_change", args=[self.disposal.id])
            # return format_html('<a href="%s">%s</a>' % (link, self.disposal.short_name))
            return format_html('<a href="%s">%s</a>' % (link, f'{self.disposal.short_name} [{self.disposal.reason}]'))
        else:
            return '-'

    disposal_link.fget.short_description = 'У розпорядження'

    # @property
    # def staff_serviceman(self):
    #     return f'{self.staff.serviceman}'
    # staff_serviceman.fget.short_description = 'Військовослужбовець'


class Dismissal(StaffActionBase):
    class Meta:
        verbose_name = 'Виключення'
        verbose_name_plural = '4. Виключення зі списків'
        ordering = ['action_date']

    class Reason(models.TextChoices):
        MOVE = "1", "ПЕРЕВЕДЕННЯ"
        HEALTH = "2", "ЗА СТАНОМ ЗДОРОВ'Я"
        AGE = "3", "ЗА ВІКОМ"
        FAMILY = "4", "ЗА СІМЕЙНИМИ ОБСТАВИНАМИ"
        DEATH = "5", "У ЗВ'ЯЗКУ ЗІ СМЕРТЮ"
        ERDR = "6", "ПРИЗУПИНЕННЯ СЛУЖБИ (ЄРДР)"
        LAW = "7", "ЗА РІШЕННЯМ СУДУ"
        TERMCON = "8", "РОЗІРВАННЯ КОНТРАКТУ"

    move_new_position = models.TextField(verbose_name='на посаду до іншої в/ч (при ПЕРЕВЕДЕННІ) або РТЦК та СП (СМЕРТІ)',
                                         blank=True, null=True)
    vacation = models.BooleanField(default=False, verbose_name='Щорічна основна відпустка')
    vacation_additional = models.BooleanField(default=False, verbose_name='Додаткова відпустка')
    payment_for_health = models.BooleanField(default=False, verbose_name='Грошова допомога на оздоровлення')
    payment_for_aid = models.BooleanField(default=False, verbose_name='Матеріальна допомога')
    transport_docs = models.BooleanField(default=False, verbose_name='Військові перевізні документи')
    official_housing = models.BooleanField(default=False, verbose_name='Постійне або службове житло')
    staff = models.ForeignKey('Staff', on_delete=models.DO_NOTHING, blank=True, null=True,
                              verbose_name='З штатної посади (збережено)')
    reason = models.CharField(max_length=2, verbose_name='причина', choices=Reason.choices, default=Reason.MOVE)

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.get_reason_display()}'

    @property
    def staff_full_name(self):
        return f'{self.staff.full_name if self.staff else "-"}'

    @property
    def staff_short_name(self):
        return f'{self.staff.short_name if self.staff else "-"}'

    staff_short_name.fget.short_description = 'З штатної посади'

    @property
    def staff_link(self):
        if self.staff:
            link = reverse("admin:personnel_staff_change", args=[self.staff.id])
            return format_html('<a href="%s">%s</a>' % (link, self.staff_full_name))
        else:
            return self.serviceman.at_disposal_text

    staff_link.fget.short_description = 'З штатної посади'

    @property
    def serviceman_staff_bonus(self):
        return get_serviceman_staff_bonus(self.serviceman, self.staff)
        # return self.staff.position.tariff.bonus2\
        #     if self.serviceman.service_term_years and self.serviceman.service_term_years >= 1\
        #     else self.staff.position.tariff.bonus1

    @property
    def serviceman_commissariat(self):
        return self.serviceman.commissariat if self.serviceman.commissariat else '[вкажіть РТЦК та СП у картці в/с]'

    @property
    def move_new_position_ext(self):
        return self.move_new_position if self.move_new_position else \
            ('[вкажіть нову посаду]' if self.reason == self.Reason.MOVE else '[вкажіть РТЦК та СП]')


class TemporaryActing(StaffActionBase):
    class Meta:
        verbose_name = 'Допуск до ТВО'
        verbose_name_plural = '5. Допуск до ТВО'
        ordering = ['action_date']

    staff = models.ForeignKey('Staff', related_name='temporary_acting_staff', on_delete=models.DO_NOTHING,
                              blank=False, null=False, verbose_name='На штатну посаду')

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.staff.short_name}'

    @property
    def staff_short_name(self):
        return f'{self.staff.short_name if self.staff else "-"}'

    staff_short_name.fget.short_description = 'На штатну посаду'

    # @property
    # def serviceman_staff_print_name(self):
    #     return f'{self.serviceman.staff_print_name if self.serviceman else "-"}'
    #
    # serviceman_staff_print_name.fget.short_description = 'Штатна посада (поточна)'
    #

    @admin.display(boolean=True, description='Активна?')
    def is_active(self):
        return bool(self.serviceman == self.staff.temporary_acting)


class AssignRank(StaffActionBase):
    class Meta:
        verbose_name = 'Присвоєння звання'
        verbose_name_plural = '6. Присвоєння звання'
        ordering = ['action_date']

    class AssignType(models.TextChoices):
        PRIMARY = "0", "ПЕРВИННЕ"
        REGULAR = "1", "ЧЕРГОВЕ"
        EXTRA = "2", "ПОЗАЧЕРГОВЕ"
        RECERT = "3", "ПЕРЕАТЕСТАЦІЯ"

    type = models.CharField(max_length=2, verbose_name='тип', choices=AssignType.choices, default=AssignType.REGULAR)
    rank_src = models.ForeignKey('Rank', related_name='assignrank_rank_src', on_delete=models.DO_NOTHING,
                                 blank=False, null=False, verbose_name='початкове звання')
    rank_dst = models.ForeignKey('Rank', related_name='assignrank_rank_dst', on_delete=models.DO_NOTHING,
                                 blank=False, null=False, verbose_name='звання')
    order_rs_src = models.ForeignKey('documents.Order', verbose_name='РС Наказ (попередній)', on_delete=models.SET_NULL,
                                 blank=True, null=True)

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.rank_src} - {self.rank_dst}'


class Payout(StaffActionBase):
    class Meta:
        verbose_name = 'Виплати'
        verbose_name_plural = '7. Виплати'
        ordering = ['action_date']

    class PayoutType(models.TextChoices):
        HEALTH = "HEA", "ГДО (грошова допомога для оздоровлення)"
        HOUSE = "HOU", "МД (матеріальна допомога для вирішення соціально-побутових питань)"

    type = models.CharField(max_length=3, verbose_name='тип', choices=PayoutType.choices, default=PayoutType.HEALTH)
    amount = models.DecimalField(verbose_name='Сума виплати', max_digits=10, decimal_places=2, default=0,
                                 blank=False, null=False)

    def __str__(self):
        return f'{self.action_date.strftime("%d.%m.%Y")}, {self.serviceman.title}, {self.amount} [{self.get_type_display()}]'

    @property
    def amount_in_words(self):
        return f'{get_integer_part_as_text(self.amount)} ({int_amount_to_words(self.amount)}) грн. {get_fractional_part_as_text(self.amount)} коп.'
    amount_in_words.fget.short_description = 'Сума прописом'

    # @property
    # def amount_short(self):
    #     return f'{int(self.amount)} грн. {get_fractional_part_as_text(self.amount)} коп.'
    # amount_short.fget.short_description = 'Сума'


class Mission(models.Model):
    class Meta:
        verbose_name = 'Бойова місія: опис'
        verbose_name_plural = 'Бойові місії: опис'
        ordering = ['mission_id']

    # class Status(models.TextChoices):
    #     NEW = "1", "НОВИЙ"
    #     DONE = "2", "ВИКОНАНО"
    #     CANCELED = "3", "СКАСОВАНО"

    mission_id = models.PositiveIntegerField(verbose_name='номер', unique=True, blank=True, null=True)
    name = models.CharField(verbose_name='назва', max_length=256)
    description = models.TextField(verbose_name='опис', blank=True, null=True)
    start_date = models.DateField(verbose_name='дата початку', default=django.utils.timezone.now, blank=False, null=False)
    end_date = models.DateField(verbose_name='дата завершення', blank=True, null=True)
    reason = models.TextField(verbose_name='Підстави (БР, накази, тощо)', blank=True, null=True)
    place = models.TextField(verbose_name='Місце (область, район, населений пункт)', blank=True, null=True)
    user = models.ForeignKey(User, verbose_name='Користувач', on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        return f'{self.mission_id} - {self.name} ({self.status}), {self.start_date.strftime("%d.%m.%Y")}'

    @property
    def status(self):
        try:
            if self.start_date > datetime.today().date():
                return 'ЗАПЛАНОВАНА'
            elif self.end_date and self.end_date < datetime.today().date():
                return 'ЗАВЕРШЕНА'
            else:
                return 'АКТИВНА'
        except Exception as ex:
            return '-'

    status.fget.short_description = 'Статус'


class MissionParticipant(models.Model):
    class Meta:
        verbose_name = 'Бойові місії: учасники'
        verbose_name_plural = 'Бойові місії: учасники'
        # ordering = ['serviceman']

    mission = models.ForeignKey('Mission', on_delete=models.PROTECT, blank=False, null=False,
                                verbose_name='Бойова місія', related_name='mission_participant')
    serviceman = models.ForeignKey('Serviceman', on_delete=models.CASCADE, blank=False, null=False,
                                   verbose_name='військовослужбовець', related_name='mission_serviceman')
    comment = models.TextField(verbose_name='коментар', blank=True, null=True)
    start_date = models.DateField(verbose_name='дата початку', default=django.utils.timezone.now, blank=False, null=False)
    end_date = models.DateField(verbose_name='дата завершення', blank=True, null=True)
    user = models.ForeignKey(User, verbose_name='Користувач', on_delete=models.PROTECT, blank=True, null=True)

    def __str__(self):
        return f'{self.id} - {self.mission.name}, {self.serviceman.full_name_upper}'

    @property
    def staff_short_name(self):
        return f'{self.serviceman.staff_serviceman.short_name if hasattr(self.serviceman, "staff_serviceman") else "-"}'

    # @property
    # def staff_link(self):
    #     if hasattr(self.serviceman, "staff_serviceman"):
    #         link = reverse("admin:personnel_staff_change", args=[self.serviceman.staff_serviceman.id])
    #         return format_html('<a href="%s">%s</a>' % (link, self.staff_short_name))
    #     else:
    #         return '-'
    #
    # staff_link.fget.short_description = 'Штат'

    @property
    def on_vacation(self):
        res = Vacation.objects.filter(serviceman=self.serviceman,
                                      order_out__isnull=False,
                                      order_out__date__lt=datetime.today().date(),
                                      order_in__isnull=True
                                      ).count()
        return '+' if res > 0 else ''
    on_vacation.fget.short_description = 'Вп'

    @property
    def on_trip(self):
        res = Trip.objects.filter(serviceman=self.serviceman,
                                  order_out__isnull=False,
                                  order_out__date__lt=datetime.today().date(),
                                  order_in__isnull=True
                                  ).count()
        return '+' if res > 0 else ''
    on_trip.fget.short_description = 'Вр'

    @property
    def on_hospitalization(self):
        res = Hospitalization.objects.filter(serviceman=self.serviceman,
                                             order_out__isnull=False,
                                             order_out__date__lt=datetime.today().date(),
                                             order_in__isnull=True
                                             ).count()
        return '+' if res > 0 else ''
    on_hospitalization.fget.short_description = 'Лк'

    @property
    def is_lost(self):
        res = Losses.objects.filter(serviceman=self.serviceman,
                                    order_daily__isnull=False,
                                    order_daily__date__lte=datetime.today().date(),
                                    order_daily_in__isnull=True
                                    ).count()
        return '+' if res > 0 else ''
    is_lost.fget.short_description = 'Вт'


class Import(models.Model):
    class Meta:
        verbose_name = 'Імпорт'
        verbose_name_plural = 'Імпорт'
        ordering = ['id']

    class Type(models.TextChoices):
        SERVICEMAN = "1", "ВІЙСЬКОВОСЛУЖБОВЦІ"
        MISSION_PART = "2", "УЧАСНИКИ МІСІЇ"
        DISPOSAL = "3", "РОЗПОРЯДНИКИ"
        SERVICE_TERM = "4", "ВИСЛУГА РОКІВ"
        SERVICE_PERIODS = "5", "ПЕРІОДИ СЛУЖБИ ТА ОСВІТА"
        LOSSES = "6", "ВТРАТИ"
        STAFF = "7", "ШТАТ"
        PAYOUT = "8", "ВИПЛАТИ"
        ALL_STAFF = "9", "ІМПОРТ ШПС (ШТАТ І ВС)"

    date = models.DateField(verbose_name='дата', default=django.utils.timezone.now, blank=False, null=False)
    type = models.CharField(verbose_name='тип', max_length=2, choices=Type.choices, default=Type.SERVICEMAN)
    description = models.TextField(verbose_name='опис', blank=True, null=True)
    save_data = models.BooleanField(default=False, verbose_name='записати дані (інакше тільки перевірка)')
    file = models.FileField(upload_to='Serviceman', blank=True, null=True, verbose_name='файл')
    user = models.ForeignKey(User, verbose_name='Користувач', on_delete=models.DO_NOTHING, blank=True, null=True)

    def __str__(self):
        return f'{self.id}, тип: {self.get_type_display()}, {self.date.strftime("%d.%m.%Y")}'


class Losses(ServicemanActionBase):
    class Type(models.TextChoices):
        DEATH = "DEA", "ПОМЕР"
        COMBAT_DEATH = "CDEA", "ЗАГИНУВ"
        MISSING = "MIS", "ЗНИК БЕЗВІСТИ"
        CAPTIVITY = "CAP", "ПОЛОН"
        OTHER = "OTH", "ІНШІ"
    class Meta:
        verbose_name = 'втрати'
        verbose_name_plural = 'втрати'

    type = models.CharField(max_length=4, verbose_name='Тип', choices=Type.choices, default=Type.OTHER)
    loss_date = models.DateField(verbose_name='дата втрати')
    loss_place = models.CharField(verbose_name='місце втрати', max_length=1000, blank=True, null=True)
    mission = models.ForeignKey(Mission, verbose_name='Бойова місія', on_delete=models.PROTECT,
                                blank=True, null=True)
    file1 = models.FileField(upload_to='Losses', verbose_name='файл (1)', blank=True, null=True)
    file2 = models.FileField(upload_to='Losses', verbose_name='файл (2)', blank=True, null=True)
    description = models.TextField(blank=True, null=True, verbose_name='опис події')
    report_in = models.ForeignKey('documents.Report', verbose_name='Рапорт (закінчення)', on_delete=models.SET_NULL,
                                  related_name='%(class)s_report_in',
                                  blank=True, null=True)
    order_daily_in = models.ForeignKey('documents.Order', verbose_name='Добовий наказ (закінчення)', on_delete=models.SET_NULL,
                                       blank=True, null=True, related_name='%(class)s_order_daily_in',
                                       limit_choices_to={'order_type': 1})

    def __str__(self):
        return f'{self.id}, {self.loss_date.strftime("%d.%m.%Y")}, {self.get_type_display()}, {self.serviceman.title}'

    @property
    def short_loss_date(self):
        return self.loss_date.strftime("%d.%m.%Y")

    @property
    def basis(self):
        return f'{"рапорт " + self.report.short_info if self.report else ""}'

    basis.fget.short_description = 'Підстава'

    @property
    def daily_order_in_short_name(self):
        return self.order_daily_in.short_name if self.order_daily_in else '-'

    daily_order_in_short_name.fget.short_description = 'Добовий наказ (закінчення)'

    @property
    def daily_order_in_link(self):
        if self.order_daily_in:
            link = reverse("admin:documents_order_change", args=[self.order_daily_in.id])
            return format_html('<a href="%s">%s</a>' % (link, self.daily_order_in_short_name))
        else:
            return '-'

    daily_order_in_link.fget.short_description = 'Добовий наказ (закінчення)'
