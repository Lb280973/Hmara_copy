from django.urls import path

from .views import shifts_view, count_view

urlpatterns = [
    path('shifts', shifts_view),
    path('count', count_view),
]
