import logging
from collections import defaultdict

from django.db.models import Q

from documents.models import *
from datetime import datetime

logger = logging.getLogger(__name__)


class Counter:
    """
    Used to count personnel in units
    """
    units = None
    counter = defaultdict()
    subtotals_unit_id = -100
    disposals_unit_id = -1000
    totals_unit_id = -2000

    def __init__(self):
        logger.info('building "БЧС"')
        self.counter.clear()
        self.set_units()
        self.set_counts()

    def set_counts(self):
        self.get_staff_count()
        self.get_trips()
        self.get_vacations()
        self.get_hospitalizations()
        self.get_arrests()
        self.get_losses()
        self.get_illegally_absent()
        self.get_totals()

    def set_units(self):
        from personnel.models import UnitCombatGroup  #Unit,
        self.units = [unit for unit in UnitCombatGroup.objects.all()]
        # # subtotals
        # subtotals_unit = UnitCombatGroup(id=self.subtotals_unit_id, full_name="Всього (штат)")
        # self.units.append(subtotals_unit)
        # # disposals
        # disposals_unit = UnitCombatGroup(id=self.disposals_unit_id, full_name="У розпорядженні")
        # self.units.append(disposals_unit)
        # # totals
        # totals_unit = UnitCombatGroup(id=self.totals_unit_id, full_name="Всього")
        # self.units.append(totals_unit)
        for unit in self.units:
            self.counter[unit.id] = {
                'type': 'unit',
                'full_name': unit.full_name,
                'staff_all': {'count': 0, 'civil': 0, 'link': ''},
                'staff_list': {'count': 0, 'link': ''},
                'posture': {'percentage': 0},
                'trips': {'count': 0, 'accompanied': 0, 'link': ''},
                'vacations': {'count': 0, 'link': ''},
                'hospitalizations': {'count': 0, 'link': ''},
                'illa': {'count': 0, 'link': ''},
                'arrest': {'count': 0, 'link': ''},
                'losses': {'count': 0, 'link': ''},
                'present': {'count': 0, 'link': ''},
            }
        # subtotals
        self.counter[self.subtotals_unit_id] = {
            'type': 'subtotal',
            'full_name': format_html(f'<b><span style="color:blue">Всього (штат)</span></b>'),
            'staff_all': {'count': 0, 'civil': 0, 'link': ''},
            'staff_list': {'count': 0, 'link': ''},
            'posture': {'percentage': 0},
            'trips': {'count': 0, 'accompanied': 0, 'link': ''},
            'vacations': {'count': 0, 'link': ''},
            'hospitalizations': {'count': 0, 'link': ''},
            'illa': {'count': 0, 'link': ''},
            'arrest': {'count': 0, 'link': ''},
            'losses': {'count': 0, 'link': ''},
            'present': {'count': 0, 'link': ''},
        }
        # disposals
        self.counter[self.disposals_unit_id] = {
            'type': 'disposal',
            'full_name': 'У розпорядженні',
            'staff_list': {'count': 0, 'link': ''},
            'trips': {'count': 0, 'accompanied': 0, 'link': ''},
            'vacations': {'count': 0, 'link': ''},
            'hospitalizations': {'count': 0, 'link': ''},
            'illa': {'count': 0, 'link': ''},
            'arrest': {'count': 0, 'link': ''},
            'losses': {'count': 0, 'link': ''},
            'present': {'count': 0, 'link': ''},
        }
        # totals
        self.counter[self.totals_unit_id] = {
            'type': 'total',
            'full_name': format_html(f'<b><span style="color:blue">Всього</span></b>'),
            'staff_all': {'count': 0, 'civil': 0, 'link': ''},
            'staff_list': {'count': 0, 'link': ''},
            'posture': {'percentage': 0},
            'trips': {'count': 0, 'accompanied': 0, 'link': ''},
            'vacations': {'count': 0, 'link': ''},
            'hospitalizations': {'count': 0, 'link': ''},
            'illa': {'count': 0, 'link': ''},
            'arrest': {'count': 0, 'link': ''},
            'losses': {'count': 0, 'link': ''},
            'present': {'count': 0, 'link': ''},
        }

    @staticmethod
    def get_link(module, item, unit_id, filt=''):
        if module == 'personnel':
            if unit_id:
                return f'/admin/{module}/{item}/?{filt}&unit_combat_group={unit_id}'
            else:
                return f'/admin/{module}/{item}/?{filt}'
        else:
            if unit_id:
                return f'/admin/{module}/{item}/?status=progress&unit_combat_group={unit_id}'
            else:
                return f'/admin/{module}/{item}/?status=progress'
    def get_staff_count(self):
        from personnel.models import Staff
        from personnel.models import ServicemanAtDisposal

        for unit in self.units:
            all_count = Staff.objects.filter(
                Q(date_end__isnull=True) |
                Q(date_end__gte=datetime.today()), # |
                #Q(serviceman__isnull=False),
                date_start__lte=datetime.today(),
                unit__combat_group__id=unit.id
            ).exclude(position__position_category__rank_level__isnull=True).count() # 'Цивільна особа'
            # ).exclude(position__position_category__name = 'Цивільна особа').count()
            civil_count = Staff.objects.filter(
                Q(date_end__isnull=True) |
                Q(date_end__gte=datetime.today()), # |
                #Q(serviceman__isnull=False),
                date_start__lte=datetime.today(),
                unit__combat_group__id=unit.id,
                position__position_category__rank_level__isnull=True # 'Цивільна особа'
            ).count()
            list_count = Staff.objects.filter(
                serviceman__isnull=False,
                unit__combat_group__id=unit.id
            ).count()
            # in staff
            self.counter[unit.id]['staff_all']['count'] = all_count
            self.counter[unit.id]['staff_all']['civil'] = civil_count
            self.counter[unit.id]['staff_all']['link'] = self.get_link('personnel', 'staff', unit.id, 'staff_active=active')
            # in list
            self.counter[unit.id]['staff_list']['count'] = list_count
            self.counter[unit.id]['staff_list']['link'] = self.get_link('personnel', 'staff', unit.id, 'in_staff=staff&staff_active=active')
            # posture
            if all_count > 0:
                self.counter[unit.id]['posture']['percentage'] = round((list_count / all_count * 100), 2)
            else:
                self.counter[unit.id]['posture']['percentage'] = 0

        # disposals
        qs = ServicemanAtDisposal.objects.filter(
            order_out__isnull=False,
            order_out__date__lte=datetime.today().date(),
            order_in__isnull=True)
        self.counter[self.disposals_unit_id]['staff_list']['count'] = qs.count()
        self.counter[self.disposals_unit_id]['staff_list']['link'] = self.get_link('personnel',
                                                                                   'servicemanatdisposal',
                                                                                   None,
                                                                                   'status=progress')

    def get_trips(self):
        for unit in self.units:
            qs = Trip.objects.filter(serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                                     order_out__isnull=False,
                                     order_out__date__lte=datetime.today().date(),
                                     order_in__isnull=True
                                     )
            trip_count = qs.count()
            self.counter[unit.id]['trips']['count'] += trip_count
            self.counter[unit.id]['trips']['link'] = self.get_link('documents', 'trip', unit.id)
            for trip in qs:
                for serviceman in trip.accompanies.all():
                    if hasattr(serviceman, "staff_serviceman"):
                        self.counter[serviceman.staff_serviceman.unit.combat_group.id]['trips']['accompanied'] += 1
                    else:
                        self.counter[self.disposals_unit_id]['trips']['accompanied'] += 1
        # count disposals
        qs = Trip.objects.filter(serviceman__staff_serviceman__isnull=True,
                                 order_out__isnull=False,
                                 order_out__date__lte=datetime.today().date(),
                                 order_in__isnull=True
                                 )
        self.counter[self.disposals_unit_id]['trips']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['trips']['accompanied'] = 0  #+= qs.count()
        self.counter[self.disposals_unit_id]['trips']['link'] = '' #self.get_link('documents', 'trip', unit.id)

        # count totals
        for unit in self.units:
            self.counter[unit.id]['trips']['total'] = self.counter[unit.id]['trips']['count'] + \
                                                      self.counter[unit.id]['trips']['accompanied']
        self.counter[self.disposals_unit_id]['trips']['total'] = \
            self.counter[self.disposals_unit_id]['trips']['count'] + \
            self.counter[self.disposals_unit_id]['trips']['accompanied']

    def get_vacations(self):
        for unit in self.units:
            self.counter[unit.id]['vacations']['count'] = Vacation.objects.filter(
                serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                order_out__isnull=False,
                order_out__date__lte=datetime.today().date(),
                order_in__isnull=True
            ).count()
            self.counter[unit.id]['vacations']['link'] = self.get_link('documents', 'vacation', unit.id)
        # count disposals
        qs = Vacation.objects.filter(serviceman__staff_serviceman__isnull=True,
                                     order_out__isnull=False,
                                     order_out__date__lte=datetime.today().date(),
                                     order_in__isnull=True
                                     )
        self.counter[self.disposals_unit_id]['vacations']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['vacations']['link'] = '' #self.get_link('documents', 'vacation', unit.id)


    def get_hospitalizations(self):
        for unit in self.units:
            self.counter[unit.id]['hospitalizations']['count'] = Hospitalization.objects.filter(
                serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                order_out__isnull=False,
                order_out__date__lte=datetime.today().date(),
                order_in__isnull=True
            ).count()
            self.counter[unit.id]['hospitalizations']['link'] = self.get_link('documents', 'hospitalization', unit.id)
        # count disposals
        qs = Hospitalization.objects.filter(serviceman__staff_serviceman__isnull=True,
                                     order_out__isnull=False,
                                     order_out__date__lte=datetime.today().date(),
                                     order_in__isnull=True
                                     )
        self.counter[self.disposals_unit_id]['hospitalizations']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['hospitalizations']['link'] = '' #self.get_link('documents', 'vacation', unit.id)


    def get_arrests(self):
        for unit in self.units:
            self.counter[unit.id]['arrest']['count'] = Arrest.objects.filter(
                serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                order_out__isnull=False,
                order_out__date__lte=datetime.today().date(),
                order_in__isnull=True
            ).count()
            self.counter[unit.id]['arrest']['link'] = self.get_link('documents', 'arrest', unit.id)
        # count disposals
        qs = Arrest.objects.filter(
            serviceman__staff_serviceman__isnull=True,
            order_out__isnull=False,
            order_out__date__lte=datetime.today().date(),
            order_in__isnull=True
        )
        self.counter[self.disposals_unit_id]['arrest']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['arrest']['link'] = '' #self.get_link('documents', 'vacation', unit.id)


    def get_losses(self):
        for unit in self.units:
            from personnel.models import Losses
            self.counter[unit.id]['losses']['count'] = Losses.objects.filter(
                serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                order_daily__isnull=False,
                order_daily__date__lte=datetime.today().date(),
                order_daily_in__isnull=True
            ).count()
            self.counter[unit.id]['losses']['link'] = self.get_link('personnel', 'losses', unit.id)
        # count disposals
        # qs = Losses.objects.filter(
        #     serviceman__staff_serviceman__isnull=True,
        #     order_daily__isnull=False,
        #     order_daily__date__lte=datetime.today().date(),
        #     order_daily_in__isnull=True
        # )
        qs = Losses.objects.filter(
            serviceman__serviceman_at_disposal__isnull=False,
            serviceman__serviceman_at_disposal__order_out__isnull=False,
            serviceman__serviceman_at_disposal__order_out__date__lte=datetime.today().date(),
            serviceman__serviceman_at_disposal__order_in__isnull=True,
            serviceman__excluded=False
        )
        self.counter[self.disposals_unit_id]['losses']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['losses']['link'] = self.get_link('personnel', 'losses',
                                                                               None, 'staff=disposal')


    def get_illegally_absent(self):
        for unit in self.units:
            from personnel.models import ServicemanIllegallyAbsent
            self.counter[unit.id]['illa']['count'] = ServicemanIllegallyAbsent.objects.filter(
                serviceman__staff_serviceman__unit__combat_group__id=unit.id,
                order_out__isnull=False,
                order_out__date__lte=datetime.today().date(),
                order_in__isnull=True
            ).count()
            self.counter[unit.id]['illa']['link'] = self.get_link('personnel', 'servicemanillegallyabsent', unit.id,
                                                                  'status=progress')
        # count disposals
        qs = ServicemanIllegallyAbsent.objects.filter(
            serviceman__staff_serviceman__isnull=True,
            order_out__isnull=False,
            order_out__date__lte=datetime.today().date(),
            order_in__isnull=True
        )
        self.counter[self.disposals_unit_id]['illa']['count'] += qs.count()
        self.counter[self.disposals_unit_id]['illa']['link'] = self.get_link('personnel', 'servicemanillegallyabsent',
                                                                             None, 'staff=disposal&status=progress')


    def get_totals(self):  # refactor me!
        all_count = sum(data['staff_all']['count'] for data in self.counter.values() if 'staff_all' in data)
        civil_count = sum(data['staff_all']['civil'] for data in self.counter.values() if 'staff_all' in data)
        list_count = sum(data['staff_list']['count'] for data in self.counter.values())
        disp_count = self.counter[self.disposals_unit_id]['staff_list']['count']
        total_trip = sum(data['trips']['total'] for data in self.counter.values() if 'total' in data['trips'])
        total_vaca = sum(data['vacations']['count'] for data in self.counter.values())
        total_hosp = sum(data['hospitalizations']['count'] for data in self.counter.values())
        total_arst = sum(data['arrest']['count'] for data in self.counter.values())
        total_loss = sum(data['losses']['count'] for data in self.counter.values())
        total_illa = sum(data['illa']['count'] for data in self.counter.values())
        total_present = list_count - total_trip - total_vaca - total_hosp - total_arst - total_loss - total_illa
        # present count
        for unit in self.units:
            self.counter[unit.id]['present']['count'] = self.counter[unit.id]['staff_list']['count'] - \
                                                        self.counter[unit.id]['trips']['count'] - \
                                                        self.counter[unit.id]['vacations']['count'] - \
                                                        self.counter[unit.id]['hospitalizations']['count'] - \
                                                        self.counter[unit.id]['illa']['count'] - \
                                                        self.counter[unit.id]['arrest']['count'] - \
                                                        self.counter[unit.id]['losses']['count']
        # disposal present
        disposal_present = self.counter[self.disposals_unit_id]['staff_list']['count'] - \
                                                    self.counter[self.disposals_unit_id]['trips']['count'] - \
                                                    self.counter[self.disposals_unit_id]['vacations']['count'] - \
                                                    self.counter[self.disposals_unit_id]['hospitalizations']['count'] - \
                                                    self.counter[self.disposals_unit_id]['illa']['count'] - \
                                                    self.counter[self.disposals_unit_id]['arrest']['count'] - \
                                                    self.counter[self.disposals_unit_id]['losses']['count']
        self.counter[self.disposals_unit_id]['present']['count'] = disposal_present
        # subtotals

        subtotals_posture = 0
        if all_count > 0:
            # minus disposals!
            subtotals_posture = round(((list_count - disp_count) / all_count * 100), 2)

        self.counter[self.subtotals_unit_id] = {
            'type': 'subtotal',
            'full_name': format_html(f'<b><span style="color:blue">Всього (штат)</span></b>'),
            'staff_all': {'count': all_count, 'civil': civil_count,
                          'link': self.get_link('personnel', 'staff', None, 'rank_level=no_civil&staff_active=active')},
            'staff_list': {'count': list_count - disp_count, 'link': ''},
            'posture': {'percentage': subtotals_posture},
            'trips': {'count': total_trip - self.counter[self.disposals_unit_id]['trips']['count'],
                      'link': self.get_link('documents', 'trip', None)},
            'vacations': {'count': total_vaca - self.counter[self.disposals_unit_id]['vacations']['count'],
                          'link': self.get_link('documents', 'vacation', None)},
            'hospitalizations': {'count': total_hosp - self.counter[self.disposals_unit_id]['hospitalizations']['count'],
                                 'link': self.get_link('documents', 'hospitalization', None)},
            'illa': {'count': total_illa - self.counter[self.disposals_unit_id]['illa']['count'],
                     'link': self.get_link('personnel', 'servicemanillegallyabsent', None, 'staff=staff&status=progress')},
            'arrest': {'count': total_arst - self.counter[self.disposals_unit_id]['arrest']['count'],
                       'link': self.get_link('documents', 'arrest', None)},
            'losses': {'count': total_loss - self.counter[self.disposals_unit_id]['losses']['count'],
                       'link': self.get_link('personnel', 'losses', None, 'staff=staff')},
            'present': {'count': total_present - disposal_present, 'link': ''},
        }
        # totals
        self.counter[self.totals_unit_id] = {
            'type': 'total',
            'full_name': format_html(f'<b><span style="color:blue">Всього</span></b>'),
            'staff_all': {'count': all_count, 'civil': civil_count, 'link': self.get_link('personnel', 'staff', None, 'rank_level=no_civil&staff_active=active')},
            'staff_list': {'count': list_count, 'link': self.get_link('personnel', 'serviceman', None, 'staff=in_list')},
            'posture': {'percentage': subtotals_posture},
            'trips': {'count': total_trip, 'link': self.get_link('documents', 'trip', None)},
            'vacations': {'count': total_vaca, 'link': self.get_link('documents', 'vacation', None)},
            'hospitalizations': {'count': total_hosp, 'link': self.get_link('documents', 'hospitalization', None)},
            'illa': {'count': total_illa, 'link': self.get_link('personnel', 'servicemanillegallyabsent', None, 'status=progress')},
            'arrest': {'count': total_arst, 'link': self.get_link('documents', 'arrest', None)},
            'losses': {'count': total_loss, 'link': self.get_link('personnel', 'losses', None)}, #???
            'present': {'count': total_present, 'link': ''},
        }
