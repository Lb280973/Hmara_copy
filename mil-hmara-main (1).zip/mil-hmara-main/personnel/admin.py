import os

from django import forms
from admin_auto_filters.filters import AutocompleteFilter
from django.contrib import messages
from django.db.models import F
from import_export import resources, fields
from import_export.admin import ExportActionModelAdmin
from import_export.fields import Field
from import_export.widgets import ForeignKeyWidget, DateWidget

from conf import settings
from documents.admin import logger
from documents.models import Order, Report
from utils import filter_name
# from weapon.models import Weapon
from .models import *
from .views import shifts_view, get_staff_position_display
from personnel.mixins.mixins import PersonnelFileMixin, check_serviceman_at_disposal_and_raise, \
    check_serviceman_illegally_absent_and_raise, check_serviceman_attached_and_raise

from django.contrib.auth.signals import user_logged_in, user_logged_out
from django.dispatch import receiver


@receiver(user_logged_in)
def log_user_login(sender, request, user, **kwargs):
    logger.info(f'[{user.username}] увійшов до системи')


@receiver(user_logged_out)
def log_user_logout(sender, request, user, **kwargs):
    logger.info(f'[{user.username}] вийшов із системи')


class UnitFilter(AutocompleteFilter):
    title = 'підрозділом (точно)'
    field_name = 'unit'
    rel_model = Staff
    parameter_name = 'unit'


class ParentUnitFilter(AutocompleteFilter):
    title = 'підпорядкуванням'
    field_name = 'parent_unit'
    rel_model = Staff
    parameter_name = 'unit'


class OrderDailyFilter(AutocompleteFilter):
    title = 'добовим наказом'
    field_name = 'order_daily'
    # rel_model = Acceptance
    parameter_name = 'order_daily'


class OrderDailyOutFilter(AutocompleteFilter):
    title = 'добовим наказом (початок)'
    field_name = 'order_out'
    parameter_name = 'order_out'


class OrderDailyInFilter(AutocompleteFilter):
    title = 'добовим наказом (закінчення)'
    field_name = 'order_in'
    parameter_name = 'order_in'


class OrderRsFilter(AutocompleteFilter):
    title = 'РС наказом'
    field_name = 'order_rs'
    parameter_name = 'order_rs'


class StaffUnitCombatGroupFilter(admin.SimpleListFilter):
    title = 'підрозділом БЧС'
    parameter_name = 'unit_combat_group'

    def lookups(self, request, model_admin):
        units = UnitCombatGroup.objects.order_by('group_id')
        return [(c.id, c.name) for c in units]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(unit__combat_group__id__exact=self.value())
        else:
            return queryset.all()


class UnitCombatGroupFilter(admin.SimpleListFilter):
    title = 'підрозділом БЧС'
    parameter_name = 'unit_combat_group'

    def lookups(self, request, model_admin):
        units = UnitCombatGroup.objects.order_by('group_id')
        return [(c.id, c.name) for c in units]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(serviceman__staff_serviceman__unit__combat_group__id__exact=self.value())
        else:
            return queryset.all()


# class StaffUnitContentFilter(admin.SimpleListFilter):
#     title = 'підрозділом (з підпорядкуванням)'
#     parameter_name = 'unit_id'
#
#     def lookups(self, request, model_admin):
#         units = Unit.objects.order_by('unit_id')
#         return [(c.id, c.name) for c in units]
#
#     def queryset(self, request, queryset):
#         if self.value():
#             return queryset.filter(Q(unit__id__exact=self.value()) | Q(unit__parent_unit__exact=self.value()) |
#                                    Q(unit__parent_unit__parent_unit__exact=self.value()))
#         else:
#             return queryset.all()


class UnitContentFilter(admin.SimpleListFilter):
    title = 'підрозділом (з підпорядкуванням)'
    parameter_name = 'unit_id'

    def lookups(self, request, model_admin):
        units = Unit.objects.order_by('unit_id')
        return [(c.id, c.name) for c in units]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(Q(id__exact=self.value()) | Q(parent_unit__exact=self.value()) |
                                   Q(parent_unit__parent_unit__exact=self.value()))
        else:
            return queryset.all()


class UnitDisposalFilter(admin.SimpleListFilter):
    title = 'підрозділом підпорядкування'
    parameter_name = 'unit'

    def lookups(self, request, model_admin):
        ids = ServicemanAtDisposal.objects.values_list('unit__id', flat=True).distinct()
        units = Unit.objects.filter(id__in=ids)
        return [(c.id, c.name) for c in units]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(unit_id__exact=self.value())
        else:
            return queryset.all()


class RsPresentFilter(admin.SimpleListFilter):
    title = 'наявністю РС наказу'
    parameter_name = 'rs_present'

    def lookups(self, request, model_admin):
        return (
            ('Yes', 'ТАК'),
            ('No', 'НІ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'Yes':
            return queryset.filter(order_rs__isnull=False)
        if self.value() == 'No':
            return queryset.filter(order_rs__isnull=True)
        else:
            return queryset.all()


class AtDisposalFilter(admin.SimpleListFilter):
    title = 'посадою/у розпорядження'
    parameter_name = 'at_disposal'

    def lookups(self, request, model_admin):
        return (
            ('staff', 'НА ПОСАДУ'),
            ('disposal', 'У РОЗПОРЯДЖЕННЯ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'staff':
            return queryset.filter(staff__isnull=False)
        if self.value() == 'disposal':
            return queryset.filter(staff__isnull=True)
        else:
            return queryset.all()


class FilesPresentFilter(admin.SimpleListFilter):
    title = 'наявністю файлів документів'
    parameter_name = 'files'

    def lookups(self, request, model_admin):
        return (
            ('Yes', 'ТАК'),
            ('No', 'НІ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'Yes':
            # return queryset.filter(Q(file__isnull=False) | ~Q(file__exact='') | Q(file2__isnull=False) | ~Q(file2__exact=''))
            return queryset.filter(Q(file__isnull=False) & ~Q(file='') | Q(file2__isnull=False) & ~Q(file2=''))
        if self.value() == 'No':
            return queryset.filter(Q(file__isnull=True) | Q(file__exact=''), Q(file2__isnull=True) | Q(file2__exact=''))
        else:
            return queryset.all()


class PositionFilter(AutocompleteFilter):
    title = 'посадою'
    field_name = 'position'
    rel_model = Staff
    parameter_name = 'position'


class UserFilter(AutocompleteFilter):
    title = 'користувачем'
    field_name = 'user_id'
    rel_model = User
    parameter_name = 'user'


class VacantFilter(admin.SimpleListFilter):
    title = 'ШТАТОМ'
    parameter_name = 'in_staff'

    def lookups(self, request, model_admin):
        return (
            ('vacant', 'ВАКАНТНІ'),
            ('vacant_ta', 'ВАКАНТНІ-ТВО'),
            ('vacant_ta_cd', 'ВАКАНТНІ-ТВО-КАНДИДАТ'),
            ('staff', 'ЗАЙНЯТІ'),
            ('staff_ta', 'ЗАЙНЯТІ+ТВО'),
            ('staff_ta_cd', 'ЗАЙНЯТІ+ТВО+КАНДИДАТ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'vacant':
            return queryset.filter(serviceman__isnull=True)
        if self.value() == 'vacant_ta':
            return queryset.filter(serviceman__isnull=True,
                                   temporary_acting__isnull=True)
        if self.value() == 'vacant_ta_cd':
            return queryset.filter(serviceman__isnull=True,
                                   temporary_acting__isnull=True,
                                   candidate__isnull=True)
        if self.value() == 'staff':
            return queryset.filter(serviceman__isnull=False)
        if self.value() == 'staff_ta':
            return queryset.filter(Q(serviceman__isnull=False) |
                                   Q(temporary_acting__isnull=False))
        if self.value() == 'staff_ta_cd':
            return queryset.filter(Q(serviceman__isnull=False) |
                                   Q(temporary_acting__isnull=False) |
                                   Q(candidate__isnull=False))
        else:
            return queryset


class StaffRankLevelFilter(admin.SimpleListFilter):
    title = 'РАНГОМ (ШПК)'
    parameter_name = 'rank_level'

    def lookups(self, request, model_admin):
        return (
            ('soldier', 'Солдати'),
            ('sergeant', 'Сержанти'),
            ('soldier_sergeant', 'Солдати+Сержанти'),
            ('officer', 'Офіцери'),
            ('civil', 'Цивільні'),
            ('no_civil', 'Крім цивільних'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'soldier':
            return queryset.filter(position__position_category__rank_level='1')
        if value == 'sergeant':
            return queryset.filter(position__position_category__rank_level='2')
        if value == 'soldier_sergeant':
            return queryset.filter(Q(position__position_category__rank_level='1') |
                                   Q(position__position_category__rank_level='2'))
        if value == 'officer':
            return queryset.filter(position__position_category__rank_level='3')
        if value == 'civil':
            return queryset.filter(position__position_category__rank_level__isnull=True)
        if value == 'no_civil':
            return queryset.filter(position__position_category__rank_level__isnull=False)
        else:
            return queryset


class ServicemanRankLevelFilter(admin.SimpleListFilter):
    title = 'РАНГОМ В/С'
    parameter_name = 'rank_level'

    def lookups(self, request, model_admin):
        return (
            ('soldier_sergeant', 'Солдати+Сержанти'),
            ('officer', 'Офіцери'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'soldier_sergeant':
            return queryset.filter(rank__rank_id__lte=12)   # magic number!!!
        elif value == 'officer':
            return queryset.filter(rank__rank_id__gte=13)
        else:
            return queryset

class ServicemanActionRankLevelFilter(admin.SimpleListFilter):
    title = 'РАНГОМ В/С'
    parameter_name = 'rank_level'

    def lookups(self, request, model_admin):
        return (
            ('soldier_sergeant', 'Солдати+Сержанти'),
            ('officer', 'Офіцери'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'soldier_sergeant':
            return queryset.filter(serviceman__rank__rank_id__lte=12)
        elif value == 'officer':
            return queryset.filter(serviceman__rank__rank_id__gte=13)
        else:
            return queryset


class TemporaryActingFilter(admin.SimpleListFilter):
    title = 'активністю'
    parameter_name = 'is_active'

    def lookups(self, request, model_admin):
        return (
            ('active', 'АКТИВНІ'),
            ('inactive', 'НЕАКТИВНІ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'active':
            return queryset.filter(serviceman=F('staff__serviceman'))
        elif self.value() == 'inactive':
            return queryset.exclude(serviceman=F('staff__serviceman'))
        else:
            return queryset.all()

class StaffActiveFilter(admin.SimpleListFilter):
    title = 'АКТИВНІСТЮ'
    parameter_name = 'staff_active'

    # def __init__(self, field, request, params, model, model_admin, field_path):
    #     self.used_parameters = {Q(date_end__isnull=True) |
    #         Q(date_end__gte=datetime.today()) |
    #         Q(serviceman__isnull=False),
    #         date_start__lte=datetime.today()}
    #     super().__init__(field, request, params, model, model_admin, field_path)

    def lookups(self, request, model_admin):
        return (
            ('active', 'АКТИВНІ'),
            ('inactive', 'НЕАКТИВНІ'),
            ('closed', 'ЗАКРИТІ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'active':
            return queryset.filter(Q(date_end__isnull=True) |
                                   Q(date_end__gte=datetime.today()) |
                                   Q(serviceman__isnull=False),
                                   date_start__lte=datetime.today())
        elif self.value() == 'inactive':
            return queryset.filter(date_start__gte=datetime.today())
        elif self.value() == 'closed':
            return queryset.filter(date_end__isnull=False, date_end__lte=datetime.today())
        else:
            return queryset.all()


class ServicemanInStaffFilter(admin.SimpleListFilter):
    title = 'Штатом'
    parameter_name = 'staff'

    def lookups(self, request, model_admin):
        return (
            ('staff', 'У штаті'),
            ('disposal', 'У розпорядженні'),
            ('in_list', 'У списку (штат+розпорядження)'),
            ('attached', 'Прикомандировані'),
            ('excluded', 'Виключені'),
            ('candidate', 'Кандидати (інші)'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'staff':
            return queryset.filter(staff_serviceman__isnull=False)
        elif value == 'disposal':
            return queryset.filter(staff_serviceman__isnull=True,
                                   serviceman_at_disposal__isnull=False,
                                   # serviceman_at_disposal__order_out__isnull=False,
                                   # serviceman_at_disposal__order_out__date__lte=datetime.today().date(),
                                   # serviceman_at_disposal__order_in__isnull=False,
                                   excluded=False
                                   )
        elif value == 'in_list':
            return queryset.filter(Q(staff_serviceman__isnull=False) |
                                   Q(serviceman_at_disposal__isnull=False),
                                   excluded=False
                                   )
        elif value == 'attached':
            return queryset.filter(staff_serviceman__isnull=True,
                                   serviceman_attached__isnull=False,
                                   excluded=False)
        elif value == 'excluded':
            return queryset.filter(excluded=True)
        elif value == 'candidate':
            return queryset.filter(staff_serviceman__isnull=True,
                                   serviceman_at_disposal__isnull=True,
                                   excluded=False)
        else:
            return queryset


class ServicemanInStaffIllegallyFilter(admin.SimpleListFilter):
    title = 'Штатом'
    parameter_name = 'staff'

    def lookups(self, request, model_admin):
        return (
            ('staff', 'У штаті'),
            ('disposal', 'У розпорядженні'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'staff':
            return queryset.filter(serviceman__staff_serviceman__isnull=False)
        elif value == 'disposal':
            return queryset.filter(serviceman__serviceman_at_disposal__isnull=False,
                                   serviceman__serviceman_at_disposal__order_out__isnull=False,
                                   serviceman__serviceman_at_disposal__order_out__date__lte=datetime.today().date(),
                                   serviceman__serviceman_at_disposal__order_in__isnull=True,
                                   serviceman__excluded=False)
            # return queryset.filter(serviceman__staff_serviceman__isnull=True, serviceman__excluded=False)
        else:
            return queryset


# class ServicemanAtDisposalIllegallyFilter(admin.SimpleListFilter):
#     title = 'СЗЧ'
#     parameter_name = 'illegally'
#
#     def lookups(self, request, model_admin):
#         return (
#             ('yes', 'У СЗЧ'),
#         )
#
#     def queryset(self, request, queryset):
#         value = self.value()
#         if value == 'yes':
#             res = ServicemanIllegallyAbsent.objects.filter(serviceman=self,
#                                                            date_from__lte=datetime.today().date(),
#                                                            date_to__gte=datetime.today().date(),
#                                                            ).count()
#
#             return queryset.filter(serviceman__staff_serviceman__isnull=False)
#         else:
#             return queryset


class SexFilter(admin.SimpleListFilter):
    title = 'Статтю'
    parameter_name = 'sex'

    def lookups(self, request, model_admin):
        return (
            ('male', 'Чоловік'),
            ('female', 'Жінка'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'male':
            return queryset.filter(sex=1)
        elif value == 'female':
            return queryset.filter(sex=2)
        else:
            return queryset


class BirthdayFilter(admin.SimpleListFilter):
    title = 'Днем народження'
    parameter_name = 'birthday'

    def lookups(self, request, model_admin):
        return (
            ('week', 'Наступні 7 днів цього місяця'),
            ('month', 'Цього місяця'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'week':
            today = date.today()
            queryset = queryset.filter(
                date_of_birth__month=today.month,
                date_of_birth__day__gte=today.day,
                date_of_birth__day__lte=today.day + 7
            )

        if self.value() == 'month':
            today = date.today()
            queryset = queryset.filter(
                date_of_birth__month=today.month,
                date_of_birth__day__gte=today.day)

        return queryset

class ServicemanMissionFilter(admin.SimpleListFilter):
    title = 'Бойовою місією'
    parameter_name = 'mission'

    def lookups(self, request, model_admin):
        items = Mission.objects.order_by('mission_id')
        return [(c.id, c.name) for c in items]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(mission_serviceman__mission_id=self.value())
        else:
            return queryset


class MissionFilter(AutocompleteFilter):
    title = 'місією'
    field_name = 'mission'
    # rel_model = MissionParticipant
    parameter_name = 'mission'

# class MissionFilter2(AutocompleteFilter):
#     title = 'місією'
#     field_name = 'mission_serviceman'
#     rel_model = MissionParticipant
#     parameter_name = 'mission'

# class ServicemanInOrderFilter(admin.SimpleListFilter):
#     title = 'наказом'
#     parameter_name = 'order'
#
#     def lookups(self, request, model_admin):
#         items = Order.objects.order_by('order_id')
#         return [(c.id, c.short_name) for c in items]
#
#     def queryset(self, request, queryset):
#         return queryset  # .filter(documents.order__mentioned__in=self.value())


class MissionParticipantInActionFilter(admin.SimpleListFilter):
    title = 'Участю у БД (поточна)'
    parameter_name = 'in_action'

    def lookups(self, request, model_admin):
        return (
            ('yes', 'так'),
            ('no', 'ні'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'yes':
            return queryset.filter(Q(start_date__lte=datetime.today().date()) &
                                   (Q(end_date__isnull=True) | Q(end_date__gte=datetime.today().date())))
        elif self.value() == 'no':
            return queryset.filter(end_date__lt=datetime.today().date())
        else:
            return queryset.all()


class ServicemanAtDisposalOrAbsentStatusFilter(admin.SimpleListFilter):
    title = 'Статусом'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return (
            ('progress', 'активний'),
            ('closed', 'закритий'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'progress':
            return queryset.filter(order_in__isnull=True)
        elif self.value() == 'closed':
            return queryset.filter(order_in__isnull=False)
        else:
            return queryset.all()
        # if self.value() == 'progress':
        #     return queryset.filter(Q(date_from__lte=datetime.today().date()) &
        #                            (Q(date_to__isnull=True) | Q(date_to__gte=datetime.today().date())))
        # elif self.value() == 'closed':
        #     return queryset.filter(date_to__lt=datetime.today().date())
        # else:
        #     return queryset.all()


###########
# INLINES #
###########

# class WeaponInline(admin.StackedInline):
#     model = Weapon
#     extra = 0

class NoEditBaseInline(admin.StackedInline):
    extra = 0

    def has_add_permission(self, request, obj):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

class OrderInline(admin.StackedInline):  #NoEditBaseInline):
    model = Order.mentioned.through
    extra = 0
    max_num = 0
    verbose_name = 'наказ'
    verbose_name_plural = 'накази'
    ordering = ['-order__date']
    # fields = ['order_id_link']
    readonly_fields = ['order']
    can_delete = False

    # def has_add_permission(self, request, obj):
    #     return False

    # def has_delete_permission(self, request, obj):
    #     return False

    # def order_id_link(self, obj):
    #     try:
    #         link = reverse(f'admin:documents_order_change', args=[obj.order_id])
    #     except AttributeError as e:
    #         pass
    #     else:
    #         return format_html('<a href="%s">%s</a>' % (link, obj))
    #
    # order_id_link.allow_tags = True
    # order_id_link.short_description = 'Номер'


class ReportInline(NoEditBaseInline):  # TabularInline
    model = Report
    extra = 0
    verbose_name = 'рапорт'
    verbose_name_plural = 'рапорти'
    ordering = ['-date']
    fields = [('input_id_link', 'user', 'file')]
    readonly_fields = ['input_id_link', 'file', 'user']

    def input_id_link(self, obj):
        try:
            link = reverse(f'admin:documents_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.input_id))

    input_id_link.allow_tags = True
    input_id_link.short_description = 'Номер'


class ActionBaseInline(NoEditBaseInline):
    extra = 0
    ordering = ['-action_date']

    def id_link(self, obj):
        try:
            link = reverse(f'admin:personnel_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id))

    id_link.allow_tags = True
    id_link.short_description = 'Номер'


class AcceptanceInline(ActionBaseInline):
    model = Acceptance
    verbose_name = 'Прийом на посаду'
    verbose_name_plural = 'Прийом на посаду'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class MovementInline(ActionBaseInline):
    model = Movement
    # fk_name = 'order_daily'
    verbose_name = 'переміщення'
    verbose_name_plural = 'переміщення'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class MovementSrcStaffInline(ActionBaseInline):
    model = Movement
    fk_name = 'staff_src'
    verbose_name = 'переміщення'
    verbose_name_plural = 'переміщення (з посади)'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class MovementDstStaffInline(ActionBaseInline):
    model = Movement
    fk_name = 'staff_dst'
    verbose_name = 'переміщення'
    verbose_name_plural = 'переміщення (на посаду)'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class TakeOutInline(ActionBaseInline):
    model = TakeOut
    verbose_name = 'Поза штат'
    verbose_name_plural = 'Поза штат'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class DismissalInline(ActionBaseInline):
    model = Dismissal
    verbose_name = 'Виключення зі списків'
    verbose_name_plural = 'Виключення зі списків'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'reason', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'reason', 'status', 'user']


class TemporaryActingInline(ActionBaseInline):
    model = TemporaryActing
    verbose_name = 'Допуск до ТВО'
    verbose_name_plural = 'Допуск до ТВО'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'status', 'user']


class AssignRankInline(ActionBaseInline):
    model = AssignRank
    verbose_name = 'Присвоєння звання'
    verbose_name_plural = 'Присвоєння звання'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class PayoutInline(ActionBaseInline):
    model = Payout
    verbose_name = 'Виплати'
    verbose_name_plural = 'Виплати'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'type', 'amount', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'type', 'amount', 'status', 'user']


class MissingBaseInline(NoEditBaseInline):
    extra = 0
    ordering = ['-date_from']

    def index_link(self, obj):
        try:
            link = reverse(f'admin:documents_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id if self.model == Hospitalization else obj.index))

    index_link.allow_tags = True
    index_link.short_description = 'Індекс/номер'


class VacationInline(MissingBaseInline):
    model = Vacation
    verbose_name = 'Відпустка'
    verbose_name_plural = 'Відпустки'
    ordering = ['-date_from']
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link','user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link','user']


class TripInline(MissingBaseInline):
    model = Trip
    verbose_name = 'Відрядження'
    verbose_name_plural = 'Відрядження'
    ordering = ['-date_from']
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link','user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link','user']


class HospitalizationInline(MissingBaseInline):
    model = Hospitalization
    verbose_name = 'Лікарняний'
    verbose_name_plural = 'Лікарняні'
    ordering = ['-date_from']
    fields = [('index_link', 'date_from', 'returned', 'user')]
    readonly_fields = ['index_link', 'date_from', 'returned', 'user']


class ServicemanAtDisposalOrAbsentBaseInline(NoEditBaseInline):
    ordering = ['-date_from']
    fields = [('id_link', 'date_from', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['id_link', 'date_from', 'order_out_link', 'order_in_link', 'user']

    def id_link(self, obj):
        try:
            link = reverse(f'admin:personnel_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id))

    id_link.allow_tags = True
    id_link.short_description = 'Номер'


class DisposalInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAtDisposal
    verbose_name = 'У розпорядженні'
    verbose_name_plural = 'У розпорядженні'


class AttachedInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAttached
    verbose_name = 'Прикомандирований'
    verbose_name_plural = 'Прикомандирований'


class IllegallyAbsentInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanIllegallyAbsent
    verbose_name = 'СЗЧ'
    verbose_name_plural = 'СЗЧ'


class ArrestInline(MissingBaseInline):
    model = Arrest
    fk_name = 'serviceman'
    verbose_name = 'Арешт'
    verbose_name_plural = 'Арешт'
    fields = [('index_link', 'date_from', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'order_out_link', 'order_in_link', 'user']


class LossesInline(NoEditBaseInline):
    model = Losses
    fk_name = 'serviceman'
    verbose_name = 'Втрати'
    verbose_name_plural = 'Втрати'
    fields = [('id_link', 'action_date', 'type', 'order_daily', 'user')]
    readonly_fields = ['id_link', 'action_date', 'type', 'order_daily', 'user']
    ordering = ['-action_date']

    def id_link(self, obj):
        try:
            link = reverse(f'admin:personnel_losses_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id))

    id_link.allow_tags = True
    id_link.short_description = 'Номер'


class MissionParticipantsInline(NoEditBaseInline):
    model = MissionParticipant
    fk_name = 'serviceman'
    verbose_name = 'Бойові місії'
    verbose_name_plural = 'Бойові місії (участь у БД)'
    fields = [('id_link', 'start_date', 'end_date', 'user')]
    readonly_fields = ['id_link', 'start_date', 'end_date', 'user']
    ordering = ['-start_date']

    def id_link(self, obj):
        try:
            link = reverse(f'admin:personnel_missionparticipant_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id))

    id_link.allow_tags = True
    id_link.short_description = 'Номер'


#
# Admin Classes
#
class ServicemanAdmin(PersonnelFileMixin, admin.ModelAdmin):
    inlines = [#WeaponInline,
               OrderInline, ReportInline, AcceptanceInline, MovementInline, TakeOutInline,
               DismissalInline, TemporaryActingInline, AssignRankInline, PayoutInline,
               VacationInline, TripInline, HospitalizationInline,
               DisposalInline, AttachedInline, IllegallyAbsentInline,
               ArrestInline, LossesInline, MissionParticipantsInline
    ]
    list_display = [
        'serviceman_id',
        'rank',
        'serviceman_link',
        'acceptance_order_link',
        'staff_link',
        'staff_full_name',
        'in_list',
        'at_disposal',
        'illegally_absent',
        'date_of_birth',
        'age',
        'next_birthday',
        'tax_id',
        'phone_number',
        'callsign',
    ]
    list_filter = [ServicemanMissionFilter,
                   ServicemanInStaffFilter,
                   ('location', filter_name('Локацією')),
                   BirthdayFilter,
                   SexFilter,
                   FilesPresentFilter,
                   ('service_type', filter_name('Видом служби')),
                   ('medical_restrictions', filter_name('Придатністю')),
                   ServicemanRankLevelFilter,
                   ('rank', filter_name('Званням'))]  # UnitFilter,
    ordering = ['last_name', 'first_name', 'second_name']
    search_fields = ['=serviceman_id', 'first_name', 'last_name', 'callsign', 'phone_number', 'tax_id', 'comment']
    autocomplete_fields = ['acceptance_order', 'rank', 'rank_order', 'dismissal_order']
    readonly_fields = ['staff_link', 'temporary_acting_link', 'short_name', 'illegally_absent', 'loss', 'arrest',
                       'service_term', 'service_term_new', 'service_term_years_new', 'service_term_years_gte1']  #, 'staff_order_link']
    fields = ['serviceman_id',
              ('last_name', 'short_name'),
              'first_name',
              ('second_name', 'callsign'),
              ('sex', 'blood_type'),
              ('date_of_birth', 'birthplace'),
              ('tax_id', 'phone_number'),
              'location',
              ('staff_link', 'temporary_acting_link', 'illegally_absent', 'loss', 'arrest'),
              'acceptance_order',  #'staff_order_link'),
              ('dismissal_order', 'dismissal_date', 'excluded'),
              'rank', ('rank_order', 'rank_order_ext', 'rank_order_ext_date'),
              ('service_type', 'medical_restrictions'),
              ('service_term_start_date', 'service_term_years', 'service_term_months', 'service_term_days'),
              ('service_term_text', 'service_periods'),
              'service_term', ('service_term_new', 'service_term_years_new', 'service_term_years_gte1'),
              ('military_id', 'military_oath_date', 'commissariat'),
              # 'excluded',
              # ('dismissal_date', 'dismissal_order'),
              ('passport', 'marital_status'),
              'home_address',
              ('education', 'relatives'), 'comment', 'file', 'file2']
    actions = ['build_table',
               'create_excel_serviceman',
               'create_form5',
               'create_combat_operations',
               'create_combat_operations_f6',
               'create_list2order_serviceman',
               'create_list2order_serviceman_accusative',
               'create_list2order_serviceman_dative',
               'serviceman_test',
               ]
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'{datetime.now().strftime("%d.%m.%Y")}_список.xlsx')
    template_form5 = 'form5_template.docx'
    change_list_template = 'admin/personnel/change-list.html'
    list_per_page = 20
    list_max_show_all = 3000

    @staticmethod
    def make_shifts(request, queryset):
        return shifts_view(request, queryset)

    def serviceman_link(self, obj):
        link = reverse("admin:personnel_serviceman_change", args=[obj.id])
        return format_html('<a href="%s">%s</a>' % (link, obj.full_name_upper))

    serviceman_link.short_description = 'Військовослужбовець'
    serviceman_link.admin_order_field = 'last_name'

    def acceptance_order_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.acceptance_order.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.acceptance_order.short_name))

    acceptance_order_link.allow_tags = True
    acceptance_order_link.short_description = 'наказ (зарахування)'
    acceptance_order_link.admin_order_field = 'acceptance_order__order_id'


class RankAdmin(admin.ModelAdmin):
    list_display = ['rank_id', 'name', 'short_name', 'rank_level', 'serviceman_count',
                    'in_genitive', 'in_dative', 'in_accusative']
    search_fields = ['rank_id', 'name', 'short_name']
    ordering = ['rank_id', 'name']
    list_per_page = 40

    def serviceman_count(self, obj):
        result = Serviceman.objects.filter(rank=obj).count()
        link = f'/admin/personnel/serviceman/?rank={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    serviceman_count.short_description = 'Кількість в/с'


class PositionCategoryAdmin(admin.ModelAdmin):
    list_display = [
        'position_category_id',
        'name',
        'rank_level',
        'staff_count'
    ]
    search_fields = ['position_category_id', 'name']
    list_filter = [('rank_level', filter_name('Рангом'))]
    ordering = ['position_category_id']
    list_per_page = 20

    def staff_count(self, obj):
        result = Position.objects.filter(position_category=obj).count()
        link = f'/admin/personnel/position/?position_category={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_count.short_description = 'Кількість посад'


class PositionAdmin(admin.ModelAdmin):
    list_display = ['position_id', 'name', 'tariff', 'milspec', 'position_category', 'staff_count',
                    'in_accusative', 'in_dative', 'in_ablative']
    list_filter = ['position_category', 'tariff']
    search_fields = ['position_id', 'name', 'milspec']
    fields = ['position_id', 'name', 'tariff', 'milspec', 'position_category']
    ordering = ['position_id', 'name', 'tariff']
    list_per_page = 20

    def staff_count(self, obj):
        result = Staff.objects.filter(Q(date_end__isnull=True) |
                                      Q(date_end__gte=datetime.today()) |
                                      Q(serviceman__isnull=False),
                                      date_start__lte=datetime.today(),
                                      position=obj).count()
        link = f'/admin/personnel/staff/?position={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_count.short_description = 'Активні посади'


class AssigneeAdmin(admin.ModelAdmin):
    list_display = ['assignee_id', 'name', 'user']
    search_fields = ['assignee_id', 'name', 'user']
    ordering = ['assignee_id', 'name']
    list_per_page = 20


class LocationAdmin(admin.ModelAdmin):
    list_display = ['location_id', 'name', 'description', 'serviceman_count']
    search_fields = ['location_id', 'name', 'description']
    ordering = ['location_id']
    list_per_page = 20

    def serviceman_count(self, obj):
        result = Serviceman.objects.filter(location=obj).count()
        link = f'/admin/personnel/serviceman/?location__id__exact={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    serviceman_count.short_description = 'Кількість в/с'


class UnitGroupAdmin(admin.ModelAdmin):
    list_display = [
        'group_id',
        'name',
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    fields = [
        'group_id',
        'name',
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    readonly_fields = [
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    search_fields = ['group_id', 'name']
    ordering = ['group_id']
    list_per_page = 20


class UnitCombatGroupAdmin(admin.ModelAdmin):
    list_display = [
        'group_id',
        'unit_group_link',
        'name',
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    list_filter = [('unit_group', filter_name('категорією'))]
    fields = [
        'group_id',
        'unit_group',
        'name',
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    readonly_fields = [
        'unit_count_link',
        'staff_all_count_link',
        'staff_list_count_link',
        'posture'
    ]
    search_fields = ['group_id', 'name']
    ordering = ['group_id']
    list_per_page = 20


class UnitAdmin(admin.ModelAdmin):
    list_display = ['unit_id', 'unit_code', 'name', 'full_name', 'in_genitive', 'parent_unit',
                    'combat_group', 'letter', 'staff_all_count_link', 'staff_list_count_link', 'posture']
    list_filter = [('combat_group__unit_group', filter_name('категорією')),
                   ('combat_group', filter_name('групою БЧС')),
                   ('letter', filter_name('літерою')),
                   #UnitContentFilter
                   ]
    fields = ['unit_id', 'unit_code', 'name', 'full_name', 'in_genitive', 'parent_unit',
              'combat_group', 'group', 'letter',
              ('staff_all_count_link', 'staff_list_count_link')]
    search_fields = ['unit_id', 'unit_code', 'name', 'full_name', 'combat_group__name', 'group__name', 'letter']
    readonly_fields = ['staff_all_count_link', 'staff_list_count_link', 'in_genitive']
    ordering = ['unit_id']
    list_per_page = 20

    def staff_all_count_link(self, obj):
        result = obj.staff_all_count()
        link = f'/admin/personnel/staff/?staff_active=active&unit={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_all_count_link.short_description = 'Посади (штат)'

    def staff_list_count_link(self, obj):
        result = obj.staff_list_count()
        link = f'/admin/personnel/staff/?in_staff=staff&staff_active=active&unit={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_list_count_link.short_description = 'Посади (список)'


class TariffAdmin(admin.ModelAdmin):
    list_display = ['tariff_id', 'salary', 'bonus1', 'bonus2', 'staff_count']
    search_fields = ['tariff_id', 'salary', 'bonus1', 'bonus2']
    ordering = ['tariff_id']
    list_per_page = 20

    def staff_count(self, obj):
        result = Position.objects.filter(tariff=obj).count()
        link = f'/admin/personnel/position/?tariff={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    staff_count.short_description = 'Кількість посад'


class MissingResource(resources.ModelResource):
    row_number = fields.Field(column_name='№', attribute='row_number', readonly=True)
    serviceman_rank = Field(column_name='Звання', attribute='serviceman__rank',
                            widget=ForeignKeyWidget(Rank, field='name'))
    serviceman_full_name = Field(column_name='ПІБ')
    serviceman_staff_full_name = Field(column_name='Посада', attribute='serviceman_staff_full_name')
    # issue_date = Field(column_name='Дата реєстрації', attribute='issue_date',
    #                    widget=DateWidget(format='%d.%m.%Y'))
    date_from = Field(column_name='Дата початку', attribute='date_from',
                      widget=DateWidget(format='%d.%m.%Y'))
    order_out = Field(column_name='Наказ (початок)', attribute='order_out_short_name')
    date_to = Field(column_name='Дата закінчення', attribute='date_to',
                    widget=DateWidget(format='%d.%m.%Y'))
    order_in = Field(column_name='Наказ (закінчення)', attribute='order_in_short_name')
    days = Field(column_name='Дні', attribute='days')
    comment = Field(column_name='Коментар', attribute='comment')
    status = Field(column_name='Статус', attribute='status_text')

    def dehydrate_row_number(self, obj):
        if not hasattr(self, 'row_counter'):
            self.row_counter = 1
        row_number = self.row_counter
        self.row_counter += 1
        return row_number

    def dehydrate_serviceman_full_name(self, obj):
        return obj.serviceman.full_name_upper


class ServicemanIllegallyAbsentResource(MissingResource):
    pass
    # class Meta:
    #     model = ServicemanIllegallyAbsent
    #     export_order = ['serviceman_rank', 'serviceman_full_name', 'serviceman_staff_full_name',
    #                     'date_from', 'date_to', 'days', 'comment', 'status', ]


class ServicemanAtDisposalResource(MissingResource):
    # class Meta:
    #     model = ServicemanAtDisposal
    #     export_order = ['serviceman_rank', 'serviceman_full_name', 'serviceman_staff_full_name',
    #                     'date_from', 'date_to', 'days', 'unit', 'reason', 'comment', 'status', ]

    unit = Field(column_name='Підрозділ розпорядження', attribute='unit')
    reason = Field(column_name='Причина', attribute='reason')


class ServicemanBaseAdmin(admin.ModelAdmin):
    list_per_page = 20
    list_max_show_all = 1000

    def save_model(self, request, obj, form, change):
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)

    def serviceman_link(self, obj):
        link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
        return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))

    serviceman_link.short_description = 'Військовослужбовець'
    serviceman_link.admin_order_field = 'serviceman'


class ServicemanAtDisposalAdmin(ServicemanBaseAdmin, ExportActionModelAdmin):
    list_display = ['id', 'serviceman_link', 'serviceman_staff_link', 'serviceman_temporary_acting',
                    'serviceman_illegally_absent', 'status', 'reason', 'unit_link', 'at_disposal_verbose', #'report_out_link',
                    'days', 'order_out_link', 'order_in_link',
                    'comment', 'user']
    list_filter = [ServicemanAtDisposalOrAbsentStatusFilter,
                   ('reason', filter_name('Причиною')),
                   ('at_disposal', filter_name('розпорядженням')),
                   ServicemanActionRankLevelFilter,
                   OrderDailyOutFilter,
                   OrderDailyInFilter,
                   UnitDisposalFilter,
                   ('date_from', filter_name('Датою початку')),
                   ('date_to', filter_name('Датою закінчення'))]
    search_fields = ['serviceman__last_name', 'serviceman__first_name', 'comment']
    # sortable_by =
    ordering = ['serviceman']
    fields = ['serviceman', 'reason', 'at_disposal', 'unit',
              ('date_from', 'date_to', 'days'),
              'report_out', 'order_out',
              'report_in', 'order_in',
              'comment', 'status', 'user']
    readonly_fields = ['date_from', 'date_to', 'days', 'status', 'user']
    autocomplete_fields = ['serviceman', 'report_out', 'report_in', 'order_out', 'order_in']
    resource_classes = [ServicemanIllegallyAbsentResource]

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')

        try:
            check_serviceman_at_disposal_and_raise(obj.serviceman, obj.id)
            obj.date_from = obj.order_out.date if obj.order_out else None
            obj.date_to = obj.order_in.date if obj.order_in else None
            super().save_model(request, obj, form, change)
        except Exception as e:
            messages.error(request, f'Помилка! {e}')  # how to handle error correctly?
            logger.error(e)

    def unit_link(self, obj):
        if obj.unit:
            link = reverse("admin:personnel_unit_change", args=[obj.unit.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.unit.name))
        else:
            return '-'

    unit_link.short_description = 'підрозділ підпорядкування'
    unit_link.admin_order_field = 'unit'

    # def serviceman_staff_link(self, obj):
    #     return obj.serviceman.staff_link
    #
    # serviceman_staff_link.short_description = 'Штат'

    def serviceman_temporary_acting(self, obj):
        return obj.serviceman.temporary_acting_link

    serviceman_temporary_acting.short_description = 'ТВО'

    def serviceman_illegally_absent(self, obj):
        return obj.serviceman.illegally_absent

    serviceman_illegally_absent.short_description = 'СЗЧ'


class ServicemanAttachedAdmin(ServicemanBaseAdmin, ExportActionModelAdmin):
    list_display = ['id', 'serviceman_link', 'status',
                    'unit_link', 'external_military_unit', 'external_position',
                    'days', 'order_out_link', 'order_in_link',
                    'comment', 'user']
    list_filter = [ServicemanAtDisposalOrAbsentStatusFilter,
                   ('external_military_unit', filter_name('Військовою частиною')),
                   ServicemanActionRankLevelFilter,
                   OrderDailyOutFilter,
                   OrderDailyInFilter,
                   ('date_from', filter_name('Датою початку')),
                   ('date_to', filter_name('Датою закінчення'))]
    search_fields = ['serviceman__last_name', 'serviceman__first_name', 'comment']
    ordering = ['serviceman']
    fields = ['serviceman', 'unit', 'external_military_unit', 'external_position', 'reason',
              ('date_from', 'date_to', 'days'),
              'report_out', 'order_out',
              'report_in', 'order_in',
              'comment', 'status',
              'user']
    readonly_fields = ['days', 'user', 'status']
    autocomplete_fields = ['serviceman', 'report_out', 'report_in', 'order_out', 'order_in']

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')

        try:
            # move to clean method !!!
            check_serviceman_attached_and_raise(obj.serviceman, obj.id)
            super().save_model(request, obj, form, change)
        except Exception as e:
            messages.error(request, f'Помилка! {e}')  # how to handle error correctly?
            logger.error(e)

    def unit_link(self, obj):
        if obj.unit:
            link = reverse("admin:personnel_unit_change", args=[obj.unit.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.unit.name))
        else:
            return '-'

    unit_link.short_description = 'Підрозділ'
    unit_link.admin_order_field = 'unit'


class ServicemanIllegallyAbsentAdmin(ServicemanBaseAdmin, ExportActionModelAdmin):
    list_display = ['id', 'serviceman_link', 'serviceman_staff_link', 'status', 'report_out_link',
                    'days', 'date_from', 'order_out_link', 'date_to', 'order_in_link',
                    'comment', 'user']
    list_filter = [ServicemanAtDisposalOrAbsentStatusFilter,
                   ServicemanInStaffIllegallyFilter,
                   OrderDailyOutFilter,
                   OrderDailyInFilter,
                   UnitCombatGroupFilter,
                   ('date_from', filter_name('Датою початку')),
                   ('date_to', filter_name('Датою закінчення'))]  #OrderDailyFilter,
    search_fields = ['serviceman__last_name', 'comment']
    fields = ['serviceman', 'serviceman_staff_link',
              ('date_from', 'date_to', 'days'),
              'report_out', 'order_out',
              'report_in', 'order_in',
              'comment', 'status', 'user']
    readonly_fields = ['serviceman_staff_link', 'date_to', 'days', 'status', 'user']
    autocomplete_fields = ['serviceman', 'report_out', 'report_in', 'order_out', 'order_in']
    resource_classes = [ServicemanIllegallyAbsentResource]

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            check_serviceman_illegally_absent_and_raise(obj.serviceman, obj.id)
            # obj.date_from = obj.order_out.date if obj.order_out else None
            obj.date_to = obj.order_in.date if obj.order_in else None
            super().save_model(request, obj, form, change)
        except Exception as e:
            messages.error(request, f'Помилка! {e}')  # how to handle error correctly?
            logger.error(e)

    def serviceman_staff_link(self, obj):
        return obj.serviceman.staff_link

    serviceman_staff_link.short_description = 'Штат'


class StaffAdmin(PersonnelFileMixin, admin.ModelAdmin):
    inlines = [AcceptanceInline, MovementSrcStaffInline, MovementDstStaffInline, TakeOutInline,
               DismissalInline, TemporaryActingInline]
    list_display = ['staff_id', 'serviceman_link', 'unit_link',  #'serviceman_name',
                    'position_display_name', 'full_name',
                    'milspec', 'position_category_link', 'is_active',
                    'staff_order_qty', 'staff_order_short_name',
                    'temporary_acting_link', 'candidate_link',
                    'serviceman_tax_id', 'serviceman_phone',
                    # 'full_name_in_accusative', 'full_name_in_dative', 'full_name_in_ablative'
                    ]
    search_fields = ['=staff_id', 'name', 'serviceman__last_name', 'serviceman__first_name',
                     'position__name', 'position__milspec', 'position__position_category__name', 'comment']
    list_filter = [VacantFilter, StaffRankLevelFilter, StaffActiveFilter,
                   ('serviceman__medical_restrictions', filter_name('Придатністю')),
                   PositionFilter, UnitFilter, StaffUnitCombatGroupFilter]  #, StaffUnitContentFilter]
    # list_filter[2].default_value = 'active'
    fields = ['staff_id', 'date_start', 'date_end', 'name', 'position', 'unit',
              ('full_name', 'full_name_rs'),
              ('full_name_in_accusative', 'full_name_rs_in_accusative'),
              ('full_name_in_dative', 'full_name_rs_in_dative'),
              ('full_name_in_ablative', 'full_name_rs_in_ablative'),
              ('serviceman', 'staff_order_short_name'),
              'temporary_acting', 'candidate', 'comment']
    readonly_fields = ['serviceman',
                       'full_name', 'full_name_rs',
                       'full_name_in_accusative', 'full_name_rs_in_accusative',
                       'full_name_in_dative', 'full_name_rs_in_dative',
                       'full_name_in_ablative', 'full_name_rs_in_ablative',
                       'staff_order_short_name']
    autocomplete_fields = ['position', 'serviceman', 'candidate', 'temporary_acting']
    #    prepopulated_fields = ['']
    ordering = ['staff_id', 'id']
    list_max_show_all = 1000
    list_per_page = 100
    actions = ['create_excel_staff',
               'create_excel_staff_missing_last_month',
               'create_excel_staff_missing_current_month',
               'create_list2order_staff',
               'create_list2order_staff_accusative',
               'create_list2order_staff_dative',
               'renumerate_staff',
               'make_takeout',
               'add_to_mission']
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Штат_204_{datetime.now().strftime("%Y.%m.%d")}.xlsx')


    def position_category_link(self, obj):
        link = reverse("admin:personnel_positioncategory_change", args=[obj.position_category.id])
        return format_html('<a href="%s">%s</a>' % (link, obj.position_category.name))

    position_category_link.short_description = 'ШПК'
    position_category_link.admin_order_field = 'position__position_category__category_id'

    def serviceman_link(self, obj):
        if obj.serviceman:
            link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))
        else:
            status = get_staff_position_status(obj)
            # return 'ВАКАНТ'
            return format_html(f'<b><span style="color:{get_staff_position_color(status)}">'
                               f'{get_staff_position_display(status, True)}</span></b>')

    serviceman_link.allow_tags = True
    serviceman_link.short_description = 'військовослужбовець'
    serviceman_link.admin_order_field = 'serviceman'


class ActionAdminBase(admin.ModelAdmin):
    list_per_page = 20
    list_max_show_all = 1000

    def serviceman_link(self, obj):
        link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
        return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))

    serviceman_link.allow_tags = True
    serviceman_link.short_description = 'військовослужбовець'
    serviceman_link.admin_order_field = 'serviceman'

    def report_link(self, obj):
        if obj.report:
            link = reverse("admin:documents_report_change", args=[obj.report.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.report.short_name))
        else:
            return '-'

    report_link.short_description = 'Рапорт'
    report_link.admin_order_field = 'report__input_id'

    def daily_order_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.order_daily.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.order_daily.short_name))

    daily_order_link.allow_tags = True
    daily_order_link.short_description = 'добовий наказ'
    daily_order_link.admin_order_field = 'order_daily__order_id'

    def rs_order_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.order_rs.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.order_rs.short_name))

    rs_order_link.allow_tags = True
    rs_order_link.short_description = 'РС наказ'
    rs_order_link.admin_order_field = 'order_rs__order_id'

    def save_model(self, request, obj, form, change):
        print(f'{self.model._meta.model_name}::save_model')
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class AcceptanceAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'serviceman_link', 'staff_link', 'disposal_link',
                    'report_link', 'rs_order_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('status', filter_name('статусом')),
                   ('action_date', filter_name('датою')),
                   AtDisposalFilter, ServicemanActionRankLevelFilter, OrderDailyFilter, OrderRsFilter, RsPresentFilter,
                   ('user', filter_name('користувачем'))]  # UserFilter]
    autocomplete_fields = ['staff', 'serviceman', 'report', 'order_rs', 'order_daily']
    fields = ['action_date', 'serviceman', 'staff', 'staff_link',
              'report', 'order_rs', 'reason', 'order_daily', 'disposal',
              'comment', 'status', 'user']
    readonly_fields = ['staff_link', 'disposal', 'status', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_for_rs_order',
               'create_doc_file_extract',
               'apply_acceptance',
               'rollback_acceptance',
               'cancel_staff_action']
    template_daily = 'daily_order_acceptance_template.docx'
    template_rs = 'rs_order_acceptance_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Acceptance')

    def staff_link(self, obj):
        if obj.staff:
            link = reverse("admin:personnel_staff_change", args=[obj.staff.id])
            return format_html('<a href="%s">%s</a>' % (link,
                                                        obj.staff if obj.status=='1' else obj.staff_short_name))
        else:
            return 'у розпорядження'

    staff_link.short_description = 'На штатну посаду/розпорядження'
    staff_link.admin_order_field = 'staff__staff_id'

    # def save_model(self, request, obj, form, change):
    #     #staff = Staff.objects.filter(id=obj.staff.id).first()
    #     #print(staff)
    #     # just update the staff.serviceman by obj.serviceman
    #     try:
    #         obj.staff.serviceman = obj.serviceman
    #         obj.staff.save()
    #         super().save_model(request, obj, form, change)
    #     except KeyError as e:
    #         messages.error(request, 'Помилка!') # how to handle error correctly?
    #         logger.error(e)

    # def render_change_form(self, request, context, *args, **kwargs):
    #     context['adminform'].form.fields['staff'].queryset = Staff.objects.filter(serviceman__isnull=True)
    #     return super(AcceptanceAdmin, self).render_change_form(request, context, *args, **kwargs)

    # def formfield_for_foreignkey(self, db_field, request, **kwargs):
    #     print('in function')
    #     print(kwargs)
    #     if db_field.name == "staff":
    #         print('condition met')
    #         qs = Staff.objects.filter(serviceman__isnull=True)
    #         print(qs)
    #         kwargs["queryset"] = qs
    #     res = super().formfield_for_foreignkey(db_field, request, **kwargs)
    #     print(res)
    #     return res

    # def get_field_queryset(self, db, db_field, request):
    #     related_admin = self.admin_site._registry.get(db_field.remote_field.model)
    #     print('in function')
    #     if related_admin is not None:
    #         print('rel admin')
    #         ordering = related_admin.get_ordering(request)
    #         if ordering is not None and ordering != ():
    #             print('has ordering')
    #             qs = db_field.remote_field.model._default_manager.using(db).order_by(
    #                 *ordering
    #             )
    #             print(db_field)
    #             print(db_field.name)
    #             if db_field.name == 'staff':
    #                 print('condition met')
    #                 filtered_qs = qs.filter(serviceman__isnull=True)
    #                 print(filtered_qs)
    #                 return filtered_qs
    #             else:
    #                 return qs
    #     return None

class MovementAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'serviceman_link', 'staff_src_link', 'staff_dst_link',
                    'report_link', 'rs_order_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('status', filter_name('статусом')),
                   ('action_date', filter_name('датою')),
                   ServicemanActionRankLevelFilter, OrderDailyFilter, OrderRsFilter, RsPresentFilter,
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['staff_src', 'staff_dst', 'report', 'order_rs', 'order_daily']
    fields = ['action_date', 'staff_src', 'serviceman', 'staff_dst', 'report', 'order_rs', 'order_daily', 'comment',
              'status', 'user']
    readonly_fields = ['serviceman', 'status', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_for_rs_order',
               'create_doc_file_extract',
               'apply_movement',
               'rollback_movement',
               'cancel_staff_action']
    template_daily = 'daily_order_movement_template.docx'
    template_rs = 'rs_order_movement_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Movement')

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            obj.serviceman = obj.staff_src.serviceman
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)

    def staff_src_link(self, obj):
        link = reverse("admin:personnel_staff_change", args=[obj.staff_src.id])
        return format_html('<a href="%s">%s</a>' % (link,
                                                    obj.staff_src if obj.status=='1' else obj.staff_src_short_name))

    staff_src_link.short_description = 'З штатної посади'
    staff_src_link.admin_order_field = 'staff_src__staff_id'

    def staff_dst_link(self, obj):
        link = reverse("admin:personnel_staff_change", args=[obj.staff_dst.id])
        return format_html('<a href="%s">%s</a>' % (link,
                                                    obj.staff_dst if obj.status=='1' else obj.staff_dst_short_name))

    staff_dst_link.short_description = 'На штатну посаду'
    staff_dst_link.admin_order_field = 'staff_dst__staff_id'

class TakeOutAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'serviceman_link', 'staff_link', 'reason', #'report_link',
                    'rs_order_link', 'daily_order_link', 'disposal_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('status', filter_name('статусом')),
                   ('reason', filter_name('причиною')),
                   ServicemanActionRankLevelFilter,
                   OrderDailyFilter,
                   OrderRsFilter,
                   RsPresentFilter,
                   ('action_date', filter_name('датою')),
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['staff', 'report', 'order_rs', 'order_daily']
    fields = ['action_date', 'staff', 'serviceman', 'reason', 'report', 'order_rs', 'order_daily', 'disposal',
              'comment', 'status', 'user']
    readonly_fields = ['serviceman', 'disposal', 'status', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_for_rs_order',
               'create_doc_file_extract',
               'apply_takeout',
               'rollback_takeout',
               'cancel_staff_action']
    template_daily = 'daily_order_takeout_template.docx'
    template_rs = 'rs_order_takeout_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'TakeOut')

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            # obj.user = request.user
            obj.serviceman = obj.staff.serviceman
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)

    def staff_link(self, obj):
        if obj.staff:
            link = reverse("admin:personnel_staff_change", args=[obj.staff.id])
            return format_html('<a href="%s">%s</a>' % (link,
                                                        obj.staff if obj.status=='1' else obj.staff_short_name))
        else:
            return 'у розпорядження'

    staff_link.short_description = 'З штатної посади'
    staff_link.admin_order_field = 'staff__staff_id'


class DismissalAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'serviceman_link', 'staff_link', 'reason',
                    'report_link', 'rs_order_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('status', filter_name('статусом')),
                   ('action_date', filter_name('датою')),
                   ServicemanActionRankLevelFilter, OrderDailyFilter, OrderRsFilter, RsPresentFilter,
                   ('reason', filter_name('причиною')),
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['serviceman', 'report', 'order_rs', 'order_daily', 'user']
    fields = ['action_date', 'serviceman', 'staff', 'reason', 'move_new_position',
              ('vacation', 'vacation_additional', 'payment_for_health', 'payment_for_aid',
              'transport_docs', 'official_housing'),
              'report', 'order_rs', 'order_daily',
              'comment', 'status', 'user']
    readonly_fields = ['status', 'staff', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_for_rs_order',
               'create_doc_file_extract',
               'apply_dismissal',
               'rollback_dismissal',
               'cancel_staff_action']
    template_daily = 'daily_order_dismissal_template.docx'
    template_rs = 'rs_order_dismissal_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Dismissal')

    # fieldsets = (
    #     (None, {
    #         'fields': ('action_date',)
    #     }),
    #     (None, {
    #         'fields': (('serviceman', 'saved_serviceman'),)
    #     }),
    #     (None, {
    #         'fields': ('report', 'order', 'comment')
    #     })
    # )

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            # obj.user = request.user
            if hasattr(obj.serviceman, 'staff_serviceman'):
                obj.staff = obj.serviceman.staff
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class TemporaryActingAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'is_active', 'serviceman_link',
                    'serviceman_staff_print_name', 'staff_link',
                    'report_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('status', filter_name('статусом')),
                   ('action_date', filter_name('датою')),
                   ServicemanActionRankLevelFilter,
                   OrderDailyFilter,
                   TemporaryActingFilter,
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['serviceman', 'staff', 'report', 'order_daily']
    fields = ['action_date', 'staff', 'serviceman', 'serviceman_staff_print_name', 'report', 'order_daily',
              'comment', 'status', 'is_active', 'user']
    readonly_fields = ['status', 'is_active', 'serviceman_staff_print_name', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_extract',
               'apply_temporary_acting',
               'rollback_temporary_acting',
               'cancel_staff_action']
    template_daily = 'daily_order_temporary_acting_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'TemporaryActing')

    def staff_link(self, obj):
        if obj.staff:
            link = reverse("admin:personnel_staff_change", args=[obj.staff.id])
            return format_html('<a href="%s">%s</a>' % (link,
                                                        obj.staff if obj.status=='1' else obj.staff_short_name))
        else:
            return 'у розпорядження'

    staff_link.short_description = 'На штатну посаду'
    staff_link.admin_order_field = 'staff__staff_id'

    def serviceman_staff_print_name(self, obj):
        return f'{obj.serviceman.staff_print_name if obj.serviceman else "-"}'

    serviceman_staff_print_name.short_description = 'Штатна посада (поточна)'
    # serviceman_staff_print_name.admin_order_field = 'serviceman__staff__staff_id'


    # def save_model(self, request, obj, form, change):
    #     try:
    #         obj.user = request.user
    #         super().save_model(request, obj, form, change)
    #     except KeyError as e:
    #         messages.error(request, 'Помилка!')  # how to handle error correctly?
    #         logger.error(e)


class AssignRankAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'status_rgb', 'serviceman_link', 'rank_src', 'rank_dst', 'type',
                    'report_link', 'rs_order_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'rank_src__name', 'rank_dst__name', 'comment']
    list_filter = [('type', filter_name('типом')),
                   ('status', filter_name('статусом')),
                   ('action_date', filter_name('датою')),
                   ServicemanActionRankLevelFilter,
                   OrderDailyFilter,
                   OrderRsFilter,
                   ('rank_dst', filter_name('званням')),
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['serviceman', 'report', 'order_rs', 'order_daily']
    fields = ['action_date', 'serviceman', 'rank_src', 'rank_dst', 'type', 'report', 'order_rs_src', 'order_rs',
              'order_daily', 'comment', 'status', 'user']
    readonly_fields = ['rank_src', 'order_rs_src', 'status', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_extract',
               'apply_assign_rank',
               'rollback_assign_rank',
               'cancel_staff_action']
    template_daily = 'daily_order_assign_rank_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'AssignRank')

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            # obj.user = request.user
            obj.rank_src = obj.serviceman.rank
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class PayoutAdmin(PersonnelFileMixin, ActionAdminBase):
    list_display = ['id', 'action_date', 'serviceman_link', 'type', 'amount',
                    'report_link', 'daily_order_link', 'comment', 'user']
    search_fields = ['action_date', 'serviceman__last_name', 'comment']
    list_filter = [('type', filter_name('типом')),
                   ('action_date', filter_name('датою')),
                   OrderDailyFilter,
                   ('user', filter_name('користувачем'))]
    autocomplete_fields = ['serviceman', 'report', 'order_daily']
    fields = ['action_date', 'serviceman', 'type', 'amount', 'amount_in_words', 'report', 'order_daily', 'comment', 'user']
    readonly_fields = ['amount_in_words', 'user']
    ordering = ['-action_date']
    actions = ['create_doc_file_for_daily_order',
               'create_doc_file_extract',
               # 'apply_payout',
               # 'rollback_payout'
               ]
    template_daily = 'daily_order_payout_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Payout')


class MissionAdmin(PersonnelFileMixin, admin.ModelAdmin):
    list_display = ['mission_id', 'name', 'start_date', 'end_date', 'status', 'description',
                    'participant_count', 'losses_count', 'user']
    search_fields = ['name', 'description']
    list_filter = [('start_date', filter_name('датою')),
                   ('user', filter_name('Користувачем'))]
    fields = ['mission_id', 'name',
              ('start_date', 'end_date'),
              'description', 'reason', 'place',
              'participant_count', 'status', 'user']
    readonly_fields = ['participant_count', 'status', 'user']
    ordering = ['-start_date']
    list_per_page = 20

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)

    def participant_count(self, obj):
        result = MissionParticipant.objects.filter(mission=obj).count()
        link = f'/admin/personnel/missionparticipant/?mission={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    participant_count.short_description = 'Учасники'

    def losses_count(self, obj):
        result = Losses.objects.filter(mission=obj).count()
        link = f'/admin/personnel/losses/?mission={obj.id}'
        return format_html('<a href="%s">%s</a>' % (link, result))

    losses_count.short_description = 'Втрати'


class MissionParticipantResource(resources.ModelResource):
    mission = Field(column_name='Місія', attribute='mission__name')
    serviceman_rank = Field(column_name='Звання')
    serviceman_full_name = Field(column_name='ПІБ')
    serviceman_staff_full_name = Field(column_name='Посада')
    start_date = Field(column_name='Дата початку', attribute='start_date',
                       widget=DateWidget(format='%d.%m.%Y'))
    end_date = Field(column_name='Дата закінчення', attribute='end_date',
                     widget=DateWidget(format='%d.%m.%Y'))
    comment = Field(column_name='Коментар', attribute='comment')

    def dehydrate_serviceman_rank(self, obj):
        return obj.serviceman.rank.name

    def dehydrate_serviceman_full_name(self, obj):
        return obj.serviceman.full_name_upper

    def dehydrate_serviceman_staff_full_name(self, obj):
        return obj.serviceman.staff_full_name2


class MissionParticipantAdmin(PersonnelFileMixin, ServicemanBaseAdmin, ExportActionModelAdmin):
    list_display = ['id', 'serviceman_link', 'staff_link', 'mission_link', 'start_date', 'end_date', 'comment',
                    'on_vacation', 'on_trip', 'on_hospitalization', 'is_lost', 'user']
    search_fields = ['mission__name', 'serviceman__last_name', 'comment']
    list_filter = [MissionFilter,
                   MissionParticipantInActionFilter,
                   ServicemanActionRankLevelFilter,
                   ('user', filter_name('Користувачем'))]
    autocomplete_fields = ['serviceman']
    fields = ['mission', 'serviceman', 'staff_link', 'comment', 'start_date', 'end_date', 'user']
    readonly_fields = ['user', 'staff_link']
    # ordering = ['serviceman']
    actions = ['create_combat_operations_f6']
    resource_classes = [MissionParticipantResource]

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)

    def staff_link(self, obj):
        return obj.serviceman.staff_link

    staff_link.short_description = 'Штат'
    # staff_link.admin_order_field = 'staff__staff_id'

    def mission_link(self, obj):
        link = reverse("admin:personnel_mission_change", args=[obj.mission.id])
        return format_html('<a href="%s">%s</a>' % (link, obj.mission))

    mission_link.short_description = 'Бойова місія'
    mission_link.admin_order_field = 'mission__mission_id'


class ImportAdmin(PersonnelFileMixin, admin.ModelAdmin):
    list_display = ['id', 'date', 'type', 'description', 'save_data', 'file', 'user']
    # search_fields = ['name']
    list_filter = ['date', 'type', 'user']
    fields = ['date', 'type', 'description', 'save_data', 'file', 'user']
    readonly_fields = ['user']
    ordering = ['-date']
    actions = ['import_from_file']
    list_per_page = 20

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class LossesResource(resources.ModelResource):
    type_name = Field(column_name='Тип')
    serviceman_rank = Field(column_name='Звання')
    serviceman_rank_level = Field(column_name='Склад')
    serviceman_full_name = Field(column_name='ПІБ')
    serviceman_staff_full_name = Field(column_name='Посада')
    action_date = Field(column_name='Дата реєстрації', attribute='action_date',
                        widget=DateWidget(format='%d.%m.%Y'))
    loss_date = Field(column_name='Дата втрати', attribute='loss_date',
                      widget=DateWidget(format='%d.%m.%Y'))
    loss_place = Field(column_name='Місце втрати', attribute='loss_place')
    description = Field(column_name='Опис події', attribute='description')
    report_out = Field(column_name='Рапорт (початок)')
    order_out = Field(column_name='Наказ (початок)')
    report_in = Field(column_name='Рапорт (закінчення)')
    order_in = Field(column_name='Наказ (закінчення)')
    comment = Field(column_name='Коментар', attribute='comment')

    def dehydrate_type_name(self, obj):
        return obj.get_type_display()

    def dehydrate_serviceman_rank(self, obj):
        return obj.serviceman.rank.name

    def dehydrate_serviceman_rank_level(self, obj):
        return obj.serviceman.rank.rank_level

    def dehydrate_serviceman_full_name(self, obj):
        return obj.serviceman.full_name_upper

    def dehydrate_serviceman_staff_full_name(self, obj):
        return obj.serviceman.staff_full_name2

    def dehydrate_report_out(self, obj):
        return obj.report.short_name if obj.report else ''

    def dehydrate_order_out(self, obj):
        return obj.order_daily.short_name if obj.order_daily else ''

    def dehydrate_report_in(self, obj):
        return obj.report_in.short_name if obj.report_in else ''

    def dehydrate_order_in(self, obj):
        return obj.order_daily_in.short_name if obj.order_daily_in else ''


class LossesAdmin(ActionAdminBase, ExportActionModelAdmin):  #PreservedFormDataMixin, DocFileMixin,
    list_display = ['id', 'action_date', 'type', 'serviceman_link', 'loss_date', 'loss_place', 'description',
                    'report_link', 'daily_order_link', 'report_in_link', 'daily_order_in_link',
                    'comment', 'user']
    search_fields = ['serviceman__last_name', 'comment']
    fields = ['action_date', 'type', 'serviceman', 'serviceman_staff_link',
              'loss_date', 'loss_place', 'mission', 'description',
              'report', 'order_daily', 'file1', 'file2',
              'report_in', 'order_daily_in',
              'comment', 'user']
    autocomplete_fields = ['serviceman', 'report', 'order_daily', 'report_in', 'mission', 'order_daily_in']
    readonly_fields = ['serviceman_staff_link', 'user']
    list_filter = [('type', filter_name('Типом')),
                   ServicemanInStaffIllegallyFilter,
                   ServicemanActionRankLevelFilter,
                   OrderDailyFilter,
                   MissionFilter,
                   UnitCombatGroupFilter,
                   ('action_date', filter_name('Датою реєстрації')),
                   ('user', filter_name('Користувачем'))]
    resource_classes = [LossesResource]

    def report_in_link(self, obj):
        if obj.report_in:
            link = reverse("admin:documents_report_change", args=[obj.report_in.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.report_in.short_name))
        else:
            return '-'

    report_in_link.short_description = 'Рапорт (закінчення)'
    report_in_link.admin_order_field = 'report_in__input_id'

    def daily_order_in_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.order_daily_in.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.order_daily_in.short_name))

    daily_order_in_link.allow_tags = True
    daily_order_in_link.short_description = 'Добовий наказ (закінчення)'
    daily_order_in_link.admin_order_field = 'order_daily_in__order_id'

    def serviceman_staff_link(self, obj):
        return obj.serviceman.staff_link

    serviceman_staff_link.short_description = 'Штат'


admin.site.register(Serviceman, ServicemanAdmin)
admin.site.register(ServicemanAtDisposal, ServicemanAtDisposalAdmin)
admin.site.register(ServicemanAttached, ServicemanAttachedAdmin)
admin.site.register(ServicemanIllegallyAbsent, ServicemanIllegallyAbsentAdmin)
admin.site.register(Rank, RankAdmin)
admin.site.register(Position, PositionAdmin)
admin.site.register(PositionCategory, PositionCategoryAdmin)
admin.site.register(Unit, UnitAdmin)
admin.site.register(UnitGroup, UnitGroupAdmin)
admin.site.register(UnitCombatGroup, UnitCombatGroupAdmin)
admin.site.register(Location, LocationAdmin)
admin.site.register(Assignee, AssigneeAdmin)
admin.site.register(Tariff, TariffAdmin)
admin.site.register(Staff, StaffAdmin)
admin.site.register(Acceptance, AcceptanceAdmin)
admin.site.register(Movement, MovementAdmin)
admin.site.register(TakeOut, TakeOutAdmin)
admin.site.register(Dismissal, DismissalAdmin)
admin.site.register(TemporaryActing, TemporaryActingAdmin)
admin.site.register(AssignRank, AssignRankAdmin)
admin.site.register(Payout, PayoutAdmin)
admin.site.register(Mission, MissionAdmin)
admin.site.register(MissionParticipant, MissionParticipantAdmin)
admin.site.register(Import, ImportAdmin)
admin.site.register(Losses, LossesAdmin)
