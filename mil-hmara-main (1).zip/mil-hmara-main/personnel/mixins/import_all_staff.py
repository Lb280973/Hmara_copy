from django.contrib import messages
from datetime import datetime
from personnel.models import UnitCombatGroup
from personnel.models import UnitGroup
from personnel.models import Unit
from personnel.models import Rank
from personnel.models import Position
from personnel.models import Tariff
from personnel.models import Serviceman
from personnel.models import Staff
from personnel.models import PositionCategory
from documents.models import Order
from documents.models import OrderType
import re


###############################
# loading all data from excel template including staff and serviceman
# during import all dependent entities will be created
###############################
class ImportFullStaff:

    def __init__(self, req, ws):
        self.request = req
        self.worksheet = ws
        # define counters for numbers
        self.ug_max_number = 1  # unit_group
        self.ucg_max_number = 1  # unit_combat_group
        self.unit_max_number = 1
        self.rank_max_number = 1
        self.pos_max_number = 1  # position
        self.tr_max_number = 1  # tariff
        self.staff_max_number = 1  # staff
        self.pc_max_number = 1  # position category
        self.sm_max_number = 1  # serviceman
        self.order_type = self.define_order_type()

    def load_full_staff(self, save):
        total = 0
        loaded = 0

        # # Loop over rows and create `Parameters()` objects with column data
        # # (?) row_offset=1 is used if you have a header row in your file, you want to skip it
        # # (?) otherwise use 0 or delete the row_offset parameter, since 0 is default
        # # (?) for row in ws.iter_rows(row_offset=2): (min_row=2)
        for row in self.worksheet.iter_rows(min_row=2):
            staff_row_data = self.fill_import_row_struct(row)
            # self.import_unit_group(staff_row_data)
            # self.import_unit_combat_group(staff_row_data)
            # self.import_position_category(staff_row_data)
            # self.import_tariff(staff_row_data)
            self.import_unit(staff_row_data)
            #
            # self.import_position(staff_row_data)
            # self.import_rank(staff_row_data)
            sm_model = self.import_serviceman(staff_row_data)
            self.import_order(staff_row_data, sm_model)

            self.import_staff(staff_row_data)

            total = total + 1
            loaded = loaded + 1

        return total, loaded

    @staticmethod
    def get_import_struct():
        return dict({
            "org_data": {
                "number": 1,
                "org_entry_short_name": "",
                "org_entry_long_name": "",
                "dep1": "",
                "dep2": "",
                "dep3": "",
                "dep4": "",
                "org_entry_code": "",
                "org_entry_rank": "",
                "org_entry_rank_category": "",
                "org_entry_rate_common": 0,
                "org_entry_rate_temp": 0,
            },
            "personal_data": {
                "rank": "",  # звання
                "rank_category": "",  # категорія звання (солдат, сержант, офіцер)
                "full_name": "",  # ПІБ
                "last_name": "",  # прізвище
                "first_name": "",  # ім’я
                "second_name": "",  # по батькові
                "birthdate": "",  # дата народження
                "phone": "",  # телефон
                "tax_id": "",  # ІПН
                "registration_address": "",  # місце прописки
                "sex": "",  # стать
                "arrival_date": "",  # дата зарахування до списків частини
                "arrival_order_num": "",  # № наказ по сч про зарахування
                "arrival_order_date": "",  # дата наказу по сч про зарахування
                "oath_date": "",  # дата прийняття присяги
                "battle_part_cert": "",  # посвідчення УБД
                "employment_type": "",  # тип призову (мобілізація, контракт, строкова)
                "assignment_order_num": "",  # номер наказу по ОС про призначення
                "assignment_order_date": "",  # дата наказу по ОС про призначення
                "assignment_order_owner": "",  # хто видав наказ по ОС про призначення
                "rank_order_num": "",  # номер наказу по ОС про присвоєння звання
                "rank_order_date": "",  # дата наказу по ОС про присвоєння звання
                "rank_order_owner": "",  # хто видав наказу по ОС про присвоєння звання
                "blood": "",  # група крові
                "education": "",  # освіта
            }
        })

    @staticmethod
    def resolve_blood(blood_val: str):
        gr = ""
        if blood_val.find("(I)") != -1:
            gr = "0"
        if blood_val.find("(II)") != -1:
            gr = "A"
        if blood_val.find("(III)") != -1:
            gr = "B"
        if blood_val.find("(IV)") != -1:
            gr = "AB"
        if blood_val.find("-") != -1:
            gr += "-"
        if blood_val.find("+") != -1:
            gr += "+"
        return gr

    def fill_import_row_struct(self, row):
        # print("Row: ")
        # print(row)

        row_struct = self.get_import_struct()
        row_struct["org_data"]["number"] = row[0].value
        row_struct["org_data"]["org_entry_short_name"] = row[1].value
        row_struct["org_data"]["org_entry_long_name"] = row[2].value
        row_struct["org_data"]["dep1"] = row[3].value
        row_struct["org_data"]["dep2"] = row[4].value
        row_struct["org_data"]["dep3"] = row[5].value
        row_struct["org_data"]["dep4"] = row[6].value
        row_struct["org_data"]["org_entry_code"] = row[7].value
        row_struct["org_data"]["org_entry_rank"] = row[8].value
        row_struct["org_data"]["org_entry_rank_category"] = row[9].value
        row_struct["org_data"]["org_entry_rate_common"] = row[10].value
        row_struct["org_data"]["org_entry_rate_temp"] = row[11].value

        row_struct["personal_data"]["rank"] = row[12].value
        row_struct["personal_data"]["rank_category"] = row[13].value
        row_struct["personal_data"]["full_name"] = row[14].value
        row_struct["personal_data"]["birthdate"] = row[15].value
        row_struct["personal_data"]["phone"] = row[16].value
        row_struct["personal_data"]["tax_id"] = row[17].value
        row_struct["personal_data"]["registration_address"] = row[18].value
        row_struct["personal_data"]["sex"] = row[19].value
        row_struct["personal_data"]["arrival_date"] = row[20].value
        row_struct["personal_data"]["arrival_order_num"] = row[21].value
        row_struct["personal_data"]["arrival_order_date"] = row[22].value
        row_struct["personal_data"]["oath_date"] = row[23].value
        row_struct["personal_data"]["battle_part_cert"] = row[24].value
        row_struct["personal_data"]["employment_type"] = row[25].value
        row_struct["personal_data"]["assignment_order_num"] = row[26].value
        row_struct["personal_data"]["assignment_order_date"] = row[27].value
        row_struct["personal_data"]["assignment_order_owner"] = row[28].value
        row_struct["personal_data"]["rank_order_num"] = row[29].value
        row_struct["personal_data"]["rank_order_date"] = row[30].value
        row_struct["personal_data"]["rank_order_owner"] = row[31].value
        row_struct["personal_data"]["blood"] = row[32].value
        row_struct["personal_data"]["education"] = row[33].value

        return row_struct

    # підрозділи категорії
    def import_unit_group(self, staff_row_data):
        ug_name = staff_row_data["org_data"]["dep1"]
        ug = UnitGroup.objects.filter(name__iexact=ug_name)
        if len(ug) > 0:
            # print("update ug " + ug_name)
            # messages.info(self.request, f'Оновлено підрозділ категорію: {ug[0].name}')
            self.ug_max_number = ug[0].group_id
            return ug[0].id
        else:
            print("create ug " + ug_name)
            ug = UnitGroup.objects.create(name=ug_name, group_id=self.ug_max_number)
            # messages.info(self.request, f'Створено підрозділ категорію: {ug.id}')
            self.ug_max_number += 1
            return ug.id

    # підрозділи групи БЧС
    def import_unit_combat_group(self, staff_row_data):
        ucg_name = staff_row_data["org_data"]["dep2"]
        ucg = UnitCombatGroup.objects.filter(name__iexact=ucg_name)
        ug_id = self.import_unit_group(staff_row_data)
        if len(ucg) > 0:
            print("update ucg " + ucg_name)
            self.ucg_max_number = ucg[0].group_id
            return ucg[0].id
        else:
            print("create ucg " + ucg_name)
            ucg = UnitCombatGroup.objects.create(name=ucg_name, group_id=self.ug_max_number, unit_group_id=ug_id)
            self.ucg_max_number += 1
            return ucg.id

    # ШПК
    def import_position_category(self, staff_row_data):
        pc_name = staff_row_data["org_data"]["org_entry_rank"]
        rank_lvl = staff_row_data["org_data"]["org_entry_rank_category"]
        pc = PositionCategory.objects.filter(name__iexact=pc_name)
        if len(pc) > 0:
            # print("update position category " + pc_name)
            self.pc_max_number = pc[0].position_category_id
            return pc[0].id
        else:
            rank_level_id = self.resolve_rank_level(rank_lvl)
            print("create position category " + pc_name)
            pc = PositionCategory.objects.create(name=pc_name,
                                                 position_category_id=self.pc_max_number,
                                                 rank_level=rank_level_id)
            self.pc_max_number += 1
            return pc.id

    @staticmethod
    def resolve_rank_level(rank: str):
        if rank.lower() == "офіцер":
            return 3
        elif rank.lower() == "сержант":
            return 2
        else:
            return 1

    # тарифний розряд
    @staticmethod
    def import_tariff(staff_row_data):
        tr_code = str(staff_row_data["org_data"]["org_entry_rate_common"])
        if tr_code == "None":
            tr_code = "0"
        tr = Tariff.objects.filter(tariff_id__iexact=tr_code)
        if len(tr) > 0:
            return tr[0].id
        else:
            print("create tariff " + tr_code)
            tr = Tariff.objects.create(tariff_id=tr_code, bonus1=100, bonus2=100, salary=100)
            return tr.id

    # підрозділи
    def import_unit(self, staff_row_data):
        dep2 = staff_row_data["org_data"]["dep2"]
        dep3 = staff_row_data["org_data"]["dep3"]
        dep4 = staff_row_data["org_data"]["dep4"]

        unit_id = None

        group_id = self.import_unit_group(staff_row_data)
        combat_group_id = self.import_unit_combat_group(staff_row_data)
        if dep2:
            unit_id = self.create_or_update_unit(dep2, dep2, None, group_id, combat_group_id)
            if dep3:
                gen_unit = Unit()
                gen_unit.full_name = dep2
                full_name = dep3 + " " + gen_unit.in_genitive
                unit_id = self.create_or_update_unit(dep3, full_name, unit_id, group_id, combat_group_id)
                if dep4:
                    dep2gen = gen_unit.in_genitive
                    gen_unit.full_name = dep3 + " " + dep2gen
                    full_name = dep4 + " " + gen_unit.in_genitive
                    unit_id = self.create_or_update_unit(dep4, full_name, unit_id, group_id, combat_group_id)
        return unit_id

    # create unit considering hierarchy
    def create_or_update_unit(self, unit_name, unit_full_name, parent_id, group_id, combat_group_id):
        dep_unit = Unit.objects.filter(full_name__iexact=unit_full_name)
        if len(dep_unit) > 0:
            self.unit_max_number = dep_unit[0].unit_id
            return dep_unit[0].id
        else:
            print("create unit " + unit_full_name)
            dep_unit = Unit.objects.create(name=unit_name,
                                           unit_id=self.unit_max_number,
                                           full_name=unit_full_name,
                                           parent_unit_id=parent_id,
                                           group_id=group_id,
                                           combat_group_id=combat_group_id)
            self.unit_max_number += 1
            return dep_unit.id

    # посада
    def import_position(self, staff_row_data):
        pos_name = staff_row_data["org_data"]["org_entry_short_name"]
        mil_spec = staff_row_data["org_data"]["org_entry_code"]
        tariff_id = self.import_tariff(staff_row_data)
        pos_cat_id = self.import_position_category(staff_row_data)

        pos = Position.objects.filter(name__iexact=pos_name,
                                      milspec__iexact=str(mil_spec),
                                      tariff_id=tariff_id)
        if len(pos) > 0:
            # print("update position " + pos_name)
            self.pos_max_number = pos[0].position_id
            return pos[0].id
        else:
            print("create position " + pos_name + " (" + str(mil_spec) + ")")
            pos = Position.objects.create(name=pos_name,
                                          position_id=self.pos_max_number,
                                          milspec=mil_spec,
                                          position_category_id=pos_cat_id,
                                          tariff_id=tariff_id)
            self.pos_max_number += 1
            return pos.id

    # звання
    def import_rank(self, staff_row_data):
        rank_name = staff_row_data["personal_data"]["rank"]
        # skip import vacant (empty rank)
        if not rank_name:
            return None
        rank = Rank.objects.filter(name__iexact=rank_name)
        if len(rank) > 0:
            # print("update position " + pos_name)
            self.rank_max_number = rank[0].rank_id
            return rank[0].id
        else:
            print("create rank " + rank_name)
            rank = Rank.objects.create(name=rank_name,
                                       rank_id=self.rank_max_number)
            self.rank_max_number += 1
            return rank.id

    @staticmethod
    def parse_and_check_date(birthdate):
        date_of_birth = None
        if isinstance(birthdate, datetime):
            date_of_birth = birthdate
        else:
            if isinstance(birthdate, str):
                # check if birthdate format is ( dd.mm.yyyy )
                pattern = re.compile("^([\d]{2}.[\d]{2}.[\d]{4})$")
                if pattern.match(birthdate):
                    date_of_birth = datetime.strptime(birthdate, "%d.%m.%Y")
        return date_of_birth

    # військовослужбовець
    def import_serviceman(self, staff_row_data):
        sm_full_name = staff_row_data["personal_data"]["full_name"]
        rank_id = self.import_rank(staff_row_data)
        # skip import vacant (empty name)
        if not sm_full_name or not rank_id:
            return None
        parts = sm_full_name.strip().split(' ', 2)
        if len(parts) > 2:
            ln = parts[0]
            fn = parts[1]
            sn = parts[2]
        else:
            return None
        tax_id = staff_row_data["personal_data"]["tax_id"]

        sm = Serviceman.objects.filter(first_name__iexact=fn,
                                       second_name__iexact=sn,
                                       last_name__iexact=ln,
                                       tax_id=tax_id)
        if len(sm) > 0:
            # print("update serviceman " + pos_name)
            self.sm_max_number = sm[0].serviceman_id
            sm_model = sm[0]
        else:
            print("create serviceman " + sm_full_name + " (" + str(tax_id) + ")")
            phone_number = staff_row_data["personal_data"]["phone"]
            birthdate = staff_row_data["personal_data"]["birthdate"]
            date_of_birth = self.parse_and_check_date(birthdate)

            sex = 0
            if staff_row_data["personal_data"]["sex"] == "ч":
                sex = 1
            elif staff_row_data["personal_data"]["sex"] == "ж":
                sex = 2
            education = staff_row_data["personal_data"]["education"]
            rank_order_ext = \
                str(staff_row_data["personal_data"]["rank_order_num"]) + \
                " " + \
                str(staff_row_data["personal_data"]["rank_order_owner"])

            roed = staff_row_data["personal_data"]["rank_order_date"]
            rank_order_ext_date = self.parse_and_check_date(roed)

            emp_type = staff_row_data["personal_data"]["employment_type"]
            service_type = "MOB"
            if emp_type == "контракт":
                service_type = "CNT"
            elif emp_type == "строковик":
                service_type = "CNS"
            blood = staff_row_data["personal_data"]["blood"]
            blood_type = None
            if blood:
                print("Blood: [" + str(blood) + "] " + self.resolve_blood(blood))
                blood_type = self.resolve_blood(blood)
            print("Service_type: " + service_type)
            sm = Serviceman.objects.create(first_name=fn,
                                           second_name=sn,
                                           last_name=ln,
                                           tax_id=tax_id,
                                           date_of_birth=date_of_birth,
                                           phone_number=phone_number,
                                           sex=sex,
                                           rank_id=rank_id,
                                           education=education,
                                           serviceman_id=self.sm_max_number,
                                           rank_order_ext_date=rank_order_ext_date,
                                           rank_order_ext=rank_order_ext,
                                           service_type=service_type,
                                           blood_type=blood_type
                                           )
            self.sm_max_number += 1
            sm_model = sm
        return sm_model

    # штатна посада
    def import_staff(self, staff_row_data):
        number = staff_row_data["org_data"]["number"]
        staff_name = staff_row_data["org_data"]["org_entry_short_name"]

        staff = Staff.objects.filter(name__iexact=staff_name,
                                     staff_id=number)
        if len(staff) > 0:
            # print("update staff " + pos_name)
            self.staff_max_number = staff[0].staff_id
            return staff[0].id
        else:
            comment = "Imported"
            print("create staff [" + str(number) + "] " + staff_name)
            position_id = self.import_position(staff_row_data)
            serviceman_model = self.import_serviceman(staff_row_data)
            if serviceman_model is None:
                sm_id = None
            else:
                sm_id = serviceman_model.id
            unit_id = self.import_unit(staff_row_data)
            start_date = datetime.strptime("24.02.2022", '%d.%m.%Y')

            staff = Staff.objects.create(name=staff_name,
                                         staff_id=number,
                                         comment=comment,
                                         position_id=position_id,
                                         serviceman_id=sm_id,
                                         unit_id=unit_id,
                                         date_start=start_date)
            self.staff_max_number += 1
            return staff.id

    # тип наказу
    def define_order_type(self):
        order_type_name = 'по стройовій частині'
        order_type = OrderType.objects.filter(name__iexact=order_type_name)
        if len(order_type) > 0:
            # print("update position " + pos_name)
            return order_type[0].id
        else:
            print("create order type " + order_type_name)
            order_type = OrderType.objects.create(name=order_type_name,
                                                  order_type_id=1,
                                                  dsk=False)
            return order_type.id

    # імпорт наказу
    def import_order(self, staff_row_data, sm_model):
        order_num = staff_row_data["personal_data"]["arrival_order_num"]
        order_date = self.parse_and_check_date(staff_row_data["personal_data"]["arrival_order_date"])
        # skip import empty order_num
        if not order_num or not order_date:
            return None

        order = Order.objects.filter(order_id=order_num,
                                     date=order_date,
                                     order_type_id=self.order_type)
        if len(order) > 0:
            order_model = order[0]
        else:
            print("create order #" + str(order_num) + " from " + str(order_date))
            order = Order.objects.create(name="по стройовій частині",
                                         order_id=order_num,
                                         date=order_date,
                                         by="командира військової частини",
                                         comment="Імпортовано з Ексель",
                                         type="по стройовій частині",
                                         order_type_id=self.order_type,
                                         status=Order.Status.DONE.value)
            order_model = order

        self.import_order_mentioned(order_model, sm_model)
        return order_model

    @staticmethod
    def import_order_mentioned(order_model: Order, serviceman_model):
        if not order_model or not serviceman_model:
            return None
        if order_model.mentioned.filter(serviceman_id=serviceman_model.id).exists():
            return None
        order_model.mentioned.add(serviceman_model)
        return None
