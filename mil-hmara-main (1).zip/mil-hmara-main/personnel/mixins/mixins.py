import datetime
import os
import pathlib

import openpyxl
from dateutil.relativedelta import relativedelta
from django.contrib import messages
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.db.models import Q
from openpyxl.utils import column_index_from_string

from conf import settings
from documents.admin import logger
from documents.models import Order
from personnel.models import *
from personnel.views import create_excel_file_staff, create_excel_file_serviceman, create_excel_file_staff_missing
from utils.docfiles import get_docfile_response, create_doc_from_template, create_doc_from_template_queryset, \
    create_extract_from_template, create_doc_from_template_data
from .import_all_staff import ImportFullStaff

# utility functions
def find_serviceman_by_tax_id(code):
    try:
        return Serviceman.objects.get(tax_id=code)
    except Exception as ex:
        return None


def find_serviceman_by_name(ln, fn, sn):
    return Serviceman.objects.filter(last_name__iexact=ln, first_name__iexact=fn, second_name__iexact=sn).first()


def check_serviceman_vacation_and_raise(sm):
    from documents.models import Vacation
    qs_vaca = Vacation.objects.filter(serviceman=sm,
                                      order_out__isnull=False,
                                      order_out__date__lt=datetime.today().date(),
                                      order_in__isnull=True, returned=None)
    if len(qs_vaca) > 0:
        raise ValidationError(f'{sm.short_name} у відпустці!')

def check_serviceman_trip_and_raise(sm):
    from documents.models import Trip
    qs_trip = Trip.objects.filter(serviceman=sm,
                                  order_out__isnull=False,
                                  order_out__date__lt=datetime.today().date(),
                                  order_in__isnull=True, returned=None)
    if qs_trip.count() > 0:
        raise ValidationError(f'{sm.short_name} у відрядженні!')

def check_serviceman_hospitalization_and_raise(sm):
    from documents.models import Hospitalization
    qs_hosp = Hospitalization.objects.filter(serviceman=sm,
                                             order_out__isnull=False,
                                             order_out__date__lt=datetime.today().date(),
                                             order_in__isnull=True)
    if len(qs_hosp) > 0:
        raise ValidationError(f'{sm.short_name} на лікарняному!')


def get_serviceman_at_disposal(sm, self_obj_id = None):
    # у розпорядженні
    qs_temp = ServicemanAtDisposal.objects.filter(serviceman=sm,
                                                  # order_out__isnull=False,
                                                  # order_out__date__lt=datetime.today().date(),
                                                  order_in__isnull=True).exclude(id=self_obj_id)
    return qs_temp

def get_serviceman_attached(sm, self_obj_id = None):
    # у розпорядженні
    qs_temp = ServicemanAttached.objects.filter(serviceman=sm,
                                                # order_out__isnull=False,
                                                # order_out__date__lt=datetime.today().date(),
                                                order_in__isnull=True).exclude(id=self_obj_id)
    return qs_temp

def check_serviceman_at_disposal_and_raise(sm, self_obj_id = None):
    # у розпорядженні
    qs_temp = get_serviceman_at_disposal(sm, self_obj_id)
    if len(qs_temp) > 0:
        raise ValidationError(f'{sm.short_name} у розпорядженні!')

def check_serviceman_attached_and_raise(sm, self_obj_id = None):
    # прикомандировані
    qs_temp = get_serviceman_attached(sm, self_obj_id)
    if len(qs_temp) > 0:
        raise ValidationError(f'{sm.short_name} прикомандирований!')

def check_serviceman_illegally_absent_and_raise(sm, self_obj_id = None):
    from personnel.models import ServicemanIllegallyAbsent
    # СЗЧ
    qs_illa = ServicemanIllegallyAbsent.objects.filter(serviceman=sm,
                                                       # order_out__isnull=False,
                                                       # order_out__date__lt=datetime.today().date(),
                                                       order_in__isnull=True).exclude(id=self_obj_id)
    if len(qs_illa) > 0:
        raise ValidationError(f'{sm.short_name} у СЗЧ!')

def check_serviceman_arrest_and_raise(sm, self_obj_id = None):
    # Арешт
    qs_arst = Arrest.objects.filter(serviceman=sm,
                                    # order_out__isnull=False,
                                    # order_out__date__lt=datetime.today().date(),
                                    order_in__isnull=True).exclude(id=self_obj_id)
    if len(qs_arst) > 0:
        raise ValidationError(f'{sm.short_name} під арештом!')


def check_serviceman_missing_status_and_raise(sm):
    from personnel.models import ServicemanAtDisposal, ServicemanIllegallyAbsent
    # у відпустці
    check_serviceman_vacation_and_raise(sm)
    # у відрядженні
    check_serviceman_trip_and_raise(sm)
    # на лікарняному
    check_serviceman_hospitalization_and_raise(sm)
    # # у розпорядженні - перевіряємо окремо і закриваємо при потребі
    # check_serviceman_at_disposal_and_raise(sm)
    # СЗЧ
    check_serviceman_illegally_absent_and_raise(sm)
    # Арешт
    check_serviceman_arrest_and_raise(sm)


###############################
# loading data implementation #
###############################
def load_servicemans(request, ws, save):
    data = []
    i = 0
    n = 0
    # # Loop over rows and create `Parameters()` objects with column data
    # # (?) row_offset=1 is used if you have a header row in your file, you want to skip it
    # # (?) otherwise use 0 or delete the row_offset parameter, since 0 is default
    # # (?) for row in ws.iter_rows(row_offset=2): (min_row=2)
    for row in ws.iter_rows():
        i = i + 1
        rank = row[0].value
        name = row[1].value
        birthday = row[2].value
        code = row[3].value
        number = row[4].value
        parts = name.split(' ')
        ln = parts[0]
        fn = parts[1]
        sn = parts[2]
        if code:
            sm = Serviceman.objects.filter(tax_id=code)
            if len(sm) > 0:
                print(f'(!!!) tax_id {code} already exists!')
                continue
        else:
            print(f'(!!!) name: {name}, no tax_id')

        sm2 = Serviceman.objects.filter(last_name__iexact=ln, first_name__iexact=fn, second_name__iexact=sn)
        if len(sm2):
            messages.info(request, f'Оновлено: {sm2[0]}')
            sm2[0].tax_id = code
            if birthday:
                sm2[0].date_of_birth = datetime.strptime(birthday, "%d.%m.%Y")
            if save:
                sm2[0].save()

        n = n + 1
        rank_obj = Rank.objects.filter(name__iexact='солдат')[0]
        r = Rank.objects.filter(name__iexact=rank)
        if len(r) > 0:
            rank_obj = r[0]

        serviceman = Serviceman()
        serviceman.serviceman_id = number
        serviceman.rank = rank_obj
        serviceman.first_name = fn
        serviceman.last_name = ln
        serviceman.second_name = sn
        serviceman.tax_id = code
        if birthday:
            # convert birthday type from datetime.datetime to string
            if isinstance(birthday, datetime):
                serviceman.date_of_birth = birthday
            else:
                serviceman.date_of_birth = datetime.strptime(birthday, "%d.%m.%Y")

        data.append(serviceman)
        # print(f'({rank_obj.name if rank_obj else "-"}) {n}, {serviceman.extended_name} {type(birthday)} {birthday}')

    # # for item in data:
    # #     print(f'{item.serviceman_id};')
    # # Bulk create data
    if save:
        Serviceman.objects.bulk_create(data)
    return i, n


def load_mission_parts(request, ws):
    messages.warning(request, 'Under construction!')
    return 0, 0


def load_disposals(request, ws, save):
    # messages.warning(request, 'Under construction!')
    data = []
    i = 0
    n = 0
    # # Loop over rows and create `Parameters()` objects with column data
    # # (?) row_offset=1 is used if you have a header row in your file, you want to skip it
    # # (?) otherwise use 0 or delete the row_offset parameter, since 0 is default
    # # (?) for row in ws.iter_rows(row_offset=2): (min_row=2)
    for row in ws.iter_rows():
        i = i + 1
        no = row[0].value
        code = row[1].value
        ln = row[2].value
        fn = row[3].value
        sn = row[4].value
        sm = find_serviceman_by_tax_id(code)
        if sm:
            print(f'{no} tax_id {code} found: {sm.full_name}')
        else:
            print(f'{no} (!!!) tax_id {code}, not found! {ln} {fn} {sn}')
            sm = find_serviceman_by_name(ln, fn, sn)
            if sm:
                messages.info(request, f'Found by full name: {sm}, tax_id updated')
                sm.tax_id = code
                if save:
                    sm.save()
            else:
                messages.error(request, f'row: {no} - serviceman not found: {ln} {fn} {sm}')
                continue

        n = n + 1

        disp = ServicemanAtDisposal()
        disp.serviceman = sm
        disp.date_from = datetime.now()
        data.append(disp)

    for item in data:
        print(f'{item.serviceman};')
    # # Bulk create data
    if save:
        ServicemanAtDisposal.objects.bulk_create(data)

    return i, n


def load_service_term(request, ws, save):
    i = 0
    n = 0
    # # Loop over rows and create `Parameters()` objects with column data
    # # (?) row_offset=1 is used if you have a header row in your file, you want to skip it
    # # (?) otherwise use 0 or delete the row_offset parameter, since 0 is default
    # # (?) for row in ws.iter_rows(row_offset=2): (min_row=2)
    for row in ws.iter_rows():
        i = i + 1
        dt = row[0].value
        ln = row[2].value
        fn = row[3].value
        sn = row[4].value
        years = row[6].value
        text = row[7].value
        sm = find_serviceman_by_name(ln, fn, sn)
        if sm:
            messages.info(request, f'Found by full name: {sm}, updated')
            sm.service_term_start_date = dt
            sm.service_term_text = text
            sm.service_term_years = years
            if save:
                sm.save()
        else:
            messages.error(request, f'row: {i} - serviceman not found: {ln} {fn} {sm}')
            continue

        n = n + 1

    return i, n


def get_col_by_name(ws, name):
    for col in ws.iter_cols(1, ws.max_column):
        if col[0].value == name:
            print(col)
            return col


def load_service_periods(request, ws, save):
    n = 0
    col_tax_id = 13  #ws.cell('N0').col_idx #13  # get_col_by_name(ws, 'ІПН')
    col_sp = 24 # get_col_by_name(ws, 'Періоди служби')
    col_ed = 25 # get_col_by_name(ws, 'Освіта')
    col_rd = 26 # get_col_by_name(ws, 'Дата присвоєння звання (інша в/ч)')
    for i, row in enumerate(ws.iter_rows()):
        print(i)
        if i==0:
            continue
        code = row[col_tax_id].value  # row[col_tax_id].value
        if not code:
            print('skipped empty tax id')
            continue
        print(code)
        sm = find_serviceman_by_tax_id(code)
        ed = row[col_ed].value
        sp = row[col_sp].value
        rd = row[col_rd].value
        print(f'{sm} - "{ed}" - "{sp}" - "{rd}"')
        if sm:
            messages.info(request, f'Found by tax id: {sm}, updated')
            sm.service_periods = sp
            sm.education = ed
            sm.rank_order_ext_date = rd
            if save:
                sm.save()
        else:
            messages.error(request, f'row: {i} - serviceman not found: {code}')
            continue

        n = n + 1

    return i, n


def get_losses_type(tp):
    if tp == 'загиблий':
        return 'CDEA'
    elif tp == 'зниклий безвісти':
        return 'MIS'
    elif tp == 'помер':
        return 'DEA'
    elif tp == 'полон':
        return 'CAP'
    else:    ## tp == 'поранений':
        return None


def get_service_type(st):
    # if st == 'призваний за мобілізацією':
    #     return 'MOB'
    if st == 'контракт':
        return 'CNT'
    elif st == 'строкова':
        return 'CNS'
    else:
        return 'MOB'


def get_date(dt):
    if type(dt) is datetime:
        return dt
    elif type(dt) is str:
        try:
            return datetime.strptime(dt.strip(), "%d.%m.%Y")
        except Exception as ex:
            print(f'[ERROR] Помилка при конвертації дати: "{dt}"')
            # messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
            return None
    else:
        return None


def load_losses(request, ws, save):
    data = []
    n = 0
    col_tax_id = 4
    col_passport = 5
    col_service_type = 6 # add processing
    col_birthdate = 9 # add processing
    col_birthplace = 10 # add new column and processing
    col_commissariat = 11 # add new column and processing
    col_type = 12
    col_loss_date = 14
    col_description = 15
    col_loss_place = 16
    col_relatives = 17

    for i, row in enumerate(ws.iter_rows()):
        try:
            if i==0:
                continue
            code = row[col_tax_id].value  # row[col_tax_id].value
            if not code or not type(code) is int:
                print('skipped empty tax id')
                continue
            print(code)
            sm = find_serviceman_by_tax_id(code)
            if not sm:
                print(f'Tax id not found: {code}')
                messages.warning(request, f'Tax id not found: {code}')
                continue

            tp = get_losses_type(row[col_type].value)
            pas = row[col_passport].value
            # srv = row[col_service_type].value  # parse it!
            bdt = get_date(row[col_birthdate].value)
            bpl = row[col_birthplace].value
            com = row[col_commissariat].value
            lsd = get_date(row[col_loss_date].value)
            lsp = row[col_loss_place].value
            des = row[col_description].value
            rel = row[col_relatives].value

            if sm.passport is None:
                sm.passport = pas
            if sm.relatives is None:
                sm.relatives = rel
            # sm.service_type = srv
            if sm.date_of_birth is None:
                sm.date_of_birth = bdt
            if sm.birthplace is None:
                sm.birthplace = bpl
            if sm.commissariat is None:
                sm.commissariat = com
            if sm.relatives is None:
                sm.relatives = rel

            if save:
                sm.save()

            n = n + 1

            if tp:
                ls = Losses()
                ls.action_date = datetime.now()
                ls.serviceman = sm
                ls.type = tp
                ls.loss_date = lsd
                ls.loss_place = lsp
                ls.description = des
                # +notified to the commissariat
                # +Probable location of the deceased / date and place of burial
                data.append(ls)
                # print(f'{i}. {sm} - [{tp}]->[{row[col_type].value}], sm bdt: {sm.date_of_birth} - {bdt} - {type(bdt)}, {row[col_loss_date].value}')
                print(f'{i}. {sm} - [{tp}]->[{row[col_type].value}], {des}')
                messages.info(request, f'Оброблено: {sm} - [{row[col_type].value}]->[{tp}]')

        except Exception as ex:
            messages.error(request, f'Помилка: {ex}')
            # e += 1

    for item in data:
        print(f'{item};')
    # # Bulk create data
    if save:
        Losses.objects.bulk_create(data)

    return i, n

def get_cell_value(row, col_letter):
    return row[column_index_from_string(col_letter)-1].value

def load_staff(request, ws, save):
    n = 0
    skip_rows = 5
    for i, row in enumerate(ws.iter_rows()):
        if i <= skip_rows:
            continue
        code = get_cell_value(row, 'Z')
        if not code:
            print(f'i:{i}, empty tax id')
            continue
        sm = find_serviceman_by_tax_id(code)
        print(f'i:{i}, {code} - "{sm}"')
        if sm is None:
            messages.error(request, f'row: {i} - serviceman not found: {code}')
            continue

        # ed = row[col_ed].value
        # sp = row[col_sp].value
        # rd = row[col_rd].value
        # messages.info(request, f'Found by tax id: {sm}, updated')

        # sm.service_periods = sp
        # sm.education = ed
        # sm.rank_order_ext_date = rd
        if save:
            sm.save()

        n = n + 1

    return i, n


def load_payout(request, ws, save):
    n = 0
    skip_rows = 0
    for i, row in enumerate(ws.iter_rows()):
        if i <= skip_rows:
            continue
        code = get_cell_value(row, 'F')
        if not code:
            print(f'i:{i}, empty tax id')
            continue
        sm = find_serviceman_by_tax_id(code)
        print(f'i:{i}, {code} - "{sm}"')
        if sm is None:
            messages.error(request, f'row: {i} - serviceman not found: {code}')
            continue
        pay_date = get_cell_value(row, 'D')
        pay_value = float(get_cell_value(row, 'E'))
        pay_type = get_cell_value(row, 'G')
        if pay_type not in ('МД', 'ГДО'):
            messages.error(request, f'{i}, sm: {sm} - недопустимий тип виплати: {pay_type}. Має бути "МД" або "ГДО"')
            continue

        messages.info(request, f'sm: {sm}, date: {pay_date.date()}, value: {pay_value}')

        payout = Payout()
        payout.action_date = pay_date
        payout.serviceman = sm
        payout.type = Payout.PayoutType.HOUSE if pay_type == 'МД' else Payout.PayoutType.HEALTH
        payout.amount = pay_value
        payout.comment = 'імпортовано'
        if save:
            payout.save()

        n = n + 1

    return i, n


def log_action_entry(ct, request, obj, name, action = 'виконано'):
    l = LogEntry.objects.log_action(
        user_id=request.user.id,
        content_type_id=ct.pk,
        object_id=obj.pk,
        object_repr='m.status',
        action_flag=CHANGE,
        change_message=f'{name} {action}')
    # print(f'log: {l}')
    logger.info(f'[{request.user.username}] [{obj.pk}] {name} {action}')


def extract_service_term(service_term_text):
    # pattern = r"(\d+) років (\d+) місяців (\d+)"
    pattern = r"(\d+)\s*(рік?|роки?|років)\s*(\d+)\s*(місяць?|місяці?|місяця?|місяців)\s*(\d+)\s*(день?|дні?|днів)"
    matches = re.search(pattern, service_term_text)
    term = dict()
    term['years'] = 0
    term['months'] = 0
    term['days'] = 0
    if matches:
        term['years'] = int(matches.group(1))
        term['months'] = int(matches.group(3))
        term['days'] = int(matches.group(5))

        # print("Років:", years)
        # print("Місяців:", months)
        # print("Днів:", days)
    # else:
        # print("Збігів не знайдено.")

    return term


def prepare_acceptance_grouped(queryset):
    qs = queryset

    grouped_members = {}
    for member in qs:
        qs_sad = get_serviceman_at_disposal(member.serviceman)
        disposal = qs_sad.count() > 0    # з розпорядження
        reason = member.order_rs.name_verbose if member.order_rs else 'контракт'
        if disposal:
            kind = 'DISPOSAL'
        elif not member.order_rs:
            kind = 'CONTRACT'
        else:
            kind = 'EXTERNAL'
        group_name = f'{reason}_{disposal}'
        print(f'group: {group_name}')
        if group_name not in grouped_members:
            grouped_members[group_name] = {'reason': reason,
                                           'disposal': disposal,
                                           'kind': kind,
                                           'order': member.order_daily,
                                           'members': []}
        grouped_members[group_name]['members'].append({
            'acc': member
        })

    data = {'groups': list(grouped_members.values())}
    print(data)
    return data


def prepare_assign_rank_grouped(queryset):
    qs = queryset

    grouped_members = {}
    for member in qs:
        group_name = f'{member.order_rs.name_verbose}_{member.type}_{member.rank_dst.name}'
        print(group_name)
        if group_name not in grouped_members:
            grouped_members[group_name] = {'order': member.order_rs.name_verbose,
                                           'type': member.type,
                                           'rank': member.rank_dst,
                                           'members': []}
        grouped_members[group_name]['members'].append({
            'sm': member.serviceman,
            'rank_src': member.rank_src,
            'basis2': member.basis2
        })
    # print(f'grouped_members: {grouped_members}')
    data = {'groups': list(grouped_members.values())}
    # print(data)
    return data


class PersonnelFileMixin:

    def process_service_terms(self, request, queryset):
        # process service terms
        n = 0
        for sm in queryset:
            if sm.service_term_text and len(sm.service_term_text.strip()) > 0:
                term = extract_service_term(sm.service_term_text)
                # print(f'{sm}: {sm.service_term_text}, term: {term}, y: {term["years"]}')

                if sm.service_term_years != term['years']:
                    messages.warning(request, f"error: {sm.short_name} - {sm.service_term_years} - {term['years']}")
                # messages.warning(request, f"{sm.short_name} - {sm.service_term_years} - {term['years']}")

                if term['years'] == 0 and term['months'] == 0 and term['days'] == 0:
                    messages.warning(request, f'{sm.short_name}, invalid service term: {sm.service_term_text}')
                else:
                    sm.service_term_years = term['years']
                    sm.service_term_months = term['months']
                    sm.service_term_days = term['days']
                    sm.save()
                    n += 1
        return n


    # def serviceman_anonymize(self, request, queryset):
    #     import random
    #     # anonymization
    #     from faker import Faker
    #     fake = Faker('uk_UA')
    #     n = 0
    #     for sm in queryset:
    #         # messages.info(request, f'{sm.first_name} {sm.last_name}')
    #         sm.first_name = fake.first_name_male() if sm.sex == Serviceman.Sex.MALE else fake.first_name_female()
    #         sm.last_name = fake.last_name()
    #         if sm.tax_id:
    #             sm.tax_id = str(int(sm.tax_id) + 333)
    #         if sm.date_of_birth:
    #             sm.date_of_birth = date(random.randint(1965, 2003), random.randint(1, 12), random.randint(1, 28))
    #         if sm.phone_number:
    #             sm.phone_number = fake.phone_number()
    #         if sm.home_address:
    #             sm.home_address = fake.address()
    #         if sm.birthplace:
    #             sm.birthplace = fake.city()
    #         sm.relatives = None
    #         sm.passport = None
    #         sm.save()
    #         # messages.info(request, f'{sm.first_name} {sm.last_name}')
    #         n += 1
    #     return n

    def serviceman_test(self, request, queryset):
        print('>>> serviceman_test <<<')
        if request.user.username != 'wifi':
            raise Exception('Access denied!')

        # n = self.process_service_terms(self, request, queryset)
        # n = self.serviceman_anonymize(request, queryset)
        n = 0
        messages.success(request, f'оновлено записів: {n}')
        # for m in queryset:
        #     if not m.excluded:
        #         print("exclude_serviceman: " + m.full_name)
        #         m.excluded = True
        #         m.save()
        #     else:
        #         messages.warning(request, 'Виключення зі списків не може бути виконано!')
        #
        # messages.success(request, 'Виключення зі списків виконано')
        return True

    serviceman_test.short_description = 'Тест'

    def create_form5(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Serviceman')
        path = create_doc_from_template_queryset(request, queryset, self.template_form5, save_to)
        messages.success(request, 'Файли успішно згенеровано')
        return get_docfile_response(path)

    create_form5.short_description = 'Згенерувати форму 5'

    def create_list2order_serviceman(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Serviceman')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_serviceman_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_serviceman.short_description = 'Згенерувати список у наказ (називний)'

    def create_list2order_serviceman_accusative(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Serviceman')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_serviceman_accusative_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_serviceman_accusative.short_description = 'Згенерувати список у наказ (знахідний)'

    def create_list2order_serviceman_dative(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR,
                               f'{datetime.now().strftime("%d.%m.%Y")}_list2order.docx')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_serviceman_dative_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_serviceman_dative.short_description = 'Згенерувати список у наказ (давальний)'

    def create_list2order_staff(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Staff')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_staff_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_staff.short_description = 'Згенерувати список у наказ (називний)'

    def create_list2order_staff_accusative(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Staff')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_staff_accusative_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_staff_accusative.short_description = 'Згенерувати список у наказ (знахідний)'

    def create_list2order_staff_dative(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Staff')
        path = create_doc_from_template_queryset(request, queryset, 'list2order_staff_dative_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_list2order_staff_dative.short_description = 'Згенерувати список у наказ (давальний)'

    def create_combat_operations(self, request, queryset):
        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Serviceman')
        path = create_doc_from_template_queryset(request, queryset, 'combat_operations_template.docx', save_to)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_combat_operations.short_description = 'Згенерувати Довідки про участь у бойових діях'

    def create_combat_operations_f6(self, request, queryset):
        from personnel.admin import ServicemanAdmin
        from personnel.admin import MissionParticipantAdmin

        save_to = os.path.join(settings.DOCUMENTS_DIR, 'Serviceman')
        if type(self) == ServicemanAdmin:
            path = create_doc_from_template_queryset(request, queryset, 'combat_operations_f6_template.docx', save_to)
        elif type(self) == MissionParticipantAdmin:
            path = create_doc_from_template_queryset(request, queryset, 'combat_operations_participant_f6_template.docx', save_to)
        else:
            messages.error(request, f'Недопустимий тип списку: {type(self)}')
            return None

        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_combat_operations_f6.short_description = 'Згенерувати Довідки про участь у бойових діях (Додаток 6)'

    def create_excel_serviceman(self, request, queryset):
        print("file: " + self.save_to)
        path = create_excel_file_serviceman(self, queryset)
        messages.success(request, 'Файли успішно згенеровано')
        return get_docfile_response(path)

    create_excel_serviceman.short_description = 'Згенерувати список о/с (Excel)'

    def create_excel_staff(self, request, queryset):
        print("file: " + self.save_to)
        path = create_excel_file_staff(self, queryset)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_excel_staff.short_description = 'Згенерувати штат (Excel)'

    def create_excel_staff_missing_last_month(self, request, queryset):
        path = create_excel_file_staff_missing(self,
                                               queryset,  #.filter(serviceman__isnull=False),
                                               datetime.today().date() - relativedelta(months=1))
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_excel_staff_missing_last_month.short_description = 'Згенерувати звіт "Відсутні за попередній місяць" (Excel)'

    def create_excel_staff_missing_current_month(self, request, queryset):
        path = create_excel_file_staff_missing(self,
                                               queryset,  #.filter(serviceman__isnull=False),
                                               datetime.today().date())
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_excel_staff_missing_current_month.short_description = 'Згенерувати звіт "Відсутні за поточний місяць" (Excel)'

    def renumerate_staff(self, request, queryset):
        if request.user.username != 'wifi':
            raise Exception('Access denied!')

        qs = Staff.objects.filter(Q(date_end__isnull=True) |
                                  Q(date_end__gte=datetime.today()),
                                  #Q(serviceman__isnull=False),
                                  date_start__lte=datetime.today()
                                  ).order_by('staff_id', 'id')
        n = 0
        for s in qs:
            n += 1
            print(f'{n} - {s}')
            s.staff_id = n
            s.save()
        messages.success(request, f'Виконано! Кількість посад: {n}')
        return True

    renumerate_staff.short_description = 'Перенумерувати штат (!)'

    def make_takeout(self, request, queryset):
        if request.user.username != 'wifi':
            raise Exception('Access denied!')
        n = 0
        e = 0
        order_dl = None     # Order.objects.get(id = 633)  #115)  531) # №74
        order_rs = Order.objects.get(id = 665)  # №7777-РС
        for item in queryset:
            if not item.serviceman:
                continue
            try:
                takeout = TakeOut(action_date = datetime.today().date(),
                                  staff = item,
                                  serviceman = item.serviceman,
                                  comment = 'зміни до штату',
                                  user = request.user,
                                  order_daily = order_dl,
                                  order_rs = order_rs
                                  )
                takeout.save()
                ct = ContentType.objects.get_for_model(takeout)
                log_action_entry(ct, request, takeout, 'Виведення поза штат', '-> згенеровано з штатної посади')
                n += 1
            except Exception as ex:
                messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                e += 1

        messages.success(request, f'Виконано. Згенеровано {n} операцій виведення поза штат. Помилок: {e}')
        return True

    make_takeout.short_description = 'Згенерувати виведення поза штат'

    def add_to_mission(self, request, queryset):
        # if request.user.username != 'wifi':
        #     raise Exception('Access denied!')
        n = 0
        e = 0
        mission = Mission.objects.filter(end_date__isnull=True).order_by('-start_date').first()  # отримати останню бойову місію
        if not mission:
            messages.warning(request, 'Відсутня активна або запланована бойова міся!')
            return

        for item in queryset:
            if not item.serviceman:
                continue
            try:
                participant = MissionParticipant(
                    mission = mission,
                    start_date = mission.start_date,
                    serviceman = item.serviceman,
                    # comment = 'автоматично',
                    user = request.user,
                    )
                participant.save()
                # ct = ContentType.objects.get_for_model(participant)
                # log_action_entry(ct, request, participant, 'Виведення поза штат', '-> згенеровано з штатної посади')
                n += 1
            except Exception as ex:
                messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                e += 1

        if e > 0:
            messages.warning(request, f'Виконано. Додано {n} в/с до бойової місії "{mission.name}". Помилок: {e}')
        else:
            messages.success(request, f'Виконано. Додано {n} в/с до бойової місії "{mission.name}"')

        return True

    add_to_mission.short_description = 'Додати до учасників бойової місії'

    def create_doc_file_for_daily_order(self, request, queryset):
        from personnel.admin import AcceptanceAdmin, AssignRankAdmin
        print("<<create_doc_file_for_daily_order>> file: " + self.save_to)
        if type(self) == AcceptanceAdmin:
            data = prepare_acceptance_grouped(queryset)
            path = create_doc_from_template_data(request, data, self.template_daily, self.save_to)
        elif type(self) == AssignRankAdmin:
            data = prepare_assign_rank_grouped(queryset)
            path = create_doc_from_template_data(request, data, self.template_daily, self.save_to)
        else:
            qs = queryset.order_by('serviceman__last_name', 'serviceman__first_name')
            path = create_doc_from_template_queryset(request, qs, self.template_daily, self.save_to)
        if path:
            messages.success(request, 'Файл успішно згенеровано')
            return get_docfile_response(path)
        else:
            return None

    create_doc_file_for_daily_order.short_description = 'Згенерувати стовпчик(и) у добовий наказ (Word)'

    def create_doc_file_extract(self, request, queryset):
        if queryset.count() > 1:
            messages.warning(request, 'Оберіть тільки ОДИН запис!')
        else:
            print("file: " + self.save_to)
            qs = queryset.order_by('serviceman__last_name', 'serviceman__first_name')
            path = create_extract_from_template(request, qs, self.template_daily, self.save_to)
            messages.success(request, 'Файл успішно згенеровано')
            return get_docfile_response(path)

    create_doc_file_extract.short_description = 'Згенерувати витяг(и) з добового наказу (Word)'

    def create_doc_file_for_rs_order(self, request, queryset):
        print("file: " + self.save_to)
        qs = queryset.filter(order_rs__isnull=False).order_by('serviceman__last_name', 'serviceman__first_name')
        if qs.count() == 0:
            messages.warning(request, 'Відсутній РС наказ!')
        else:
            path = create_doc_from_template_queryset(request, qs, self.template_rs, self.save_to)
            if path:
                messages.success(request, 'Файли успішно згенеровано')
                return get_docfile_response(path)
            else:
                messages.warning(request, 'Помилка формування РС наказу.')

    create_doc_file_for_rs_order.short_description = 'Згенерувати стовпчик(и) у РС наказ (Word)'


    ##########################
    # action tools           #
    ##########################
    def add_order_mentioned(self, order, sm):
        try:
            order.mentioned.add(sm)
        except:
            pass

    def remove_order_mentioned(self, order, sm):
        try:
            order.mentioned.remove(sm)
        except:
            pass

    ##########################
    # actions implementation #
    ##########################
    def apply_acceptance(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            try:
                if not m.order_daily:
                    raise Exception('Не вказано Добовий наказ!')
                if m.serviceman.staff:
                    raise Exception(f'Військовослужбовець вже на посаді: {m.serviceman.staff}')
                if m.status != StaffActionBase.Status.NEW:
                    raise Exception('Неможливо виконати дію! Статус повинен бути "Новий"')

                if m.serviceman.excluded:
                    # raise Exception('Військовослужбовець вже виключений зі списків!')
                    msg = f'Прийом на посаду в/с який вже раніше був виключений зі списків: {m.serviceman.title}'
                    messages.warning(request, msg)
                    logger.warning(msg)
                    m.serviceman.excluded = False
                    m.serviceman.dismissal_order = None
                    m.serviceman.dismissal_date = None
                    m.serviceman.save()

                check_serviceman_missing_status_and_raise(m.serviceman)

                if m.status == StaffActionBase.Status.NEW and not m.staff:
                    qs_sad = ServicemanAtDisposal.objects.filter(serviceman=m.serviceman,
                                                                 order_in__isnull=True)
                    if len(qs_sad) > 0:
                        messages.warning(request, f'Військовослужбовець {m.serviceman.short_name} у розпорядженні!')
                        raise Exception(f'Військовослужбовець {m.serviceman.short_name} у розпорядженні!')

                    sad = ServicemanAtDisposal(date_from = m.order_daily.date,
                                               order_out = m.order_daily,
                                               serviceman = m.serviceman,
                                               reason = ServicemanAtDisposal.Reason.DISPOSAL,
                                               comment = 'створено автоматично')
                    sad.save()
                    m.serviceman.acceptance_order = m.order_daily
                    m.serviceman.save()
                    m.disposal = sad
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    messages.info(request, f'{m.serviceman} - Зараховано у розпорядження. Додайте деталі зарахування в/с у розпорядження №{sad.id}!')
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                elif m.status == StaffActionBase.Status.NEW and not m.staff.serviceman:
                    print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                    if m.staff.date_start > datetime.today().date():
                        raise Exception('Посада ЩЕ не активна!')
                    if m.staff.date_end and m.staff.date_end <= datetime.today().date():
                        raise Exception('Посада ВЖЕ не активна!')
                    if m.staff.serviceman:
                        raise Exception('Посада вже зайнята!')

                    qs_sad = ServicemanAtDisposal.objects.filter(serviceman=m.serviceman,
                                                                 # order_out__isnull=False,
                                                                 # order_out__date__lt=datetime.today().date(),
                                                                 order_in__isnull=True)
                    if len(qs_sad) > 0:
                        qs_sad[0].order_in = m.order_daily
                        qs_sad[0].date_to = m.order_daily.date
                        qs_sad[0].save()
                        messages.warning(request, f'Військовослужбовець {m.serviceman.short_name}: у розпорядженні - закрито!')

                    m.staff.serviceman = m.serviceman
                    if m.staff.candidate == m.serviceman:
                        m.staff.candidate = None
                    if m.staff.temporary_acting == m.serviceman:
                        m.staff.temporary_acting = None
                    if m.serviceman.excluded:
                        m.serviceman.excluded = False
                    m.staff.save()
                    m.serviceman.acceptance_order = m.order_daily
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()

                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                else:
                    messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! ')
                    e += 1
                    continue
            except Exception as ex:
                messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                e += 1
                continue

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_acceptance.short_description = 'Виконати прийом на посаду'

    def rollback_acceptance(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE:
                try:
                    if m.staff:
                        if not m.staff.serviceman:
                            raise Exception('Посада вже вакантна!')
                        if m.serviceman != m.staff.serviceman:
                            raise Exception(f'На посаді вже інший військовослужбовець: {m.staff.serviceman}')
                        m.staff.serviceman = None
                        m.staff.save()

                    # open SAD if present
                    qs_sad = ServicemanAtDisposal.objects.filter(serviceman = m.serviceman,
                                                                 order_in = m.order_daily)
                    if len(qs_sad) > 0:
                        qs_sad[0].order_in = None
                        qs_sad[0].date_to = None
                        qs_sad[0].save()
                        messages.warning(request,
                                         f'Військовослужбовець {m.serviceman.short_name}: у розпорядженні - відновлено!')
                    disp = m.disposal
                    m.disposal = None
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    self.remove_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    if disp:
                        disp.delete()

                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхилення {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')
                logger.warning(f'[{request.user.username}] {self.model._meta.verbose_name}[{m.id}]: не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_acceptance.short_description = 'Відхилити (повернути) прийом на посаду'

    def cancel_staff_action(self, request, queryset):
        logger.info(f'[{request.user.username}] cancel {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.NEW:
                m.status = StaffActionBase.Status.CANCELED
                m.save()
                n += 1
                log_action_entry(ct, request, m, self.model._meta.verbose_name, 'скасовано (забраковано)')
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} #{m.id} не може бути скасовано (забраковано)!')
                logger.warning(f'[{request.user.username}] {self.model._meta.verbose_name}[{m.id}]: не може бути скасовано (забраковано)!')

        if n > 0:
            messages.success(request, f'{self.model._meta.verbose_name} скасовано (забраковано) - {n}')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} скасовано (забраковано) - {n}')

        return True

    cancel_staff_action.short_description = 'Скасувати (забракувати)'


    # Movement
    def apply_movement(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.NEW and m.order_daily:
                print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                try:
                    if m.staff_dst.date_start > datetime.today().date():
                        raise Exception('Посада ЩЕ не активна!')
                    if m.staff_dst.date_end and m.staff_dst.date_end <= datetime.today().date():
                        raise Exception('Посада ВЖЕ закрита!')
                    if m.staff_dst.serviceman:
                        raise Exception(f'Посада вже зайнята: {m.staff_dst.serviceman}!')
                    if m.serviceman != m.staff_src.serviceman:
                        raise Exception(f'На посаді вже інший військовослужбовець: {m.staff_src.serviceman}')
                    serviceman = m.staff_src.serviceman
                    m.staff_src.serviceman = None
                    m.staff_src.save()
                    m.staff_dst.serviceman = serviceman
                    if m.staff_dst.candidate == m.staff_dst.serviceman:
                        m.staff_dst.candidate = None
                    if m.staff_dst.temporary_acting == m.staff_dst.serviceman:
                        m.staff_dst.temporary_acting = None
                    m.staff_dst.save()
                    m.serviceman = serviceman
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                except Exception as ex:
                    messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                    e += 1
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'{"Не вказано Добовий наказ" if not m.order_daily else ""}')
                e += 1

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_movement.short_description = 'Виконати переміщення'

    def rollback_movement(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE:
                try:
                    if m.staff_src.serviceman:
                        raise Exception(f'Посада вже зайнята: {m.staff_src.serviceman}!')
                    if m.serviceman != m.staff_dst.serviceman:
                        raise Exception(f'На посаді вже інший військовослужбовець: {m.staff_dst.serviceman}')
                    serviceman = m.staff_dst.serviceman
                    m.staff_dst.serviceman = None
                    m.staff_dst.save()
                    m.staff_src.serviceman = serviceman
                    m.staff_src.save()
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    self.remove_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхиленні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_movement.short_description = 'Відхилити (повернути) переміщення'

    # Takeout
    def apply_takeout(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.NEW and m.order_daily:
                try:
                    if not m.staff.serviceman:
                        raise Exception('Посада вже вакантна!')
                    if m.serviceman != m.staff.serviceman:
                        raise Exception(f'На посаді вже інший військовослужбовець: {m.staff.serviceman}')

                    check_serviceman_at_disposal_and_raise(m.staff.serviceman)
                    sad = ServicemanAtDisposal(date_from=m.order_daily.date,
                                               order_out=m.order_daily,
                                               serviceman=m.serviceman,
                                               reason=m.reason,
                                               comment='створено автоматично')
                    sad.save()
                    m.disposal = sad
                    messages.info(request,
                                  f'{m.serviceman} - Зараховано у розпорядження. Додайте деталі зарахування в/с у розпорядження №{sad.id}!')

                    m.staff.serviceman = None
                    m.staff.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                except Exception as ex:
                    messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                    e += 1
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'{"Не вказано Добовий наказ" if not m.order_daily else ""}')
                e += 1

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_takeout.short_description = 'Виконати виведення поза штат'

    def rollback_takeout(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE and not m.staff.serviceman:
                try:
                    if m.staff.serviceman:
                        raise Exception(f'Посада вже зайнята: {m.staff.serviceman}!')
                    # if m.serviceman != m.staff.serviceman:
                    #     raise Exception(f'На посаді вже інший військовослужбовець: {m.staff.serviceman}')
                    m.staff.serviceman = m.serviceman
                    m.staff.save()
                    disp = m.disposal
                    m.disposal = None
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    self.remove_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    if disp:
                        disp.delete()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхиленні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_takeout.short_description = 'Відхилити (повернути) виведення поза штат'

    # Dismissal
    def apply_dismissal(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if not m.order_daily:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'{"Не вказано Добовий наказ" if not m.order_daily else ""}')
                e += 1
                continue
            if m.staff and m.staff.serviceman != m.serviceman:
                messages.error(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'На штатній посаді інший військовослужбовець: {m.staff.serviceman}')
                e += 1
                continue

            if m.status == StaffActionBase.Status.NEW and not m.serviceman.excluded:
                print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                try:
                    qs_sad = get_serviceman_at_disposal(m.serviceman)
                    if len(qs_sad) > 0:
                        qs_sad[0].order_in = m.order_daily
                        qs_sad[0].date_to = m.order_daily.date
                        qs_sad[0].save()
                        messages.warning(request,
                                         f'Військовослужбовець {m.serviceman.short_name}: у розпорядженні - закрито!')

                    check_serviceman_missing_status_and_raise(m.serviceman)
                    if m.staff and m.staff.serviceman:
                        m.staff.serviceman = None
                        m.staff.save()

                    # remove TA
                    qs_ta = Staff.objects.filter(temporary_acting=m.serviceman)
                    if len(qs_ta) > 0:
                        for item in qs_ta:
                            item.temporary_acting = None
                            item.save()
                    # remove Candidate
                    qs_ta = Staff.objects.filter(candidate=m.serviceman)
                    if len(qs_ta) > 0:
                        for item in qs_ta:
                            item.candidate = None
                            item.save()

                    m.serviceman.excluded = True
                    m.serviceman.dismissal_date = m.order_daily.date
                    m.serviceman.dismissal_order = m.order_daily
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                except Exception as ex:
                    messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                    e += 1
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! ')
                e += 1

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_dismissal.short_description = 'Виконати виключення зі списків'

    def rollback_dismissal(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE and m.serviceman.excluded:
                print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                try:
                    if m.staff and m.staff.serviceman:
                        raise Exception(f'Посада вже зайнята: {m.staff.serviceman}!')

                    # open SAD if present
                    qs_sad = ServicemanAtDisposal.objects.filter(serviceman = m.serviceman,
                                                                 order_in = m.order_daily)
                    if len(qs_sad) > 0:
                        qs_sad[0].order_in = None
                        qs_sad[0].date_to = None
                        qs_sad[0].save()
                        messages.warning(request,
                                         f'Військовослужбовець {m.serviceman.short_name}: у розпорядженні - відновлено!')

                    if m.staff and not m.staff.serviceman:  # add check if serviceman already assigned !!!
                        m.staff.serviceman = m.serviceman
                        m.staff.save()

                    m.serviceman.excluded = False
                    m.serviceman.dismissal_date = None
                    m.serviceman.dismissal_order = None
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    self.remove_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхиленні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_dismissal.short_description = 'Відхилити (повернути) виключення зі списків'

    # Temporary Acting
    def apply_temporary_acting(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.NEW and m.order_daily and not m.serviceman.excluded:
                print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                # + СЗЧ, втрати
                qst = Staff.objects.filter(temporary_acting=m.serviceman)
                if len(qst) > 0:
                    qst.first().temporary_acting = None
                    qst.first().save()
                    messages.warning(request, f'{m.serviceman.short_name}, попередній ТВО - "{qst.first().full_name}" скасовано!')

                try:
                    m.staff.temporary_acting = m.serviceman
                    m.staff.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                except Exception as ex:
                    messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                    e += 1
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'{"Не вказано Добовий наказ" if not m.order_daily else ""}')
                e += 1

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_temporary_acting.short_description = 'Виконати Допуск до ТВО'

    def rollback_temporary_acting(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE:
                print(f'{self.model._meta.verbose_name}: {m.__str__()}')
                try:
                    m.staff.temporary_acting = None
                    m.staff.save()
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхиленні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_temporary_acting.short_description = 'Відхилити (повернути) допуск до ТВО'

    # Assign Rank
    def apply_assign_rank(self, request, queryset):
        logger.info(f'[{request.user.username}] applying {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.NEW and m.order_daily:
                try:
                    m.rank_src = m.serviceman.rank  # current rank
                    m.order_rs_src = m.serviceman.rank_order  # current rs order
                    m.serviceman.rank = m.rank_dst
                    m.serviceman.rank_order = m.order_rs
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.DONE
                    self.add_order_mentioned(m.order_daily, m.serviceman)
                    self.add_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name)
                except Exception as ex:
                    messages.error(request, f'Помилка при виконанні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
                    e += 1
            else:
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути виконано! '
                                          f'{"Не вказано Добовий наказ" if not m.order_daily else ""}')
                e += 1

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) виконано')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) виконано, ({e}) помилок')

        return True

    apply_assign_rank.short_description = 'Виконати Присвоєння звання'

    def rollback_assign_rank(self, request, queryset):
        logger.info(f'[{request.user.username}] rollback {self.model._meta.model_name} [{queryset.count()}]')
        ct = ContentType.objects.get_for_model(queryset.model)
        n = e = 0
        for m in queryset:
            logger.info(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {m.__str__()}')
            if m.status == StaffActionBase.Status.DONE:
                try:
                    m.serviceman.rank = m.rank_src
                    m.serviceman.rank_order = m.order_rs_src
                    m.serviceman.save()
                    m.status = StaffActionBase.Status.NEW
                    self.remove_order_mentioned(m.order_daily, m.serviceman)
                    self.remove_order_mentioned(m.order_rs, m.serviceman)
                    m.save()
                    n += 1
                    log_action_entry(ct, request, m, self.model._meta.verbose_name, 'відхилено (повернуто)')
                except Exception as ex:
                    e += 1
                    messages.error(request, f'Помилка при відхиленні {self.model._meta.verbose_name}: {ex}')
                    logger.error(f'[{request.user.username}] {self.model._meta.model_name}[{m.id}]: {ex}')
            else:
                e += 1
                messages.warning(request, f'{self.model._meta.verbose_name} не може бути відхилено (повернуто)!')

        if e == 0:
            messages.success(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто)')
        else:
            messages.warning(request, f'{self.model._meta.verbose_name} - ({n}) відхилено (повернуто), ({e}) помилок')

        return True

    rollback_assign_rank.short_description = 'Відхилити (повернути) присвоєння звання'


    ################
    # Data loading #
    ################
    def load_mission_participants(self, request, queryset):
        print(f'## [{request.user}] {self.model._meta.verbose_name.title()}')
        path = os.path.join(settings.DOCUMENTS_DIR, '_import/204_29.xlsx')
        if not os.path.exists(path):
            messages.warning(request, f'Файл не знайдено: {path}')
            return
        print(path)
        wb = openpyxl.load_workbook(path, read_only=True)
        print(wb.get_sheet_names())
        first_sheet = wb.get_sheet_names()[0]
        print(first_sheet)
        ws = wb.get_sheet_by_name(first_sheet)

        data = []

        i = 1
        n = 0
        # Loop over rows and create `Parameters()` objects with column data
        # row_offset=1 is used if you have a header row in your file, you want to skip it
        # otherwise use 0 or delete the row_offset parameter, since 0 is default
        # for row in ws.iter_rows(row_offset=2): (min_row=2)
        for row in ws.iter_rows():
            full_name = row[9].value
            # print(full_name)
            if i>2 and full_name:
                parts = full_name.split(' ')
                ln = parts[0]
                fn = parts[1]
                sn = parts[2]
                sm = Serviceman.objects.filter(last_name__iexact=ln, first_name__iexact=fn, second_name__iexact=sn)
                if len(sm) == 0 and len(parts) > 3:
                    print(ln)
                    sm = Serviceman.objects.filter(last_name__iexact=ln)
                    if len(sm) > 0:
                        print(f'{ln} - found: {len(sm)}')

                if len(sm)>0:
                    n = n + 1
                    print(f'{i-2}:{n} - {full_name}: {ln}-{fn}-{sn} :: {sm[0]} (+)')
                    participant = MissionParticipant()
                    participant.mission_id = 1
                    participant.serviceman_id = sm[0].id
                    participant.start_date = datetime.today()
                    participant.user = request.user
                    data.append(participant)
                else:
                    print(f'{i-2} - {full_name}: {ln}-{fn}-{sn} :: ???')

            i = i + 1

        wb.close()

        # for item in data:
        #     print(f'{item.serviceman_id};')
        # Bulk create data
        MissionParticipant.objects.bulk_create(data)
        messages.info(request, f'Завантаження файлу завершено. Всього записів: {i-3}, завантажено: {n}')

    load_mission_participants.short_description = 'Завантажити учасників місії'


    def import_from_file(self, request, queryset):
        logger.info(f'[{request.user.username}] {self.model._meta.model_name}')
        fn = queryset[0].file.name
        import_type = queryset[0].type
        import_type_name = queryset[0].get_type_display()
        save = queryset[0].save_data
        print(f'import_type: {import_type_name}, file: {fn}')
        path = os.path.join(settings.DOCUMENTS_DIR, fn)
        if not fn or not os.path.exists(path):
            messages.warning(request, f'Файл не знайдено: {path}')
            return
        ext = pathlib.Path(path).suffix
        if ext != '.xlsx':
            messages.warning(request, f'Файл повинен мати тип .xlsx ( поточний: [{ext}] )')
            return

        # load workbook
        wb = openpyxl.load_workbook(path, read_only=True)
        print(f'sheets: {wb.get_sheet_names()}')
        first_sheet = wb.get_sheet_names()[0]
        print(f'sheet to load data: {first_sheet}')
        ws = wb.get_sheet_by_name(first_sheet)

        if import_type == Import.Type.SERVICEMAN.value:
            total, loaded = load_servicemans(request, ws, save)
        elif import_type == Import.Type.MISSION_PART.value:
            total, loaded = load_mission_parts(request, ws, save)
        elif import_type == Import.Type.DISPOSAL.value:
            total, loaded = load_disposals(request, ws, save)
        elif import_type == Import.Type.SERVICE_TERM.value:
            total, loaded = load_service_term(request, ws, save)
        elif import_type == Import.Type.SERVICE_PERIODS.value:
            total, loaded = load_service_periods(request, ws, save)
        elif import_type == Import.Type.LOSSES.value:
            total, loaded = load_losses(request, ws, save)
        elif import_type == Import.Type.STAFF.value:
            total, loaded = load_staff(request, ws, save)
        elif import_type == Import.Type.PAYOUT.value:
            total, loaded = load_payout(request, ws, save)
        elif import_type == Import.Type.ALL_STAFF.value:
            imp = ImportFullStaff(request, ws)
            total, loaded = imp.load_full_staff(save)
        else:
            messages.warning(request, f'Вказаний тип імпорту не підтримується: {import_type_name}')
            return

        wb.close()

        messages.info(request, f'Завантаження файлу завершено. Всього записів: {total}, завантажено: {loaded}')
        logger.info(f'[{request.user.username}] {self.model._meta.model_name} Завантаження файлу завершено. Всього записів: {total}, завантажено: {loaded}')

    import_from_file.short_description = 'Виконати імпорт даних'

