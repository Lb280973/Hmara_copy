import inspect
import logging
from collections import defaultdict
from datetime import datetime
#import datetime
import os
import time

import openpyxl
from dateutil.relativedelta import relativedelta
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment

from conf import settings
from documents.models import Trip, Vacation, Hospitalization, Arrest, Exemption
from utils.docfiles import get_globals
from .counter import Counter


def get_shifts(shift_start, shift_length=None, staff_involved=None):
    """
    It takes a start time and either a shift length or a number of staff involved, and returns a list of shifts

    :param shift_start: the time the shift starts
    :param shift_length: the length of the shift in hours
    :param staff_involved: the number of staff involved in the shift
    :return: A list of shifts.
    """
    if not shift_length and not staff_involved:
        raise Exception('specify either shift length or staff involved')

    current = shift_start
    hours = []

    while True:
        to = current + shift_length
        if current < shift_start:
            hours.append(f'{current}-{to}')
            current += shift_length
            if current >= shift_start:
                break
        elif current < 24:
            if to >= 24:
                to = to % 24
            hours.append(f'{current}-{to}')
            current = to
    return hours


def get_shift_length(posts, staff_involved, max_shift_length=None):
    """
    > Given the number of posts and the number of staff involved, calculate the length of the shift

    :param posts: the number of posts you want to cover
    :param staff_involved: the number of staff members involved in the shift
    :param max_shift_length: the maximum number of hours a shift can be
    :return: The number of hours in a shift.
    """
    n_hours = 24 * posts / staff_involved
    n_shifts_per_person = 1

    if max_shift_length:
        while n_hours / n_shifts_per_person > max_shift_length:
            n_shifts_per_person += 1
        shift_length = n_hours / n_shifts_per_person
    else:
        shift_length = n_hours
    if n_hours % n_shifts_per_person != 0:
        staff_involved -= 1
        shift_length = get_shift_length(posts, staff_involved, max_shift_length=max_shift_length)
    return int(shift_length)


def adjust_staff_number(staff_involved, posts):
    """
    It takes two numbers, and returns a number that is the first number minus as many times as necessary to make the second
    number evenly divisible by the first

    :param staff_involved: the number of people involved in the rota
    :param posts: the number of posts you want to cover
    :return: The adjusted staff count.
    """
    if staff_involved < posts:
        raise Exception(f'Not enough people ({staff_involved}) to cover {posts} posts')
    while 24 * posts % staff_involved != 0:
        staff_involved -= 1
    return staff_involved


@login_required
def shifts_view(request, queryset):
    """
    It takes a list of personnel, and returns a list of shifts,
    each shift containing a list of personnel

    :param request: the request object
    :param queryset: a queryset of personnel
    :return: A rendered template with the context of the shifts, personnel, staff_involved, n_shifts, n_teams,
    shifts_per_person, hours_per_person, shift_length, marks, and reserve.
    """
    personnel = queryset

    shift_start = 11
    posts = 2
    shift_length = 3
    max_shift_length = None
    staff_involved = None

    if not staff_involved or staff_involved > personnel.count():
        staff_involved = personnel.count()

    if staff_involved:
        if shift_length:
            staff_involved = None
        else:
            staff_involved = adjust_staff_number(staff_involved, posts)

    if not shift_length:
        shift_length = get_shift_length(posts, staff_involved, max_shift_length)

    if not staff_involved:
        staff_involved = personnel.count()
        while 24 * posts / shift_length % staff_involved != 0:
            staff_involved -= 1

    shifts = get_shifts(shift_start, shift_length, staff_involved=staff_involved)
    n_shifts = len(shifts)
    n_teams = int(staff_involved / posts)

    shifts_per_person = n_shifts * posts / staff_involved
    hours_per_person = shifts_per_person * shift_length

    marks = []
    x = 0
    y = 0
    in_schedule = personnel[0:staff_involved]
    while x < len(shifts):
        for i in range(posts):
            mark = {
                'callsign': in_schedule[y].callsign,

            }
            s = x
            mark['shifts'] = []
            for i in range(int(shifts_per_person)):
                mark['shifts'].append(s)
                s += n_teams
            marks.append(mark)
            y += 1
        x += 1
        if y >= staff_involved:
            break

    reserve = [serviceman for serviceman in personnel[staff_involved:]]
    return render(request, 'shifts.html',
                  context={'shifts': shifts, 'personnel': personnel, 'staff_involved': staff_involved,
                           'n_shifts': n_shifts, 'n_teams': n_teams, 'shifts_per_person': shifts_per_person,
                           'hours_per_person': hours_per_person, 'shift_length': shift_length, 'marks': marks,
                           'reserve': reserve})


@login_required
def count_view(request):
    c = Counter()
    context = {
        'counter': c.counter
    }
    return render(request, 'personnel/count.html', context=context)


def get_rank_level_color(position_category):
    if position_category.rank_level == '3':  # PositionCategory.RankLevel.OFFICER:
        return '00729FCF'
    elif position_category.rank_level == '2':  # PositionCategory.RankLevel.SERGEANT:
        return '0070AD47'
    elif position_category.rank_level == '1':  # PositionCategory.RankLevel.SOLDIER:
        return None
    else:  # PositionCategory.RankLevel.CIVIL
        return '00F2DCDB'


def get_staff_position_status(staff):
    if staff.date_end and staff.date_end <= datetime.today().date():
        return 1  # StaffPositionStatus.CLOSED
    elif staff.date_start and staff.date_start > datetime.today().date():
        return 2  # StaffPositionStatus.INACTIVE
    else:
        return 3  # StaffPositionStatus.ACTIVE

def get_staff_position_display(status, show_vacant):
    if status == 1:
        return 'ЗАКРИТА' # StaffPositionStatus.CLOSED
    elif status == 1:
        return 'НЕАКТИВНА' # StaffPositionStatus.INACTIVE
    else:
        return 'ВАКАНТ' if show_vacant else 'АКТИВНА'   # StaffPositionStatus.ACTIVE - not used

def get_staff_position_color(status):
    if status == 1:
        return 'red' # StaffPositionStatus.CLOSED
    elif status == 1:
        return 'magenta' # StaffPositionStatus.INACTIVE
    else:
        return 'green'   # StaffPositionStatus.ACTIVE

# def fill_cell(ws, ri, ci):
#     ws.cell(row=ri, column=ci+1).fill = PatternFill("solid", fgColor="00FF0000" if row[18] > 1 else "00FFFF00")

def get_worksheet(wb, sheet_name):
    print(f'## get_worksheet, wb: {"Present" if wb else "None"}, ws: {sheet_name}')
    ws = None
    if not wb:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = sheet_name
        print('new wb and ws created')
    else:
        try:
            ws = wb.get_sheet_by_name(sheet_name)
        except KeyError:
            print(f'ws {sheet_name} not found')
    if not ws:
        print('>create_sheet')
        ws = wb.create_sheet(sheet_name, len(wb.sheetnames))
    print(f'ws: {ws.title}')
    return ws

def update_serviceman_dict(sms_dict, key):
    if not sms_dict.get(key):
        sms_dict[key] = 1
    else:
        sms_dict[key] += 1


def create_staff_worksheet(wb, queryset, add_header_and_format):
    from .models import ServicemanIllegallyAbsent, Losses

    start = time.time()
    func = inspect.currentframe().f_code.co_name
    print(f'## {func}')

    sheet_name = 'Штат'
    ws = get_worksheet(wb, sheet_name)

    # openpyxl.worksheet.page.PrintPageSetup(orientation='landscape')
    if add_header_and_format:
        headers = ['№ з/п',
                   'Посада за штатом',
                   'Посадовий оклад',
                   '№ ВОС за штатом',
                   'Військове звання за штатом',
                   'Склад',
                   'Військове звання фактичне',
                   'ПІБ',
                   # 'Номер наказу про зарахування',
                   # 'Період і рік призову ',
                   'Підпорядкування',
                   'Підрозділ',
                   'Підрозділ БЧС',
                   'Літера',
                   'Дата народження',
                   'ІПН',
                   'Телефон',
                   'ТВО',
                   'Кандидат',
                   'Посада (повністю)',
                   'Відпустка',
                   'Відрядження',
                   'Лікарняний',
                   'СЗЧ',
                   'Стать',
                   'Вид служби',
                   'Періоди служби',
                   'Освіта',
                   'Дата присвоєння звання (інша в/ч)',
                   'Втрати',
                   'Втрати (дата)',
                   'Наказ про зарахування',
                   'Група крові',
                   'Сімейний стан (неодружений / одружений / розлучений / вдівець)',
                   'Родичі',
                   'Місце народження',
                   'Місце проживання',
                   'Арешт',
                   'Тимчасове звільнення від с/о',
                   'Вислуга років',
                   'Наказ на посаду',
                   'Дата наказу на посаду',
                   'Посада активна',
                   'Локація'
                   ]
        ws.append(headers)
        thin = Side(border_style="thin", color="000000")
        for x in range(1, len(headers)+1):
            ws.cell(row=1, column=x).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            ws.cell(row=1, column=x).border = Border(top=thin, left=thin, right=thin, bottom=thin)
            ws.cell(row=1, column=x).fill = PatternFill("solid", fgColor="0099CCFF")

    # у відпустці
    qs_vaca = Vacation.objects.filter(order_out__isnull=False,
                                      order_out__date__lte=datetime.today().date(),
                                      order_in__isnull=True, returned=None)
    # у відрядженні
    qs_trip = Trip.objects.filter(order_out__isnull=False,
                                  order_out__date__lte=datetime.today().date(),
                                  order_in__isnull=True, returned=None)
    trip_sms = defaultdict()
    for trip in qs_trip:
        update_serviceman_dict(trip_sms, trip.serviceman.id)
        for serviceman in trip.accompanies.all():
            update_serviceman_dict(trip_sms, serviceman.id)
    # на лікарняному
    qs_hosp = Hospitalization.objects.filter(order_out__isnull=False,
                                             order_out__date__lte=datetime.today().date(),
                                             order_in__isnull=True, returned=None)
    # СЗЧ
    qs_illa = ServicemanIllegallyAbsent.objects.filter(order_out__isnull=False,
                                                       order_out__date__lte=datetime.today().date(),
                                                       order_in__isnull=True)
    # Втрати
    qs_loss = Losses.objects.filter(order_daily__isnull=False,
                                    order_daily__date__lte=datetime.today().date(),
                                    order_daily_in__isnull=True)
    # Арешт
    qs_arst = Arrest.objects.filter(order_out__isnull=False,
                                    order_out__date__lte=datetime.today().date(),
                                    order_in__isnull=True)
    # Тимчасове звільнення
    qs_exem = Exemption.objects.filter(order_out__isnull=False,
                                       order_out__date__lte=datetime.today().date(),
                                       order_in__isnull=True)

    i = 1
    for item in queryset:
        loss = qs_loss.filter(serviceman=item.serviceman).first()
        row = [
            item.staff_id,
            item.position.name.capitalize(),
            item.position.tariff.tariff_short_name,
            item.position.milspec,
            item.position.position_category.name if item.position.position_category else '-',
            item.position.position_category.get_rank_level_display(),
            item.serviceman.rank.__str__() if item.serviceman else '',
            item.serviceman.full_name_upper if item.serviceman else '',  #'ВАКАНТ',
            # '',
            # '',
            item.unit.parent_unit.name if item.unit.parent_unit else '',
            item.unit.name,
            item.unit.combat_group.name if item.unit.combat_group else '?',
            item.unit.letter,
            item.serviceman.birthday if item.serviceman else '',
            item.serviceman.tax_id if item.serviceman else '',
            item.serviceman.phone_number if item.serviceman else '',
            f'ТВО: {item.temporary_acting.__str__()}' if item.temporary_acting else '',
            f'К: {item.candidate.__str__()}' if item.candidate else '',
            '', #item.full_name,
            qs_vaca.filter(serviceman=item.serviceman).count(),
            trip_sms[item.serviceman.id] if item.serviceman and trip_sms.get(item.serviceman.id) else 0,
            qs_hosp.filter(serviceman=item.serviceman).count(),
            qs_illa.filter(serviceman=item.serviceman).count(),
            item.serviceman.get_sex_display() if item.serviceman else '',
            item.serviceman.get_service_type_display() if item.serviceman else '',
            item.serviceman.service_periods if item.serviceman else '',
            item.serviceman.education if item.serviceman else '',
            item.serviceman.rank_order_ext_date  #.strftime('%d.%m.%Y')
                if item.serviceman and item.serviceman.rank_order_ext_date else '',
            loss.get_type_display() if loss else '',
            loss.action_date if loss else '',
            item.serviceman.acceptance_order.short_name if item.serviceman and item.serviceman.acceptance_order else '',
            item.serviceman.get_blood_type_display() if item.serviceman else '',
            item.serviceman.get_marital_status_display() if item.serviceman else '',
            item.serviceman.relatives if item.serviceman else '',
            item.serviceman.birthplace if item.serviceman else '',
            item.serviceman.home_address if item.serviceman else '',
            qs_arst.filter(serviceman=item.serviceman).count(),
            qs_exem.filter(serviceman=item.serviceman).count(),
            item.serviceman.service_term_years_new if item.serviceman else 0,
            '', #item.staff_order.short_name if item.staff_order else '',
            '', #item.staff_order.date if item.staff_order else '',
            1 if (item.date_end is None or item.date_end >= datetime.today().date()) and item.date_start <= datetime.today().date() else 0, # is active
            item.serviceman.location.name if item.serviceman and item.serviceman.location else '',
        ]
        # Staff.objects.filter(Q(date_end__isnull=True) |
        #                      Q(date_end__gte=datetime.today()) |
        #                      Q(serviceman__isnull=False),
        #                      date_start__lte=datetime.today())
        ws.append(row)
        i += 1

        status = get_staff_position_status(item)
        # if item.date_end and item.date_end <= datetime.today():
        # if item.date_start and item.date_start > datetime.today():
        if status == 1:  # CLOSED, closed staff positions
            format_cells(ws, i, range(1, 5), '00FF5050')
            if item.serviceman:
                format_cells(ws, i, range(7, 9), '00FF5050')
        elif status == 2:  # INACTIVE, inactive (not started) staff positions
            format_cells(ws, i, range(1, 5), '00B1A0C7')
            if item.serviceman:
                format_cells(ws, i, range(7, 9), '00B1A0C7')

        # vacant
        # c = ws.cell(row=i, column=8)
        # if not item.serviceman:
        #     c.fill = PatternFill("solid", fgColor="00E2EFDA")
        if not item.serviceman:
            format_cells(ws, i, range(7, 9), '00E2EFDA')

        # rank level
        c = ws.cell(row=i, column=5)
        if item.position.position_category:
            cl = get_rank_level_color(item.position.position_category)
            if cl:
                c.fill = PatternFill("solid", fgColor=cl)

        # commander
        if "командир " in item.position.name.lower() or "начальник " in item.position.name.lower():
            for x in range(1, 15):
                ws.cell(row=i, column=x).font = Font(bold=True)
        # ТВО
        if item.temporary_acting:
            ws.cell(row=i, column=16).fill = PatternFill("solid", fgColor="00FFFF00")

        # validate and highlight trip/vacation/hospitalization
        if row[18] > 0:
            # fill_cell(ws, i+1, 18)
            ws.cell(row=i, column=19).fill = PatternFill("solid", fgColor="00FF0000" if row[18] > 1 else "00FFFF00")
            if row[18] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} у відрядженні {row[18]} рази!!!')
        if row[19] > 0:
            ws.cell(row=i, column=20).fill = PatternFill("solid", fgColor="00FF0000" if row[19] > 1 else "00FFFF00")
            if row[19] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} у відпустці {row[19]} рази!!!')
        if row[20] > 0:
            ws.cell(row=i, column=21).fill = PatternFill("solid", fgColor="00FF0000" if row[20] > 1 else "00FFFF00")
            if row[20] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} на лікарняному {row[20]} рази!!!')

        # highlight Illegally Absent Servicemans
        if row[21] > 0:
            ws.cell(row=i, column=22).fill = PatternFill("solid", fgColor="00ED7D31")

        # center cells
        centered = {1, 3, 4, 11, 12, 13, 14, 19, 20, 21, 22, 23, 27, 29, 31, 36, 37, 38, 41}
        for c in centered:
            ws.cell(row=i, column=c).alignment = Alignment(horizontal='center')

        # format rank date, losses date
        ws.cell(row=i, column=27).number_format = 'dd/mm/yyyy'  # 'dd/mm/yyyy;@'
        ws.cell(row=i, column=29).number_format = 'dd/mm/yyyy'  # 'dd/mm/yyyy;@'

    if add_header_and_format:
        # # format table
        # set column width
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 30
        ws.column_dimensions['C'].width = 11
        ws.column_dimensions['D'].width = 11
        ws.column_dimensions['E'].width = 21
        ws.column_dimensions['F'].width = 10
        ws.column_dimensions['G'].width = 21
        ws.column_dimensions['H'].width = 36
        # ws.column_dimensions['H'].width = 16 #
        # ws.column_dimensions['I'].width = 11 #
        ws.column_dimensions['I'].width = 21
        ws.column_dimensions['J'].width = 21
        ws.column_dimensions['K'].width = 21
        ws.column_dimensions['L'].width = 8
        ws.column_dimensions['M'].width = 12
        ws.column_dimensions['N'].width = 13
        ws.column_dimensions['O'].width = 15
        ws.column_dimensions['P'].width = 36
        ws.column_dimensions['Q'].width = 36
        ws.column_dimensions['R'].width = 36
        ws.column_dimensions['S'].width = 13
        ws.column_dimensions['T'].width = 13
        ws.column_dimensions['U'].width = 13
        ws.column_dimensions['V'].width = 13
        ws.column_dimensions['W'].width = 9
        ws.column_dimensions['X'].width = 16
        ws.column_dimensions['Y'].width = 30
        ws.column_dimensions['Z'].width = 40
        ws.column_dimensions['AA'].width = 11
        ws.column_dimensions['AB'].width = 11
        ws.column_dimensions['AC'].width = 11
        ws.column_dimensions['AD'].width = 16
        ws.column_dimensions['AE'].width = 12
        ws.column_dimensions['AF'].width = 18
        ws.column_dimensions['AG'].width = 21
        ws.column_dimensions['AH'].width = 21
        ws.column_dimensions['AI'].width = 21
        ws.column_dimensions['AM'].width = 16

        # wrap text and top alignment for table content
        for row in ws.iter_rows():
            for cell in row:
                if cell.row > 1:
                    cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

        ws.sheet_view.zoomScale = 80
    print(f'## {func} - Done (%.2f seconds)' % (time.time() - start))


def create_disposal_or_attached_worksheet(wb, queryset, add_header_and_format, sheet_name):
    from .models import ServicemanIllegallyAbsent, Losses

    start = time.time()
    func = inspect.currentframe().f_code.co_name
    print(f'## {func}')

    # sheet_name = 'Розпорядники'
    ws = get_worksheet(wb, sheet_name)

    # openpyxl.worksheet.page.PrintPageSetup(orientation='landscape')
    if add_header_and_format:
        headers = ['№ з/п',
                   'Військове звання фактичне',
                   'Склад',
                   'ПІБ',
                   '№ наказу та дата',
                   'Причина',
                   'Підрозділ БЧС',
                   'Літера',
                   'Дата народження',
                   'ІПН',
                   'Телефон',
                   'ТВО (штат)',
                   'Відпустка',
                   'Відрядження',
                   'Лікарняний',
                   'СЗЧ',
                   'Стать',
                   'Вид служби',
                   'Причина',
                   'Періоди служби',
                   'Освіта',
                   'Дата присвоєння звання (інша в/ч)',
                   'Втрати',
                   'Втрати (дата)',
                   'Наказ про зарахування',
                   'Група крові',
                   'Сімейний стан (неодружений / одружений / розлучений / вдівець)'
                   'Родичі',
                   'Місце народження',
                   'Місце проживання',
                   'Арешт',
                   'Тимчасове звільнення від с/о',
                   'Вислуга років',
                   # 'Наказ на посаду',
                   # 'Дата наказу на посаду',
                   'Локація',
                   ]
        ws.append(headers)
        thin = Side(border_style="thin", color="000000")
        for x in range(1, len(headers)+1):
            ws.cell(row=1, column=x).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            ws.cell(row=1, column=x).border = Border(top=thin, left=thin, right=thin, bottom=thin)
            ws.cell(row=1, column=x).fill = PatternFill("solid", fgColor="0099CCFF")

    # у відпустці
    qs_vaca = Vacation.objects.filter(order_out__isnull=False,
                                      order_out__date__lte=datetime.today().date(),
                                      order_in__isnull=True, returned=None)
    # у відрядженні
    qs_trip = Trip.objects.filter(order_out__isnull=False,
                                  order_out__date__lte=datetime.today().date(),
                                  order_in__isnull=True, returned=None)
    trip_sms = defaultdict()
    for trip in qs_trip:
        update_serviceman_dict(trip_sms, trip.serviceman.id)
        for serviceman in trip.accompanies.all():
            update_serviceman_dict(trip_sms, serviceman.id)
    # на лікарняному
    qs_hosp = Hospitalization.objects.filter(order_out__isnull=False,
                                             order_out__date__lte=datetime.today().date(),
                                             order_in__isnull=True, returned=None)
    # СЗЧ
    qs_illa = ServicemanIllegallyAbsent.objects.filter(order_out__isnull=False,
                                                       order_out__date__lte=datetime.today().date(),
                                                       order_in__isnull=True)
    # Втрати
    qs_loss = Losses.objects.filter(order_daily__isnull=False,
                                    order_daily__date__lte=datetime.today().date(),
                                    order_daily_in__isnull=True)
    # Арешт
    qs_arst = Arrest.objects.filter(order_out__isnull=False,
                                    order_out__date__lte=datetime.today().date(),
                                    order_in__isnull=True)
    # Тимчасове звільнення
    qs_exem = Exemption.objects.filter(order_out__isnull=False,
                                       order_out__date__lte=datetime.today().date(),
                                       order_in__isnull=True)

    i = 1
    for item in queryset:
        loss = qs_loss.filter(serviceman=item.serviceman).first()
        row = [
            i,
            item.serviceman.rank.__str__() if item.serviceman else '',
            item.serviceman.rank.rank_level if item.serviceman else '',
            item.serviceman.full_name_upper if item.serviceman else '',
            item.order_out.short_name if item.order_out else '',
            item.comment,
            item.unit.combat_group.name if item.unit and item.unit.combat_group else '',
            item.unit.letter if item.unit else '',
            item.serviceman.birthday if item.serviceman else '',
            item.serviceman.tax_id if item.serviceman else '',
            item.serviceman.phone_number if item.serviceman else '',
            item.serviceman.temporary_acting_short_name if item.serviceman else '',
            qs_vaca.filter(serviceman=item.serviceman).count(),
            trip_sms[item.serviceman.id] if item.serviceman and trip_sms.get(item.serviceman.id) else 0,
            qs_hosp.filter(serviceman=item.serviceman).count(),
            qs_illa.filter(serviceman=item.serviceman).count(),
            item.serviceman.get_sex_display() if item.serviceman else '',
            item.serviceman.get_service_type_display() if item.serviceman else '',
            item.get_reason_display() if sheet_name == 'Розпорядники' else item.external_military_unit,  # reason or military unit
            item.serviceman.service_periods if item.serviceman else '',
            item.serviceman.education if item.serviceman else '',
            item.serviceman.rank_order_ext_date  # .strftime('%d.%m.%Y')
                if item.serviceman and item.serviceman.rank_order_ext_date else '',
            loss.get_type_display() if loss else '',
            loss.action_date if loss else '',
            item.serviceman.acceptance_order.short_name if item.serviceman and item.serviceman.acceptance_order else '',
            item.serviceman.get_blood_type_display() if item.serviceman else '',
            item.serviceman.get_marital_status_display() if item.serviceman else '',
            item.serviceman.relatives if item.serviceman else '',
            item.serviceman.birthplace if item.serviceman else '',
            item.serviceman.home_address if item.serviceman else '',
            qs_arst.filter(serviceman=item.serviceman).count(),
            qs_exem.filter(serviceman=item.serviceman).count(),
            item.serviceman.service_term_years_new if item.serviceman else 0,
            item.serviceman.location.name if item.serviceman and item.serviceman.location else '',
        ]
        ws.append(row)

        # rank level
        # c = ws.cell(row=i + 1, column=5)
        # if item.position.position_category:
        #     cl = get_rank_level_color(item.position.position_category)
        #     if cl:
        #         c.fill = PatternFill("solid", fgColor=cl)

        # ТВО
        col_ta = 12
        if item.serviceman.temporary_acting_short_name != '-':
            ws.cell(row=i + 1, column=col_ta).fill = PatternFill("solid", fgColor="00FFFF00")

        # validate and highlight vacation/trip/hospitalization
        col_vac = 13
        col_tri = 14
        col_hos = 15

        if row[col_vac-1] > 0:
            ws.cell(row=i + 1, column=col_vac).fill = PatternFill(
                "solid", fgColor="00FF0000" if row[col_vac-1] > 1 else "00FFFF00")
            if row[col_vac-1] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} у відрядженні {row[col_vac-1]} рази!!!')
        if row[col_tri-1] > 0:
            ws.cell(row=i + 1, column=col_tri).fill = PatternFill(
                "solid", fgColor="00FF0000" if row[col_tri-1] > 1 else "00FFFF00")
            if row[col_tri-1] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} у відпустці {row[col_tri-1]} рази!!!')
        if row[col_hos-1] > 0:
            ws.cell(row=i + 1, column=col_hos).fill = PatternFill(
                "solid", fgColor="00FF0000" if row[col_hos-1] > 1 else "00FFFF00")
            if row[col_hos-1] > 1:
                logging.warning(f'військовослужбовець {item.serviceman.full_name} на лікарняному {row[col_hos-1]} рази!!!')

        # highlight Illegally Absent Serviceman
        col_ill = 16
        if row[col_ill-1] > 0:
            ws.cell(row=i + 1, column=col_ill).fill = PatternFill("solid", fgColor="00ED7D31")

        # center cells
        centered = {1, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18}
        for c in centered:
            ws.cell(row=i + 1, column=c).alignment = Alignment(horizontal='center')

        # format rank date, losses date
        ws.cell(row=i, column=22).number_format = 'dd/mm/yyyy'  # 'dd/mm/yyyy;@'
        ws.cell(row=i, column=24).number_format = 'dd/mm/yyyy'  # 'dd/mm/yyyy;@'

        i += 1

    if add_header_and_format:
        # # format table
        # set column width
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 21
        ws.column_dimensions['C'].width = 10
        ws.column_dimensions['D'].width = 36
        ws.column_dimensions['E'].width = 15
        ws.column_dimensions['F'].width = 15
        ws.column_dimensions['G'].width = 25
        ws.column_dimensions['H'].width = 8
        ws.column_dimensions['I'].width = 13
        ws.column_dimensions['G'].width = 12
        ws.column_dimensions['K'].width = 15
        ws.column_dimensions['L'].width = 36
        ws.column_dimensions['M'].width = 13
        ws.column_dimensions['N'].width = 13
        ws.column_dimensions['O'].width = 13
        ws.column_dimensions['P'].width = 13
        ws.column_dimensions['R'].width = 9
        ws.column_dimensions['S'].width = 16

        ws.column_dimensions['Z'].width = 11
        ws.column_dimensions['AA'].width = 18
        ws.column_dimensions['AB'].width = 21
        ws.column_dimensions['AC'].width = 21

        # wrap text and top alignment for table content
        for row in ws.iter_rows():
            for cell in row:
                if cell.row > 1:
                    cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

        ws.sheet_view.zoomScale = 80
    print(f'## {func} - Done (%.2f seconds)' % (time.time() - start))


def create_missing_worksheet(wb, add_header = True):
    from .models import ServicemanIllegallyAbsent, Losses

    start = time.time()
    func = inspect.currentframe().f_code.co_name
    print(f'## {func}')

    sheet_name = 'Відсутні'
    ws = get_worksheet(wb, sheet_name)

    if add_header:
        headers = ['№ з/п',
                   'в/частина',
                   'в/звання',
                   'Прізвище та ініціали',
                   'Причина відсутності',
                   'Куди вибув',
                   'Дата вибуття',
                   'Дата прибуття',
                   'Дата фактичного прибуття',
                   'Примітка',
                   ]
        ws.append(headers)
        thin = Side(border_style="thin", color="000000")
        for x in range(1, len(headers)+1):
            ws.cell(row=1, column=x).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            ws.cell(row=1, column=x).border = Border(top=thin, left=thin, right=thin, bottom=thin)
            ws.cell(row=1, column=x).fill = PatternFill("solid", fgColor="0099CCFF")

    # у відпустці
    qs_vaca = Vacation.objects.filter(order_out__isnull=False,
                                      order_out__date__lte=datetime.today().date(),
                                      order_in__isnull=True, returned=None)
    # у відрядженні
    qs_trip = Trip.objects.filter(order_out__isnull=False,
                                  order_out__date__lte=datetime.today().date(),
                                  order_in__isnull=True, returned=None)
    # на лікарняному
    qs_hosp = Hospitalization.objects.filter(order_out__isnull=False,
                                             order_out__date__lte=datetime.today().date(),
                                             order_in__isnull=True, returned=None)
    # СЗЧ
    qs_illa = ServicemanIllegallyAbsent.objects.filter(order_out__isnull=False,
                                                       order_out__date__lte=datetime.today().date(),
                                                       order_in__isnull=True)
    # Втрати
    qs_loss = Losses.objects.filter(order_daily__isnull=False,
                                    order_daily__date__lte=datetime.today().date(),
                                    order_daily_in__isnull=True)
    # Арешт
    qs_arst = Arrest.objects.filter(order_out__isnull=False,
                                    order_out__date__lte=datetime.today().date(),
                                    order_in__isnull=True)

    globa = get_globals()
    i = 1
    # vacations
    for item in qs_vaca:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            'відпустка',
            item.location,
            item.verbose_date_from,
            item.verbose_date_to,
            item.verbose_must_return_date,
            item.comment
        ]
        ws.append(row)
        i += 1

    # trips
    for item in qs_trip:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            'відрядження',
            item.destination,
            item.verbose_date_from,
            item.verbose_date_to,
            item.verbose_must_return_date,
            item.comment
        ]
        ws.append(row)
        i += 1

    # Hospitalization
    for item in qs_hosp:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            'лікарняний',
            item.location,
            item.verbose_date_from,
            '',
            '',
            item.comment
        ]
        ws.append(row)
        i += 1

    # ServicemanIllegallyAbsent
    for item in qs_illa:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            'СЗЧ',
            '',
            item.verbose_date_from,
            '',
            '',
            item.comment
        ]
        ws.append(row)
        i += 1

    # Losses
    for item in qs_loss:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            f'Втрати [{item.get_type_display()}]',
            '',
            item.short_loss_date,
            '',
            '',
            item.description if item.description else item.comment
        ]
        ws.append(row)
        i += 1

    # Arrest
    for item in qs_arst:
        row = [
            i,
            globa.military_unit_name_public,
            item.serviceman.rank.__str__(),
            item.serviceman.short_name,
            f'Арешт',
            '',
            item.date_from_short,
            '',
            '',
            item.comment
        ]
        ws.append(row)
        i += 1

    # # format table
    # set column width
    ws.column_dimensions['A'].width = 8
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 20
    ws.column_dimensions['D'].width = 20
    ws.column_dimensions['E'].width = 18
    ws.column_dimensions['F'].width = 36
    ws.column_dimensions['G'].width = 11
    ws.column_dimensions['H'].width = 15
    ws.column_dimensions['I'].width = 11
    ws.column_dimensions['J'].width = 50

    # wrap text and top alignment for table content
    for row in ws.iter_rows():
        for cell in row:
            if cell.row > 1:
                cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

    ws.sheet_view.zoomScale = 80
    print(f'## {func} - Done (%.2f seconds)' % (time.time() - start))


def get_last_month_dates():
    from datetime import date
    today = date.today()
    d = today - relativedelta(months=1)
    first_day = date(d.year, d.month, 1)
    # first_day.strftime('%A %d %B %Y')
    # returns first date of the previous month - datetime.date(2019, 7, 1)
    last_day = date(today.year, today.month, 1) - relativedelta(days=1)
    # last_day.strftime('%A %d %B %Y')
    # returns the last date of the previous month - datetime.date(2019, 7, 31)
    print(f'{first_day} - {last_day}')
    return first_day, last_day

def get_month_dates(dt = datetime.today().date()):
    from datetime import date
    first_day = date(dt.year, dt.month, 1)
    # returns first date of the month
    last_day = first_day + relativedelta(months=1) - relativedelta(days=1)
    # returns the last date of the month
    print(f'get_month_dates({dt}): {first_day} - {last_day}')
    return first_day, last_day

def get_missing_string(serviceman, qs, caption, end_date):
    result = ''
    for item in qs:
        if item.serviceman == serviceman and item.order_out:
            # result += '\r\n' if result else ''
            result += f'{item.order_out.date.strftime("%d.%m.%Y")} - ' \
                      f'{item.order_in.date.strftime("%d.%m.%Y") if item.order_in else end_date.strftime("%d.%m.%Y")} {caption}\r\n'
    return result

def get_losses_string(serviceman, qs, caption, end_date):
    result = ''
    for item in qs:
        if item.serviceman == serviceman and item.order_daily:
            result += f'{item.order_daily.date.strftime("%d.%m.%Y")} - ' \
                      f'{item.order_daily_in.date.strftime("%d.%m.%Y") if item.order_daily_in else end_date.strftime("%d.%m.%Y")} {caption} [{item.get_type_display()}]\r\n'
    return result

def create_missing_by_unit_combat_group_worksheet(wb, cg, qs_vaca, qs_trip, qs_hosp, qs_illa, qs_loss, qs_arst,
                                                  month_last_date):
    from .models import Unit
    from .models import Staff
    print('## create_missing_by_unit_combat_group_worksheet')
    sheet_name = 'СОДТ' if cg.name == 'Служба охорони державної таємниці' else cg.name
    ws = get_worksheet(wb, sheet_name)

    qs_unit = Unit.objects.filter(combat_group=cg)
    ridx = 0
    for unit in qs_unit:
        row_unit = [None, unit.full_name]
        ws.append(row_unit)
        ridx += 1
        format_group_row(ws, ridx, range(1, 5), 'FFE699', 12)
        qs_staff = Staff.objects.filter(unit=unit, serviceman__isnull=False)
        for staff in qs_staff:
            missing = get_missing_string(staff.serviceman, qs_vaca, 'відпустка', month_last_date)
            missing += get_missing_string(staff.serviceman, qs_trip, 'відрядження', month_last_date)
            missing += get_missing_string(staff.serviceman, qs_hosp, 'лікарняний', month_last_date)
            missing += get_missing_string(staff.serviceman, qs_illa, 'СЗЧ', month_last_date)
            missing += get_missing_string(staff.serviceman, qs_arst, 'Арешт', month_last_date)
            missing += get_losses_string(staff.serviceman, qs_loss, 'Втрати', month_last_date)
            row_staff = [staff.staff_id,
                         staff.serviceman.full_name_upper,
                         staff.serviceman.rank.name.lower(),
                         missing.strip()]
            ws.append(row_staff)
            ridx += 1

    # # format table
    # set column width
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 40
    ws.column_dimensions['C'].width = 20
    ws.column_dimensions['D'].width = 40
    #
    # wrap text and top alignment for table content
    for row in ws.iter_rows():
        for cell in row:
            if row[0] and cell.row > 1:
                cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

    ws.sheet_view.zoomScale = 80
    print('## create_missing_by_unit_combat_group_worksheet - Done')


def create_missing_by_disposals_worksheet(wb, qs_vaca, qs_trip, qs_hosp, qs_illa, qs_loss, qs_arst,
                                          month_last_date):
    from .models import ServicemanAtDisposal
    print('## create_missing_by_disposals_worksheet')
    sheet_name = 'У розпорядженні'
    ws = get_worksheet(wb, sheet_name)

    qs = ServicemanAtDisposal.objects.filter(order_out__isnull=False,
                                             order_out__date__lte=datetime.today().date(),
                                             order_in__isnull=True).order_by(
                                                 'serviceman__last_name',
                                                 'serviceman__first_name')
    ridx = 0
    for item in qs:
        missing = get_missing_string(item.serviceman, qs_vaca, 'відпустка', month_last_date)
        missing += get_missing_string(item.serviceman, qs_trip, 'відрядження', month_last_date)
        missing += get_missing_string(item.serviceman, qs_hosp, 'лікарняний', month_last_date)
        missing += get_missing_string(item.serviceman, qs_illa, 'СЗЧ', month_last_date)
        missing += get_missing_string(item.serviceman, qs_arst, 'Арешт', month_last_date)
        missing += get_losses_string(item.serviceman, qs_loss, 'Втрати', month_last_date)
        row = [item.id,
               item.serviceman.full_name_upper,
               item.serviceman.rank.name.lower(),
               missing.strip()]
        ws.append(row)
        ridx += 1

    # # format table
    # set column width
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 40
    ws.column_dimensions['C'].width = 20
    ws.column_dimensions['D'].width = 40
    #
    # wrap text and top alignment for table content
    for row in ws.iter_rows():
        for cell in row:
            if row[0] and cell.row > 1:
                cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

    ws.sheet_view.zoomScale = 80
    print('## create_missing_by_disposals_worksheet - Done')


def format_group_row(ws, row_idx, columns, color, sz=14):
    for col in columns:
        ws.cell(row=row_idx, column=col).fill = PatternFill("solid", fgColor=color)
        ws.cell(row=row_idx, column=col).font = openpyxl.styles.Font(bold=True, size=sz)

def format_cells(ws, row_idx, columns, color):
    for col in columns:
        ws.cell(row=row_idx, column=col).fill = PatternFill("solid", fgColor=color)


def create_staff_by_unit_combat_group_worksheet(wb):
    from .models import UnitGroup, UnitCombatGroup, Unit, Staff

    start = time.time()
    func = inspect.currentframe().f_code.co_name
    print(f'## {func}')

    ws = get_worksheet(wb, 'Штат (друк)')

    ridx = 1  # skip existing header row
    qs_group = UnitGroup.objects.all().order_by('group_id')
    for g in qs_group:
        qs_cg = UnitCombatGroup.objects.filter(unit_group=g).order_by('group_id')
        print(f'unit group: [{g.group_id}. {g.name}]')
        row_g = ['', g.name]
        ws.append(row_g)
        ridx += 1
        format_group_row(ws, ridx, range(1, 15), "FFE699")

        for cg in qs_cg:    # combat groups
            qs_unit = Unit.objects.filter(combat_group=cg).order_by('group_id', 'unit_id')
            print(f'combat group: {cg.group_id}. {cg.name}')
            row_cg = ['', cg.name]
            ws.append(row_cg)
            ridx += 1
            format_group_row(ws, ridx, range(1, 15), "92D050")

            for unit in qs_unit:    # units in combat groups
                row_unit = [None, f'{unit.full_name}{" (" + unit.name + ")" if unit.name.lower() != unit.full_name.lower() else ""}']

                qs_staff = Staff.objects.filter(Q(date_end__isnull=True) |
                                                Q(date_end__gte=datetime.today()) |
                                                Q(serviceman__isnull=False),
                                                date_start__lte=datetime.today(),
                                                unit=unit
                                                ).order_by('staff_id', 'id')

                if cg.name.lower() != unit.full_name.lower():  # and qs_staff.count() > 0:
                    print(f'unit: {unit.unit_id} {unit.full_name}')
                    ws.append(row_unit)
                    ridx += 1
                    format_group_row(ws, ridx, range(1, 15), "D6DCE4", 12) #00E2EFDA

                for item in qs_staff:   # staff
                    row_staff = [
                                 item.staff_id,
                                 item.position.name.capitalize(),
                                 item.position.tariff.tariff_short_name,
                                 item.position.milspec,
                                 item.position.position_category.name if item.position.position_category else '-',
                                 # item.position.position_category.get_rank_level_display(),
                                 item.serviceman.rank.__str__() if item.serviceman else '',
                                 item.serviceman.full_name_upper if item.serviceman else '',  # 'ВАКАНТ',
                                 item.unit.parent_unit.name if item.unit.parent_unit else '',
                                 # item.unit.name,
                                 # item.unit.combat_group.name if item.unit.combat_group else '?',
                                 # item.unit.letter,
                                 item.serviceman.date_of_birth if item.serviceman else '',
                                 item.serviceman.tax_id if item.serviceman else '',
                                 item.serviceman.phone_number if item.serviceman else '',
                                 f'ТВО: {item.temporary_acting.__str__()}' if item.temporary_acting else '',
                                 f'К: {item.candidate.__str__()}' if item.candidate else '',
                                 '',
                                 item.serviceman.acceptance_order.date if item.serviceman and item.serviceman.acceptance_order else '',
                                 ]
                    ws.append(row_staff)
                    ridx += 1

                    status = get_staff_position_status(item)
                    if status == 1:  # CLOSED, closed staff positions
                        format_cells(ws, ridx, range(1, 5), '00FF5050')
                        if item.serviceman:
                            format_cells(ws, ridx, range(6, 8), '00FF5050')

                    # vacant
                    if not item.serviceman:
                        format_cells(ws, ridx, range(6, 8), '00E2EFDA')

                    # rank level
                    c = ws.cell(row=ridx, column=5)
                    if item.position.position_category:
                        cl = get_rank_level_color(item.position.position_category)
                        if cl:
                            c.fill = PatternFill("solid", fgColor=cl)

                    # ТВО
                    if item.temporary_acting:
                        ws.cell(row=ridx, column=12).fill = PatternFill("solid", fgColor="00FFFF00")

                    # date_of_birth, acceptance date
                    ws.cell(row=ridx, column=9).number_format = 'dd/mm/yyyy'
                    ws.cell(row=ridx, column=15).number_format = 'dd/mm/yyyy'

                    # center:top
                    for col in (3, 4, 9, 10, 11, 15):
                        ws.cell(row=ridx, column=col).alignment = Alignment(horizontal='center', vertical='top')

    # format table
    # wrap text and top alignment for table content
    for row in ws.iter_rows():
        for cell in row:
            if row[0].value and cell.row > 1:
                cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')
    #
    # ws.sheet_view.zoomScale = 80
    print(f'## {func} - Done (%.2f seconds)' % (time.time() - start))


def create_excel_file_staff(model, queryset):
    wb = openpyxl.Workbook()
    wb.remove_sheet(wb.active)
    create_staff_worksheet(wb, queryset, True)
    wb.save(model.save_to)

    return model.save_to


# def create_excel_file_staff_by_units(model, queryset):
#     from .models import UnitCombatGroup
#
#     wb = openpyxl.Workbook()
#     wb.remove_sheet(wb.active)
#     cgqs = UnitCombatGroup.objects.all().order_by('group_id')
#
#     for cg in cgqs:
#         create_missing_by_unit_combat_group_worksheet(wb, cg)
#     save_to = os.path.join(settings.DOCUMENTS_DIR, f'staff_{datetime.now().strftime("%Y.%m.%d")}.xlsx')
#     wb.save(save_to)
#
#     return save_to


def create_excel_file_staff_missing(model, queryset, dt):
    from .models import UnitCombatGroup
    from .models import ServicemanIllegallyAbsent, Losses

    wb = openpyxl.Workbook()
    wb.remove_sheet(wb.active)
    cgqs = UnitCombatGroup.objects.all().order_by('group_id')

    month_first_date, month_last_date = get_month_dates(dt)

    # у відпустці
    qs_vaca = Vacation.objects.filter((Q(order_in__isnull=True) | Q(order_in__date__gte=month_first_date)),
                                      order_out__isnull=False,
                                      order_out__date__lte=month_last_date)
    # у відрядженні
    qs_trip = Trip.objects.filter((Q(order_in__isnull=True) | Q(order_in__date__gte=month_first_date)),
                                  order_out__isnull=False,
                                  order_out__date__lte=month_last_date)
    # на лікарняному
    qs_hosp = Hospitalization.objects.filter((Q(order_in__isnull=True) | Q(order_in__date__gte=month_first_date)),
                                             order_out__isnull=False,
                                             order_out__date__lte=month_last_date)
    # СЗЧ
    qs_illa = ServicemanIllegallyAbsent.objects.filter((Q(order_in__isnull=True) | Q(order_in__date__gte=month_first_date)),
                                                       order_out__isnull=False,
                                                       order_out__date__lte=month_last_date)
    # втрати
    qs_loss = Losses.objects.filter((Q(order_daily_in__isnull=True) | Q(order_daily_in__date__gte=month_first_date)),
                                    order_daily__isnull=False,
                                    order_daily__date__lte=month_last_date)
    # Арешт
    qs_arst = Arrest.objects.filter(order_out__isnull=False,
                                    order_out__date__lte=datetime.today().date(),
                                    order_in__isnull=True)

    # staff
    for cg in cgqs:
        create_missing_by_unit_combat_group_worksheet(wb, cg,
                                                      qs_vaca, qs_trip, qs_hosp, qs_illa, qs_loss, qs_arst,
                                                      month_last_date)

    # disposals
    create_missing_by_disposals_worksheet(wb,
                                          qs_vaca, qs_trip, qs_hosp, qs_illa, qs_loss, qs_arst,
                                          month_last_date)

    save_to = os.path.join(settings.DOCUMENTS_DIR, f'missing_{datetime.now().strftime("%Y.%m.%d")}.xlsx')
    wb.save(save_to)

    return save_to


def create_excel_file_serviceman(model, queryset):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Список 204'
    headers = ['№ з/п',
               'Військове звання фактичне',
               'ПІБ',
               'Штат',
               'Посада за штатом (повністю)',
               'Дата народження',
               'ІПН',
               'Телефон',
               'Наказ про зарахування',
               'Наказ про виключення',
               ]
    ws.append(headers)
    thin = Side(border_style="thin", color="000000")
    for x in range(1, len(headers)+1):
        ws.cell(row=1, column=x).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=1, column=x).border = Border(top=thin, left=thin, right=thin, bottom=thin)
        ws.cell(row=1, column=x).fill = PatternFill("solid", fgColor="0099CCFF")

    i = 1
    for item in queryset:
        row = [
            i,
            item.rank.__str__(),
            item.full_name,
            item.staff_short_name,
            item.staff_full_name,
            item.birthday,
            item.tax_id,
            item.phone_number,
            item.acceptance_order.short_name if item.acceptance_order else '',
            item.dismissal_order.short_name if item.dismissal_order else ''
        ]
        ws.append(row)
        i = i+1

    # # format table
    # set column width
    ws.column_dimensions['A'].width = 8
    ws.column_dimensions['B'].width = 25
    ws.column_dimensions['C'].width = 35
    ws.column_dimensions['D'].width = 35
    ws.column_dimensions['E'].width = 35
    ws.column_dimensions['F'].width = 12
    ws.column_dimensions['G'].width = 12
    ws.column_dimensions['H'].width = 14
    ws.column_dimensions['I'].width = 21
    ws.column_dimensions['J'].width = 21

    # wrap text and top alignment for table content
    for row in ws.iter_rows():
        for cell in row:
            if cell.row > 1:
                cell.alignment = cell.alignment.copy(wrap_text=True, vertical='top')

    ws.sheet_view.zoomScale = 80

    path = model.save_to  # os.path.join(settings.DOCUMENTS_DIR, 'test.xlsx')
    wb.save(path)

    return path

