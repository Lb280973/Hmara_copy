#!/usr/bin/bash

docker build -t uaf . # build image
docker run --rm --name uaf --env-file .env -d uaf # run image with environment variables in detached mode
docker exec -it uaf python manage.py migrate --noinput # run migrations
docker stop uaf # stop container




