import json
import os
from datetime import datetime
from urllib.parse import quote as urlquote
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.admin.templatetags.admin_urls import add_preserved_filters
from django.contrib.admin.utils import quote
from django.db.models import Max, Min
from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from django.utils.html import format_html
from django.utils.translation import gettext as _

from conf import settings
# from personnel.models import *
from utils.docfiles import *
# get_docfile_response, create_doc_from_template, create_doc_from_template_queryset, \

IS_POPUP_VAR = "_popup"
TO_FIELD_VAR = "_to_field"


class PreservedFormDataMixin:
    """
    Mixin for admin views that preserves form data on object creation
    """

    def get_free_numbers(self, request, queryset):
        numbers = list(queryset.values_list('input_id', flat=True))

        # Знаходимо мінімальне та максимальне значення номерів у рекордсеті
        min_number = min(numbers)
        max_number = max(numbers)

        # Створюємо список усіх можливих номерів, які повинні бути у рекордсеті
        all_numbers = list(range(min_number, max_number + 1))

        # Знаходимо відсутні номери у списку усіх можливих номерів
        missing_numbers = list(set(all_numbers) - set(numbers))

        # Формуємо список відсутніх діапазонів номерів у порядку спадання
        missing_ranges = []
        range_start = None
        for i in range(len(missing_numbers)):
            if i == 0 or missing_numbers[i] != missing_numbers[i - 1] + 1:
                range_start = missing_numbers[i]
            if i == len(missing_numbers) - 1 or missing_numbers[i] != missing_numbers[i + 1] - 1:
                range_end = missing_numbers[i]
                if range_start == range_end:
                    missing_ranges.append(str(range_start))
                else:
                    missing_ranges.append(str(range_start) + '-' + str(range_end))

        # Сортуємо список відсутніх діапазонів номерів у порядку спадання
        missing_ranges.sort(key=lambda x: int(x.split('-')[0]), reverse=True)

        if len(missing_ranges)>0:
            messages.success(request, f'Вільні номери:')
            messages.success(request, ', '.join(missing_ranges))
            # messages.success(request, f'{missing_ranges} ')
        else:
            messages.warning(request, 'Вільні номери відсутні')

        return True

    get_free_numbers.short_description = 'Отримати вільні номери'


    def response_add(self, request, obj, post_url_continue=None):
        """
        Determine the HttpResponse for the add_view stage.
        """
        opts = obj._meta
        preserved_filters = self.get_preserved_filters(request)
        obj_url = reverse(
            "admin:%s_%s_change" % (opts.app_label, opts.model_name),
            args=(quote(obj.pk),),
            current_app=self.admin_site.name,
        )
        # Add a link to the object's change form if the user can edit the obj.
        if self.has_change_permission(request, obj):
            obj_repr = format_html('<a href="{}">{}</a>', urlquote(obj_url), obj)
        else:
            obj_repr = str(obj)
        msg_dict = {
            "name": opts.verbose_name,
            "obj": obj_repr,
        }
        # Here, we distinguish between different save types by checking for
        # the presence of keys in request.POST.

        if IS_POPUP_VAR in request.POST:
            to_field = request.POST.get(TO_FIELD_VAR)
            if to_field:
                attr = str(to_field)
            else:
                attr = obj._meta.pk.attname
            value = obj.serializable_value(attr)
            popup_response_data = json.dumps(
                {
                    "value": str(value),
                    "obj": str(obj),
                }
            )
            return TemplateResponse(
                request,
                self.popup_response_template
                or [
                    "admin/%s/%s/popup_response.html"
                    % (opts.app_label, opts.model_name),
                    "admin/%s/popup_response.html" % opts.app_label,
                    "admin/popup_response.html",
                ],
                {
                    "popup_response_data": popup_response_data,
                },
            )

        elif "_continue" in request.POST or (
                # Redirecting after "Save as new".
                "_saveasnew" in request.POST
                and self.save_as_continue
                and self.has_change_permission(request, obj)
        ):
            msg = _("The {name} “{obj}” was added successfully.")
            if self.has_change_permission(request, obj):
                msg += " " + _("You may edit it again below.")
            self.message_user(request, format_html(msg, **msg_dict), messages.SUCCESS)
            if post_url_continue is None:
                post_url_continue = obj_url
            post_url_continue = add_preserved_filters(
                {"preserved_filters": preserved_filters, "opts": opts},
                post_url_continue,
            )
            return HttpResponseRedirect(post_url_continue)
        elif "_addanother" in request.POST:
            msg = format_html(
                _(
                    "The {name} “{obj}” was added successfully. You may add another "
                    "{name} below."
                ),
                **msg_dict,
            )
            self.message_user(request, msg, messages.SUCCESS)
            redirect_url = request.path
            redirect_url = add_preserved_filters(
                {"preserved_filters": preserved_filters, "opts": opts}, redirect_url
            )
            return HttpResponseRedirect(redirect_url)
        elif "_addsimilar" in request.POST:
            # Redirect to the same form, keeping the same values. Useful for adding a bunch of reports, trips, etc.
            params = {}
            for key, value in dict(request.POST).items():
                if not key.startswith('_') and not key.startswith('csrf'):
                    if key == 'index':
                        index_id = value[0].split("/")[0]
                        if index_id:
                            new_index_id = int(index_id) + 1
                            new_index = value[0].replace(index_id, str(new_index_id))
                            params[key] = new_index
                    elif key == 'input_id':
                        params[key] = int(value[0]) + 1
                    else:
                        params[key] = value[0]

            msg = format_html(
                _(
                    "The {name} “{obj}” was added successfully. You may add another "
                    "{name} below."
                ),
                **msg_dict,
            )
            self.message_user(request, msg, messages.SUCCESS)
            redirect_url = request.path
            redirect_url += f'?{urlencode(params)}'
            redirect_url = add_preserved_filters(
                {"preserved_filters": preserved_filters, "opts": opts}, redirect_url
            )
            return HttpResponseRedirect(redirect_url)

        else:
            msg = format_html(
                _("The {name} “{obj}” was added successfully."), **msg_dict
            )
            self.message_user(request, msg, messages.SUCCESS)
            return self.response_post_save_add(request, obj)


class DocFileMixin:
    """
    Mixin for admin views that allows to render and download a document file
    """

    def log_decorator(func):
        def wrapper(*args, **kwargs):
            from documents.admin import logger
            logger.info(f"[{func.__name__}] args: {args}, kwargs: {kwargs}")
            # print(f'{args[1]}, {type(args[1])}')
            result = func(*args, **kwargs)
            logger.info(f"[{func.__name__}] result={result}")
            return result

        return wrapper

    @log_decorator
    def create_doc_file(self, request, queryset):
        print(f'create_doc_file>> {self.save_to}')
        path = create_doc_from_template(queryset, self.template, self.save_to)
        messages.success(request, 'Файли успішно згенеровано')
        return get_docfile_response(path)

    create_doc_file.short_description = 'Згенерувати документи'

    @log_decorator
    def create_doc_file2(self, request, queryset):
        print(f'create_doc_file2>> {self.save_to}')
        path = create_doc_from_template_queryset(request, queryset, self.template, self.save_to)
        messages.success(request, 'Файли успішно згенеровано')
        return get_docfile_response(path)

    create_doc_file2.short_description = 'Згенерувати документи'

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        if getattr(self.model, 'index', None):
            try:
                items = self.model.objects.filter(Q(index__regex=r'^\d+$'))
                max_found = max(int(item.index) for item in items)
                new_index = int(max_found) + 1
            except:
                new_index = 1
            form.base_fields['index'].initial = str(new_index)

            # count = self.model.objects.filter(issue_date=datetime.today()).count() + 1
            # form.base_fields['index'].initial = f'{count}/{datetime.now().strftime("%d/%m")}'
        return form

    @log_decorator
    def create_reward4wounding(self, request, queryset):
        if queryset.count() > 1:
            messages.warning(request, 'Оберіть тільки ОДИН запис!')
        else:
            path = create_doc_from_template_queryset(request, queryset[0].participants.all(),
                                                     'reward4wounding_template.docx',
                                                     settings.DOCUMENTS_DIR)
            messages.success(request, 'Файл успішно згенеровано')
            return get_docfile_response(path)

    create_reward4wounding.short_description = 'Згенерувати Подання про нагородження (за поранення)'

    @log_decorator
    def create_transfer_plan(self, request, queryset):
        path = create_transfer_plan_from_template(request,
                                                  queryset,
                                                  settings.DOCUMENTS_DIR)
        if path:
            messages.success(request, 'Файл успішно згенеровано')
            return get_docfile_response(path)

    create_transfer_plan.short_description = 'Згенерувати План переміщення'

    @log_decorator
    def create_daily_order(self, request, queryset):
        if queryset.count() > 1:
            messages.warning(request, 'Оберіть тільки ОДИН запис!')
            return
        if queryset[0].order_type.id != 1:  # Daily Order
            messages.error(request, f'Невірний тип наказу! {queryset[0].order_type}')
            return

        path = create_daily_order_from_template(request, queryset[0].id)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_daily_order.short_description = 'Згенерувати Добовий наказ'

    @log_decorator
    def create_rs_order(self, request, queryset):
        if queryset.count() > 1:
            messages.warning(request, 'Оберіть тільки ОДИН запис!')
            return
        if queryset[0].order_type.id != 3:  # RS Order
            messages.error(request, 'Невірний тип наказу!')
            return

        path = create_rs_order_from_template(request, queryset[0].id)
        messages.success(request, 'Файл успішно згенеровано')
        return get_docfile_response(path)

    create_rs_order.short_description = 'Згенерувати РС наказ'