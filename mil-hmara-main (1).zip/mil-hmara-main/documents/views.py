import inspect
import logging
import os
import time
from datetime import datetime

import openpyxl
from django.conf import settings
from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponse, HttpResponseBadRequest
from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from openpyxl.styles import Alignment, Side, Border, PatternFill

from personnel.models import UnitCombatGroup, Staff, ServicemanAtDisposal, ServicemanAttached
from personnel.views import create_staff_worksheet, create_missing_worksheet, \
    create_staff_by_unit_combat_group_worksheet, create_disposal_or_attached_worksheet
from utils.docfiles import get_globals
from .forms import ReportStatusForm
from .models import Report, ReportStatus, Order
from .models import Trip, Vacation

logger = logging.getLogger(__name__)


def status_view(request):
    if request.POST:
        data = request.POST
        status_id = int(data.get('status'))
        report_ids = data.get('report')
        qs = Report.objects.filter(pk__in=report_ids)
        qs.update(status=ReportStatus.objects.get(id=status_id))
        messages.success(request, f'Статус успішно змінено для {qs.count()}')
        return HttpResponseRedirect(reverse('admin:documents_report_changelist'))
    context = {
        'form': ReportStatusForm
    }
    return render(request, 'admin/documents/change_status.html', context=context)


def create_report(wb, model, direction='in'):
    print(f'##: create_report, model: {model}, direction: {direction}')
    """
    Creates a report for a given model and direction
    :param model: Trip or Vacation
    :param direction: Determines whether to create a report for incoming, outgoing, or personnel,
    that didn't come back in time.
    :return:
    """
    sheet_index = len(wb.sheetnames)
    if direction == 'out':
        sheet_name = f'Вибули у {"відрядження" if model == Trip else "відпустку"}'
        qs = model.objects.filter(order_out__date=datetime.today())
    elif direction == 'in':
        sheet_name = f'Прибули з {"відрядження" if model == Trip else "відпустки"}'
        qs = model.objects.filter(order_in__date=datetime.today())
    elif direction == 'missing':
        sheet_name = f'Не прибули з {"відрядження" if model == Trip else "відпустки"}'
        qs = model.objects.filter(must_return_date__lte=datetime.today(), returned=None)
    elif direction == 'current':
        qs = Trip.objects.filter(order_in__date=None, returned=None)
        sheet_name = f'поточні відрядження'
    else:
        raise Exception('direction must be in or out')

    fields = [
        ('index', 'Індекс'),
        ('order_out__order_id', 'Номер наказу про вибуття'),
    ]
    # check if model is Trip or Vacation, and add fields accordingly
    if model == Trip:
        fields.extend([
            ('destination', 'Місце призначення'),
            ('goal', 'Мета'),
            ('report', 'Рапорт'),
            ('reason', 'Підстава'),
            ('by', 'Транспортний засіб'),
            ('weapon', 'Зброя')]
        )
    elif model == Vacation:
        fields.extend([
            ('certificate', 'Довідка'),
            ('location', 'Місце відпустки'),
            ('type', 'Тип відпустки'),
        ])
    headers = ['Звання, ПІБ, посада']
    headers.extend([field[1] for field in fields])
    if model == Vacation:
        headers.append('Рапорт')
    date_headers = [
        'Термін',
        'Дата відправлення',
        'Дата закінчення',
        'Має повернутись',
        'Фактична дата повернення',
    ]
    headers.extend(date_headers)
    ws = create_worksheet(wb, sheet_name, sheet_index)
    ws.append(headers)

    for item in qs:
        row = None
        if model == Trip:
            row = [
                item.serviceman.full_title,
                item.index,
                item.order_out.order_id,
                item.destination,
                item.goal,
                item.report.verbose_info if item.report else '-',
                item.reason,
                item.by,
                item.weapon, item.verbose_days_full,
                item.date_from.strftime('%d %B %Y року') if item.date_from else '-',
                item.date_to.strftime('%d %B %Y року') if item.date_to else '-',
                item.must_return_date.strftime('%d %B %Y року') if item.must_return_date else '-',
                item.returned.strftime('%d %B %Y року') if item.returned else '-'
            ]
        elif model == Vacation:
            row = [
                item.serviceman.full_title,
                item.index,
                item.order_out.order_id if item.order_out else '-',
                item.certificate,
                item.location,
                item.get_vtype_display(),
                item.report.verbose_info if item.report else '-',
                item.verbose_days_full,
                item.date_from.strftime('%d %B %Y року') if item.date_from else '-',
                item.date_to.strftime('%d %B %Y року') if item.date_to else '-',
                item.must_return_date.strftime('%d %B %Y року') if item.must_return_date else '-',
                item.returned.strftime('%d %B %Y року') if item.returned else '-'
            ]
        ws.append(row)

    format_headers(ws, headers)
    format_worksheet(ws)


def get_combat_group_counts():
    return 1, 2


def create_cnc_report(wb):
    print(f'##: create_cnc_report')
    sheet_name = 'БЧС'
    sheet_index = len(wb.sheetnames)
    ws = create_worksheet(wb, sheet_name, sheet_index)

    # wb.create_named_range('global1', None, '$B$11:$B$35')
    wb.create_named_range('local1', ws, '$B$11:$B$35')
    wb.create_named_range('local2', ws, '$A$1:$A$5')

    qs = UnitCombatGroup.objects.all() # order ?
    n = 0
    for item in qs:
        staff_count, list_count = get_combat_group_counts()
        row = [
            item.group_id,
            item.unit_group.name,
            item.name,
            staff_count,
            list_count
        ]
        ws.append(row)
        n += 1

    # ref = f"{quote_sheetname(ws.title)}!{absolute_coordinate('A1:A5')}"
    # print(f"title: {ws.title}")
    # print(f"ref:{ref}")
    # defn = DefinedName("global_range", attr_text=ref)
    # print(f"defn:{defn}")
    # print(f"defined_names:{wb.defined_names}")
    # wb.defined_names["global_range0"] = defn
    # wb.defined_names.add(defn)


    # wb.defined_names.definedName = []

    # print(f"defined_names:{wb.defined_names}")
    # ref = f"{quote_sheetname(ws.title)}!{absolute_coordinate('A1:A5')}"
    # new_range = DefinedName('newrange', attr_text=ref)  # 'Sheet!$B$1:$B$5')
    # wb.defined_names.append(new_range)

    #format_worksheet(ws)


def format_headers(ws, headers):
    thin = Side(border_style="thin", color="000000")
    for x in range(1, len(headers) + 1):
        ws.cell(row=1, column=x).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=1, column=x).border = Border(top=thin, left=thin, right=thin, bottom=thin)
        ws.cell(row=1, column=x).fill = PatternFill("solid", fgColor="0099CCFF")


def format_worksheet(ws):
    """
    Adjusts column width, wrap text, align text in a worksheet - makes it readable
    """
    rows = ws.iter_rows()
    for row in rows:
        for cell in row:
            cell.alignment = Alignment(wrap_text=True)

    for col in ws.columns:
        length = 0
        max_length = 30
        column = col[0].column_letter  # Get the column name
        for cell in col:
            try:  # Necessary to avoid an error on empty cells
                if len(str(cell.value)) > length:
                    length = len(str(cell.value))
            except Exception as e:
                logger.warning(e)
        adjusted_width = (length if length < max_length else max_length) + 2
        ws.column_dimensions[column].width = adjusted_width


def get_report_path(dir_name, file_name):
    save_to = os.path.join(settings.DOCUMENTS_DIR, dir_name)
    print(f'## get_report_path, dir_name: {dir_name}, file_name: {file_name}, save_to: {save_to}')
    if not os.path.exists(save_to):
        os.makedirs(save_to)
    path = os.path.join(save_to, file_name)
    return path


def get_workbook(path):
    if os.path.exists(path):
        wb = openpyxl.load_workbook(path)
        print(f'workbook loaded: {path}')
    else:
        wb = openpyxl.Workbook()
        print(f'workbook not found: {path}, new workbook created')
    return wb


def create_vars_worksheet(request, wb):
    sheet_name = 'Дані'
    ws = wb.get_sheet_by_name(sheet_name)
    if not ws:
        ws = wb.create_sheet(sheet_name, len(wb.sheetnames))

    order = Order.objects.filter(order_type__id=1).order_by('-date').first()
    if not order:
        messages.warning(request, 'Поточний добовий наказ на знайдено!')

    globa = get_globals()
    rows = (['Дата формування', datetime.today().date().strftime('%d.%m.%Y')],
            ['Дійсна назва в/ч', globa.military_unit_name_private],
            ['Умовна назва в/ч', globa.military_unit_name_public],
            ['Командир (звання)', globa.commander_rank],
            ['Командир (ПІБ)', globa.commander_name],
            ['Начальник штабу (звання)', globa.chief_of_staff_rank],
            ['Начальник штабу (ПІБ)', globa.chief_of_staff_name],
            ['Добовий наказ (номер)', order.order_id],
            ['Добовий наказ (дата)', order.date if order else datetime.today().date()],
            )

    for idx, row in enumerate(rows):
        ws.cell(row=idx+1, column=1).value = row[0]
        ws.cell(row=idx+1, column=2).value = row[1]
    ws.cell(row=7, column=2).number_format = 'dd/mm/yyyy'


def create_daily_report(request=None):
    """
    Handles creation of daily report
    """

    start = time.time()
    func = inspect.currentframe().f_code.co_name
    logger.info(f'[{request.user.username}] {func}')
    report_path = get_report_path('Workbook', f'204_{datetime.now().strftime("%Y.%m.%d_%H_%M")}.xlsx')
    template_path = os.path.join(settings.BASE_DIR, f'doc_templates/daily_report_template.xlsx')
    wb = get_workbook(template_path)
    print(f'## {func}, report: {report_path}, template: {template_path}')

    # Global variables page
    create_vars_worksheet(request, wb)

    # Staff with Trips/Vacations/Hospitalizations/IllegallyAbsent columns
    create_staff_worksheet(wb, Staff.objects.filter(Q(date_end__isnull=True) |
                                                    Q(date_end__gte=datetime.today()) |
                                                    Q(serviceman__isnull=False),
                                                    date_start__lte=datetime.today()), False)

    create_staff_by_unit_combat_group_worksheet(wb)

    # Serviceman at disposal with IllegallyAbsent column
    create_disposal_or_attached_worksheet(
        wb,
        ServicemanAtDisposal.objects.filter(order_out__isnull=False,
                                            order_out__date__lte=datetime.today().date(),
                                            order_in__isnull=True).order_by(
                                                'serviceman__last_name',
                                                'serviceman__first_name'),
    False,
    'Розпорядники')

    # Serviceman attached
    create_disposal_or_attached_worksheet(
        wb,
        ServicemanAttached.objects.filter(order_out__isnull=False,
                                          order_out__date__lte=datetime.today().date(),
                                          order_in__isnull=True).order_by(
                                              'serviceman__last_name',
                                              'serviceman__first_name'),
    False,
    'Прикомандировані')

    # Missing servicemen
    create_missing_worksheet(wb)

    # Trip, Vacation
    # for direction in ['in', 'out', 'missing']:
    for direction in ['missing']:
        for model in [Trip, Vacation]:
            create_report(wb, model, direction=direction)

    # combat and numerical composition of the unit (БЧС)
    # create_cnc_report(wb)

    wb.save(report_path)
    logger.info(f'[{request.user.username}] {func} - Done (%.2f seconds)' % (time.time() - start))
    # progress_bar_instance.close()

    if request:
        messages.success(request, 'Звіт успішно створено')
        # return file for download
        with open(report_path, 'rb') as f:
            response = HttpResponse(
                f.read(),
                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'  # noqa
                # probably unnecessary to be that specific
            )
            response['Content-Disposition'] = f'attachment; filename={os.path.split(report_path)[-1]}'
            return response


def create_worksheet(wb, sheet_name, sheet_index):
    """
    Handle worksheet creation/overwriting
    """
    print(f'##: create_worksheet, ws:{sheet_name}[{sheet_index}]')

    # overwrite sheet if it exists
    try:
        ws = wb.get_sheet_by_name(sheet_name)
    except KeyError:
        ws = None

    if ws:
        wb.remove_sheet(ws)
    ws = wb.create_sheet(sheet_name, sheet_index)

    # remove default sheet
    try:
        default_sheet = wb.get_sheet_by_name('Sheet')
        wb.remove_sheet(default_sheet)
    except KeyError as e:
        pass

    return ws


def media(request, file_path=None):
    """
    Serve files
    """
    if not file_path:
        return HttpResponseBadRequest('Invalid File Path')

    with open(os.path.join(settings.MEDIA_ROOT, file_path), 'rb') as doc:
        response = HttpResponse(doc.read(), content_type='application/doc')
        response['Content-Disposition'] = 'filename=%s' % (file_path.split('/')[-1])
        return response
