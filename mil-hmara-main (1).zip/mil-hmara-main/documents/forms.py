from django import forms
from django.contrib.admin import widgets

from .models import Report, Order, ReportStatus
from personnel.models import Serviceman
from django.contrib import admin


class ReportStatusForm(forms.Form):
    report = forms.ModelMultipleChoiceField(
        Report.objects, widget=widgets.FilteredSelectMultiple('рапорти', False)
    )
    status = forms.ModelChoiceField(ReportStatus.objects)

