import datetime
import os
import re

import django
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Max, Min
from django.urls import reverse
from django.utils.html import format_html

# from personnel.mixins import check_serviceman_trip_and_raise
# from documents import admin
from utils.helpers import *  #get_verbose_days, get_short_date


class DocumentBase(models.Model):
    class Meta:
        abstract = True
    comment = models.TextField(blank=True, null=True, verbose_name='коментар')
    # status = models.CharField(max_length=2, verbose_name='статус', choices=Status.choices, default=Status.NEW)
    user = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, verbose_name='Користувач')

    def check_missing_and_raise(self):
        if self.serviceman.excluded or self.serviceman.dismissal_order:
            raise ValidationError(f'{self.serviceman.short_name} вже виключений зі списків!')
        # + СЗЧ, втрати
        qsa = Arrest.objects.filter(serviceman=self.serviceman,
                                    order_in__isnull=True).exclude(id=self.id)
        if len(qsa) > 0:
            raise ValidationError(f'{self.serviceman.short_name} під арештом! arrest.id={qsa.first().id}')
        qst = Trip.objects.filter(serviceman=self.serviceman,
                                  order_in__isnull=True).exclude(id=self.id)
        if len(qst) > 0:
            raise ValidationError(f'{self.serviceman.short_name} вже у відрядженні! trip.id={qst.first().id}')
        qsv = Vacation.objects.filter(serviceman=self.serviceman,
                                      order_in__isnull=True).exclude(id=self.id)
        if len(qsv) > 0:
            raise ValidationError(f'{self.serviceman.short_name} вже у відпустці! vacation.id={qsv.first().id}')
        qsh = Hospitalization.objects.filter(serviceman=self.serviceman,
                                             order_in__isnull=True).exclude(id=self.id)
        if len(qsh) > 0:
            raise ValidationError(
                f'{self.serviceman.short_name} вже на лікарняному! hospitalization.id={qsh.first().id}')


class Addressee(DocumentBase):
    class Type(models.TextChoices):
        MILITARY_BASE = "MIL", "Військова частина"
        COMMISSARIAT = "COM", "Військомат"
        CONTACT = "CON", "Контакт"

    class Meta:
        verbose_name = 'Адресати'
        verbose_name_plural = 'Адресати'

    type = models.CharField(max_length=3, verbose_name='Тип', choices=Type.choices, default=Type.MILITARY_BASE)
    name = models.CharField(max_length=1000, blank=False, null=False, verbose_name='назва')
    address = models.CharField(max_length=1000, blank=True, null=True, verbose_name='адреса')
    contacts = models.TextField(blank=True, null=True, verbose_name='контакти')
    link = models.CharField(max_length=1000, blank=True, null=True, verbose_name='лінк')

    def __str__(self):
        return f'{self.get_type_display()}: {self.name}'


class Order(DocumentBase):
    # class Direction(models.TextChoices):
    #     IN = "1", "ВХІДНИЙ"
    #     OUT = "2", "ФОРМУЄТЬСЯ"

    class Status(models.TextChoices):
        NEW = "1", "НОВИЙ"
        PROGRESS = "2", "ФОРМУЄТЬСЯ"
        VERIFICATION = "3", "НА ПЕРЕВІРЦІ"
        DONE = "4", "ВИКОНАНО"
        CANCELED = "5", "СКАСОВАНО"

    class Meta:
        verbose_name = 'наказ'
        verbose_name_plural = 'накази'

    name = models.CharField(max_length=2048, blank=True, null=True, verbose_name='назва',
                            default='по стройовій частині')
    order_id = models.CharField(max_length=128, blank=True, null=True, verbose_name='номер')
    by = models.CharField(max_length=256, verbose_name='ким виданий')  #, default='командира військової частини А7373')
    date = models.DateField(verbose_name='дата наказу', null=True, blank=True)
    mentioned = models.ManyToManyField('personnel.Serviceman', related_name='orders',
                                       verbose_name='вказані військовослужбовці', blank=True)
    type = models.CharField(max_length=256, blank=True, null=True, verbose_name='тип')
    order_type = models.ForeignKey('OrderType', on_delete=models.PROTECT, null=False, blank=False, default=1,
                                   verbose_name='тип')
    file = models.FileField(upload_to='Order', blank=True, null=True, verbose_name='файл')
    file_word = models.FileField(upload_to='OrderWord', blank=True, null=True, verbose_name='файл (Word)')
    file_report = models.FileField(upload_to='DailyReport', blank=True, null=True, verbose_name='добовий звіт')
    status = models.CharField(max_length=2, verbose_name='статус', choices=Status.choices, default=Status.NEW)
    assigned_to = models.ForeignKey('personnel.Assignee', on_delete=models.SET_NULL, blank=True, null=True,
                                    verbose_name='виконавець')

    def __str__(self):
        return f'№{self.order_id}, {get_short_date(self.date)}, {self.by.replace("командира військової частини ", "")} ({self.name})'
    # def __str__(self):
    #     return f'наказ {self.by} ({self.name}) від {get_short_date(self.date)} року №{self.order_id}'

    @property
    def name_verbose(self):
        return f'наказ {self.by} ({self.name}) від {get_verbose_date(self.date)} №{self.order_id}'
    name_verbose.fget.short_description = 'Назва (повна)'

    @property
    def name_in_genitive(self):
        return self.name_verbose.replace('наказ', 'наказу')

    @property
    def name_in_genitive_verbose(self):
        return self.name_verbose.replace('наказ', 'наказу')

    @property
    def name_in_ablative(self):
        return self.name_verbose.replace('наказ', 'наказом')

    @property
    def name_in_ablative_verbose(self):
        return self.name_verbose.replace('наказ', 'наказом')

    @property
    def short_name(self):
        return f'№{self.order_id}, {get_short_date(self.date)}'

    short_name.fget.short_description = 'Наказ'

    @property
    def status_rgb(self):
        if self.status == '1':
            return format_html(f'<b><span style="color:blue">{self.get_status_display()}</span></b>')
        elif self.status == '2':
            return format_html(f'<b><span style="color:green">{self.get_status_display()}</span></b>')
        elif self.status == '3':
            return format_html(f'<b><span style="color:magenta">{self.get_status_display()}</span></b>')
        elif self.status == '5':
            return format_html(f'<b><span style="color:red">{self.get_status_display()}</span></b>')
        else:
            return self.get_status_display()

    status_rgb.fget.short_description = 'Статус'

    @property
    def next_date(self):
        return get_short_date(self.date + datetime.timedelta(days=1))

    @property
    def next_date_verbose(self):
        return get_verbose_date(self.date + datetime.timedelta(days=1))

    @property
    def date_short(self):
        return get_short_date(self.date)

    @property
    def date_verbose(self):
        return get_verbose_date(self.date)

    @property
    def file_link(self):
        if self.file:
            # return format_html('<a href="{}"><img src="/path/to/download_icon.png"></a>', obj.file.url)
            # image_url = static('icons/1.ico')
            # print(image_url)
            # return format_html('<a href="{}"><img src="{}"></a>', self.file.url, image_url)
            return format_html('<a href="{}">FILE('+os.path.splitext(self.file.url)[1]+')</a>', self.file.url)
        else:
            return ''

    file_link.fget.short_description = 'Файл'

    @property
    def file_word_link(self):
        if self.file_word:
            return format_html('<a href="{}">FILE('+os.path.splitext(self.file_word.url)[1]+')</a>', self.file_word.url)
        else:
            return ''

    file_word_link.fget.short_description = 'Файл (Word)'

    @property
    def file_report_link(self):
        if self.file_report:
            return format_html('<a href="{}">FILE('+os.path.splitext(self.file_report.url)[1]+')</a>', self.file_report.url)
        else:
            return ''

    file_report_link.fget.short_description = 'Добовий звіт'


class OrderType(models.Model):
    class Meta:
        verbose_name = 'Довідник: тип наказу'
        verbose_name_plural = 'Довідник: типи наказів'

    order_type_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    name = models.CharField(max_length=256, verbose_name='назва типу')
    dsk = models.BooleanField(default=False, verbose_name='ДСК')

    def __str__(self):
        return f'{self.name}{" (ДСК)" if self.dsk else ""}'


class Report(DocumentBase):
    class Meta:
        verbose_name = 'рапорт'
        verbose_name_plural = 'рапорти'

    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.CASCADE, blank=True, null=True,
                                   verbose_name='подавач')
    input_id = models.PositiveIntegerField(unique=True, verbose_name='вхідний номер')
    type = models.ForeignKey('ReportType', on_delete=models.SET_NULL, blank=True, null=True, verbose_name='тип')
    status = models.ForeignKey('ReportStatus', on_delete=models.SET_NULL, null=True, verbose_name='статус')
    content = models.TextField(blank=True, null=True, verbose_name='короткий зміст рапорту')
    date = models.DateField(null=True, blank=True, verbose_name='дата')
    assigned_to = models.ForeignKey('personnel.Assignee', on_delete=models.SET_NULL, blank=True, null=True,
                                    verbose_name='виконавець')
    comment = models.CharField(max_length=512, blank=True, null=True, verbose_name='коментар')
    file = models.FileField(upload_to='Report', blank=True, null=True, verbose_name='файл')
    file2 = models.FileField(upload_to='Report', blank=True, null=True, verbose_name='файл (2)')

    def __str__(self):
        return self.verbose_info

    @property
    def short_info(self):
        return f'{self.serviceman.in_genitive_short if self.serviceman else "-"} від ' \
               f'{self.date.strftime("%d.%m.%Y")} року №{self.input_id}'

    @property
    def verbose_info(self):
        return f'№ {self.input_id} від {self.date.strftime("%d.%m.%Y")}, ' \
               f'{self.serviceman.full_title if self.serviceman else "-"}, {self.content}'

    @property
    def short_verbose_info(self):
        return f'№ {self.input_id} від {self.date.strftime("%d.%m.%Y")}, {self.serviceman.full_title if self.serviceman else "-"}'

    @property
    def short_name(self):
        return f'№{self.input_id}, {self.date.strftime("%d.%m.%Y")}, {self.serviceman.short_title2 if self.serviceman else "-"}'

    # @property
    # def status_rgb(self):
    #     if self.status == '1':
    #         return format_html(f'<b><span style="color:blue">{self.get_status_display()}</b>')
    #     elif self.status == '5':
    #         return format_html(f'<b><span style="color:red">{self.get_status_display()}</span></b>')
    #     else:
    #         return self.get_status_display()
    #
    # status_rgb.fget.short_description = 'Статус'


class ReportType(models.Model):
    class Meta:
        verbose_name = 'Довідник: тип рапорту'
        verbose_name_plural = 'Довідник: типи рапортів'

    report_type_id = models.PositiveIntegerField(blank=True, null=True, verbose_name='номер')
    name = models.CharField(max_length=256, verbose_name='назва типу')

    def __str__(self):
        return self.name


class ReportStatus(models.Model):
    class Meta:
        verbose_name = 'Довідник: статус рапорту'
        verbose_name_plural = 'Довідник: статуси рапортів'

    name = models.CharField(max_length=256, verbose_name='назва статусу')

    def __str__(self):
        return self.name


class MissingBase(DocumentBase):
    class Meta:
        abstract = True

    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.SET_NULL, null=True,
                                   verbose_name='військовослужбовець')
    issue_date = models.DateField(auto_now_add=True, blank=True, null=True, verbose_name='дата реєстрації')
    date_from = models.DateField(verbose_name='дата початку')
    date_to = models.DateField(verbose_name='дата закінчення', blank=True, null=True)
    report = models.ForeignKey(Report, verbose_name='рапорт (початок)', on_delete=models.SET_NULL, blank=True, null=True)
    order_out = models.ForeignKey(Order, verbose_name='наказ (початок)', on_delete=models.SET_NULL,
                                  blank=True, null=True,
                                  related_name='%(class)s_order_out',
                                  limit_choices_to={'order_type': 1})
    report_in = models.ForeignKey(Report, verbose_name='рапорт (закінчення)', on_delete=models.SET_NULL,
                                  blank=True, null=True,
                                  related_name='%(class)s_report_in')
    order_in = models.ForeignKey(Order, verbose_name='наказ (закінчення)', on_delete=models.SET_NULL,
                                 blank=True, null=True,
                                 related_name='%(class)s_order_in',
                                 limit_choices_to={'order_type': 1})

    @property
    def days(self):
        date_end = self.date_to if self.date_to else self.order_in.date if self.order_in else datetime.datetime.today().date()
        return abs((date_end - self.date_from).days) + 1 if self.date_from and date_end else 0
    days.fget.short_description = 'дні'

    @property
    def days_real(self):
        try:
            date_end_real = self.date_to_real if self.date_to_real else self.order_in.date if self.order_in else datetime.datetime.today().date()
            return abs((date_end_real - self.date_from).days) + 1 if self.date_from and date_end_real else 0
        except:
            print(f'id: {self.id}, date_from: {self.date_from}, date_to_real: {self.date_to_real}, date_end_real: {date_end_real}')
            return 0
    days_real.fget.short_description = 'дні'

    @property
    def days_real_verbose(self):
        return str(self.days) if self.days == self.days_real else format_html(f'<b>{self.days_real}({self.days})</b>')
    days_real_verbose.fget.short_description = 'дні'

    @property
    def verbose_days_short(self):
        return f'{self.days} {" день" if self.days == 1 else " дні"}' \
               f'{"" if 0 < self.days < 5 else "в"}'

    @property
    def verbose_days(self):
        return get_verbose_days(self.days)

    @property
    def verbose_calendar_days(self):
        return f'{self.days} ({get_verbose_days(self.days, True)})'

    @property
    def verbose_issue_date(self):
        return get_verbose_date(self.issue_date)

    @property
    def verbose_days_full(self):
        date_to_verbose = f'по {get_short_date(self.date_to)} року' if self.date_to else 'до окремого розпорядження'
        return f'{self.verbose_calendar_days if self.date_to else ""} з {get_short_date(self.date_from)} {date_to_verbose}'

    verbose_days.fget.short_description = 'термін'

    @property
    def date_from_short(self):
        return get_short_date(self.date_from)

    @property
    def verbose_date_from(self):
        return get_short_date(self.date_from)

    @property
    def verbose_date_from2(self):
        return get_verbose_date(self.date_from)

    @property
    def date_to_short(self):
        return get_short_date(self.date_to) if self.date_to else ''

    @property
    def verbose_date_to(self):
        return get_short_date(self.date_to) if self.date_to else 'окремого розпорядження'

    @property
    def verbose_must_return(self):
        return f"{get_verbose_date(self.must_return_date)}"

    @property
    def verbose_must_return_date(self):
        return get_short_date(self.must_return_date) if self.must_return_date else ''


    @property
    def serviceman_staff_full_name(self):
        return self.serviceman.staff_full_name2

    @property
    def order_out_short_name(self):
        return self.order_out.short_name

    @property
    def order_out_link(self):
        try:
            link = reverse("admin:documents_order_change", args=[self.order_out.id])
        except AttributeError as e:
            return '-'''
        else:
            return format_html('<a href="%s">%s</a>' % (link, self.order_out_short_name))

    order_out_link.fget.short_description = 'наказ про вибуття'

    @property
    def order_in_short_name(self):
        return self.order_in.short_name

    @property
    def order_in_link(self):
        try:
            link = reverse("admin:documents_order_change", args=[self.order_in.id])
        except AttributeError as e:
            return '-'
        else:
            return format_html('<a href="%s">%s</a>' % (link, self.order_in_short_name))

    order_in_link.fget.short_description = 'наказ про прибуття'

    @property
    def basis_out_verbose(self):
        return f'{"рапорт " + self.report.short_info if self.report else self.serviceman.in_genitive_short}'

    @property
    def basis_in_verbose(self):
        return f'{"рапорт " + (self.report_in.short_info if self.report_in else self.serviceman.in_genitive_short)}'


class Trip(MissingBase):
    class Meta:
        verbose_name = 'Відсутні: Відрядження'
        verbose_name_plural = 'Відсутні: Відрядження'

    index = models.CharField(max_length=32, blank=True, null=True, verbose_name='індекс')
    by = models.CharField(max_length=256, verbose_name='транспортний засіб', blank=True, null=True)
    weapon = models.CharField(max_length=256, blank=True, null=True, verbose_name='зброя')
    destination = models.CharField(max_length=256, verbose_name='куди')
    abroad = models.BooleanField(default=False, verbose_name='за кордон')
    goal = models.CharField(max_length=256, verbose_name='мета')
    must_return_date = models.DateField(verbose_name='має повернутись', blank=True, null=True)
    returned = models.DateField(blank=True, null=True, verbose_name='фактична дата повернення')
    # report_in = models.ForeignKey(Report, on_delete=models.SET_NULL, blank=True, null=True,
    #                                verbose_name='рапорт про прибуття', related_name='%(class)s_report_in')
    # order_in = models.ForeignKey(Order, verbose_name='наказ про прибуття', on_delete=models.SET_NULL,
    #                              blank=True, null=True, related_name='trip_in', limit_choices_to={'order_type': 1})
    reason = models.CharField(max_length=256, blank=True, null=True, verbose_name='підстава')
    accompanies = models.ManyToManyField('personnel.Serviceman', blank=True, verbose_name='з особовим складом',
                                         related_name='on_a_trip')
    file = models.FileField(upload_to='Trip', blank=True, null=True, verbose_name='файл')
    file2 = models.FileField(upload_to='Trip', blank=True, null=True, verbose_name='файл (2)')

    def clean(self):
        if not self.order_in:  # check opened trip only
            self.check_missing_and_raise()

    def __str__(self):
        return f'{self.index}, {self.serviceman.title if self.serviceman else "?"}, {self.destination}' \
               f', з {self.date_from.strftime("%d.%m.%Y") if self.date_from else "??"}' \
               f'{" по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""}'

    @property
    def print_name(self):
        return f'посвідчення про відрядження №{self.index} від {self.date_from.strftime("%d.%m.%Y")}'

    @property
    def date_to_real(self):
        return self.returned if self.returned and self.returned != self.date_to else self.date_to

    @property
    def date_to_real_rgb(self):
        return format_html(f'<b>{get_short_date(self.date_to_real)}</b>')\
            if self.date_to_real and self.date_to_real != self.date_to else get_short_date(self.date_to_real)

    date_to_real_rgb.fget.short_description = 'Дата закінчення'

    # @property
    # def basis(self):
    #     return self.print_name
    @property
    def basis_out_verbose(self):
        return f'{self.reason + ", " if self.reason else ""}' \
               f'{self.print_name}' \
               f'{", рапорт " + self.report.short_info if self.report else ""}'

    @property
    def basis_in_verbose(self):
        return f'{self.print_name}' \
               f'{", рапорт " + self.report_in.short_info if self.report_in else ""}'  # add report if present
               # f', рапорт {self.report_in.short_info if self.report_in else self.serviceman.in_genitive_short}'

    @property
    def serviceman_count(self):
        cnt = self.accompanies.count() + 1
        if cnt > 1:
            return format_html(f'<b>{cnt}</b>')
        else:
            return cnt

    serviceman_count.fget.short_description = 'О/С'

    @property
    def destination_rgb(self):
        if self.abroad:
            return format_html(f'<b><span style="color:LimeGreen">{self.destination}</span></>')
        else:
            return self.destination

    destination_rgb.fget.short_description = 'Куди'

    @property
    def status(self):
        if not self.order_out:
            return format_html(f'<span style="color:red">[відсутній наказ]</span>')
        if self.order_out.date > datetime.datetime.today().date():
            return format_html(f'<span style="color:red">[не почалося]</span>')
        if self.order_out and self.order_out.date < datetime.datetime.today().date() and not self.order_in and \
                (not self.must_return_date or (self.must_return_date and self.must_return_date > datetime.datetime.today().date())):
            return format_html(f'<span style="color:blue">у відрядженні</span>')
        elif self.order_out and self.order_out.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:green">у відрядженні (вибув)</span></b>')
        elif not self.order_in and self.must_return_date and self.must_return_date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:green">у відрядженні (має повернутися сьогодні)</span></b>')
        elif self.order_in and self.order_in.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:magenta">прибув з відрядження</span></b>')
        elif self.must_return_date and self.must_return_date < datetime.datetime.today().date() and not self.returned:
            return format_html(f'<b><span style="color:red">НЕ прибув з відрядження</span></b>')
        else:
            return 'закрите'

    status.fget.short_description = 'Статус'

    # @property
    # def order_in_short_name(self):
    #     return self.order_in.short_name
    #
    # @property
    # def order_in_link(self):
    #     try:
    #         link = reverse("admin:documents_order_change", args=[self.order_in.id])
    #     except AttributeError as e:
    #         return '-'
    #     else:
    #         return format_html('<a href="%s">%s</a>' % (link, self.order_in_short_name))
    #
    # order_in_link.fget.short_description = 'наказ про прибуття'


class TripProlongation(DocumentBase):
    class Meta:
        verbose_name = 'Відсутні: Відрядження (продовження)'
        verbose_name_plural = 'Відсутні: Відрядження (продовження)'

    date = models.DateField(verbose_name='дата', default=django.utils.timezone.now, blank=False, null=False)
    trip = models.ForeignKey(Trip, verbose_name='Відрядження', on_delete=models.PROTECT,
                             null=False, blank=False, limit_choices_to={'order_in__isnull': True})
    date_to_orig = models.DateField(verbose_name='початкова дата закінчення', blank=True, null=True)
    date_to = models.DateField(verbose_name='продовжити відрядження до', blank=True, null=True)
    report = models.ForeignKey(Report, on_delete=models.SET_NULL, blank=True, null=True, verbose_name='рапорт')
    order_rs = models.ForeignKey(Order, verbose_name='РС Наказ (підстава)', on_delete=models.SET_NULL,
                                 blank=True, null=True, related_name='%(class)s_order_rs',
                                 limit_choices_to={'order_type': 3})
    order_daily = models.ForeignKey(Order, verbose_name='До добового наказу', on_delete=models.SET_NULL,
                                    blank=True, null=True, related_name='%(class)s_order_daily',
                                    limit_choices_to={'order_type': 1})
    cause = models.CharField(max_length=1000, blank=True, null=True, verbose_name='підстава')

    def __str__(self):
        return f'{self.date.strftime("%d.%m.%Y")}, продовження відрядження {self.trip.index}, ' \
               f'{self.trip.serviceman.title}, ' \
               f'{"по " + self.date_to.strftime("%d.%m.%Y") + " на " + str(self.days) + " дні(в)" if self.date_to else "до окремого розпорядження"}'

    @property
    def days(self):
        return abs((self.date_to - self.date_to_orig).days) if self.date_to_orig and self.date_to else '-'

    days.fget.short_description = 'дні'

    @property
    def prolongation_term(self):
        return f'{"на " + str(self.days) + " календарних дні(в)" if self.date_to else "до окремого розпорядження"}' \
               f' з {self.order_daily.date_short} ' \
               f'{"по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""}'
    ## + 'з метою (мета продовження відрядження):'

    @property
    def basis_verbose(self):
        data = [self.order_rs.name_verbose if self.order_rs else None,
                self.cause,
                "рапорт " + self.report.short_info if self.report else None]
        return build_basis(data)


class Vacation(MissingBase):
    class Meta:
        verbose_name = 'Відсутні: Відпустка'
        verbose_name_plural = 'Відсутні: Відпустки'

    class Type(models.TextChoices):
        HEALTH = "HEA", "За станом здоров'я"
        FAMILY = "FAM", "За сімейними обставинами"
        REGULAR = "REG", "Щорічна основна"

    index = models.CharField(max_length=32, blank=True, null=True, verbose_name='індекс')
    location = models.CharField(max_length=256, verbose_name='буде перебувати')
    abroad = models.BooleanField(default=False, verbose_name='за кордон')
    vtype = models.CharField(max_length=3, verbose_name='Тип', choices=Type.choices, default=Type.HEALTH)
    must_return_date = models.DateField(verbose_name='має повернутись', blank=True, null=True)
    returned = models.DateField(blank=True, null=True, verbose_name='фактична дата повернення')
    certificate = models.CharField(max_length=256, blank=True, null=True, verbose_name='довідка')
    file = models.FileField(upload_to='Vacation', blank=True, null=True, verbose_name='файл')
    file2 = models.FileField(upload_to='Vacation', blank=True, null=True, verbose_name='файл (2)')

    def clean(self):
        if not self.order_in:  # check opened Vacation only
            self.check_missing_and_raise()

    def __str__(self):
        return f'{self.index}, {self.serviceman.title}, {self.get_vtype_display()}, ' \
               f'на {self.verbose_days}' \
               f', з {self.date_from.strftime("%d.%m.%Y") if self.date_from else "??"}' \
               f'{" по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""}'

    @property
    def date_to_real(self):
        return self.returned if self.returned and self.returned != self.date_to else self.date_to

    @property
    def date_to_real_rgb(self):
        return format_html(f'<b>{get_short_date(self.date_to_real)}</b>')\
            if self.date_to_real and self.date_to_real != self.date_to else get_short_date(self.date_to_real)

    date_to_real_rgb.fget.short_description = 'Дата закінчення'

    @property
    def print_name(self):
        return f'відпускний квиток № {self.index} від {self.date_from.strftime("%d.%m.%Y")} року'

    @property
    def basis_out_verbose(self):
        return f'{self.print_name}' \
               f'{", рапорт " + self.report.short_info if self.report else ""}'  # add report if present
               # f', рапорт {self.report.short_info if self.report else self.serviceman.in_genitive_short}'

    @property
    def basis_in_verbose(self):
        return f'{self.print_name}' \
               f'{", рапорт " + self.report_in.short_info if self.report_in else ""}'  # add report if present
               # f', рапорт {self.report_in.short_info if self.report_in else self.serviceman.in_genitive_short}'

    @property
    def status(self):
        if not self.order_out:
            return format_html(f'<span style="color:red">[відсутній наказ]</span>')
        if self.order_out.date > datetime.datetime.today().date():
            return format_html(f'<span style="color:red">[не почалася]</span>')
        if self.order_out and self.order_out.date < datetime.datetime.today().date() \
            and not self.order_in \
            and (not self.must_return_date or self.must_return_date > datetime.datetime.today().date()):
            return format_html(f'<span style="color:blue">у відпустці</span>')
        elif self.order_out and self.order_out.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:green">у відпустці (вибув)</span></b>')
        elif not self.order_in and self.must_return_date and self.must_return_date==datetime.datetime.today().date() and not self.order_in:
            return format_html(f'<b><span style="color:green">у відпустці (має повернутися сьогодні)</span></b>')
        elif self.order_in and self.order_in.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:magenta">прибув з відпустки</span></b>')
        elif self.must_return_date and self.must_return_date < datetime.datetime.today().date() and not self.returned:
            return format_html(f'<b><span style="color:red">НЕ прибув з відпустки</span></b>')
        else:
            return 'закрита'

    status.fget.short_description = 'Статус'

    @property
    def location_rgb(self):
        if self.abroad:
            return format_html(f'<b><span style="color:LimeGreen">{self.location}</span></>')
        else:
            return self.location

    location_rgb.fget.short_description = 'Буде перебувати'

    @property
    def terms(self):
        return f"з {get_verbose_date(self.date_from, False)} по {get_verbose_date(self.date_to, False)}"

    @property
    def must_return_str(self):
        return f"{get_verbose_date(self.must_return_date)}"

    @property
    def index_header(self):
        return f"{get_verbose_date(self.issue_date)}\n№ {self.index}"

    @property
    def placeholder(self):
        return '\n' * 28

    # @property
    # def order_in_short_name(self):
    #     return self.order_in.short_name
    #
    # @property
    # def order_in_link(self):
    #     try:
    #         link = reverse("admin:documents_order_change", args=[self.order_in.id])
    #     except AttributeError as e:
    #         return '-'
    #     else:
    #         return format_html('<a href="%s">%s</a>' % (link, self.order_in_short_name))
    #
    # order_in_link.fget.short_description = 'наказ про прибуття'


class Hospitalization(DocumentBase):
    class Meta:
        verbose_name = 'Відсутні: Лікарняний'
        verbose_name_plural = 'Відсутні: Лікарняні'

    class Type(models.TextChoices):
        REGULAR = "REG", "Хвороба"
        ILLNESS = "ILL", "Евакуйований внаслідок хвороби"
        INJURY = "ENJ", "Евакуйований з пораненнями"
        COMMISSION = "COM", "Проходження військово-лікарської комісії (ВЛК)"

    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.SET_NULL, null=True, blank=True,
                                   verbose_name='військовослужбовець')
    date_from = models.DateField(verbose_name='дата госпіталізації')
    type = models.CharField(max_length=3, verbose_name='Тип', choices=Type.choices, default=Type.REGULAR)
    location = models.CharField(max_length=256, verbose_name='місце госпіталізації')
    returned = models.DateField(blank=True, null=True, verbose_name='дата виписки')
    details = models.TextField(blank=True, null=True, verbose_name='деталі')
    report_out = models.ForeignKey(Report, on_delete=models.SET_NULL, blank=True, null=True,
                                   verbose_name='рапорт про вибуття', related_name='hospitalization_report_out')
    basis_out = models.CharField(max_length=256, verbose_name='підстава вибуття (епікриз)', null=True, blank=True)
    report_in = models.ForeignKey(Report, on_delete=models.SET_NULL, blank=True, null=True,
                                   verbose_name='рапорт про прибуття', related_name='hospitalization_report_in')
    basis_in = models.CharField(max_length=256, verbose_name='підстава прибуття (епікриз)', null=True, blank=True)
    order_out = models.ForeignKey(Order, verbose_name='наказ про вибуття', on_delete=models.SET_NULL, null=True,
                                  blank=True, related_name='hospitalization_out', limit_choices_to={'order_type': 1})
    order_in = models.ForeignKey(Order, verbose_name='наказ про прибуття', on_delete=models.SET_NULL, null=True,
                                 blank=True, related_name='hospitalization_in', limit_choices_to={'order_type': 1})
    file = models.FileField(upload_to='Hospitalization', blank=True, null=True, verbose_name='файл')
    file2 = models.FileField(upload_to='Hospitalization', blank=True, null=True, verbose_name='файл (2)')

    def clean(self):
        if not self.order_in:  # check opened Hospitalization only
            self.check_missing_and_raise()

            # qs = Hospitalization.objects.filter(serviceman=self.serviceman,
            #                                     order_in__isnull=True).exclude(id=self.id)
            # if len(qs) > 0:
            #     raise ValidationError(f'{self.serviceman.short_name} вже на лікарняному! hospitalization.id={qs.first().id}')

    def __str__(self):
        return f'{self.id}, {self.serviceman.title}, {self.location}' \
               f', госпіталізовано {self.date_from.strftime("%d.%m.%Y") if self.date_from else "??"}' \
               f'{" по " + self.order_in.date.strftime("%d.%m.%Y") if self.order_in else ""}'

    @property
    def status(self):
        if not self.order_out:
            return format_html(f'<span style="color:red">[відсутній наказ]</span>')
        if self.order_out.date > datetime.datetime.today().date():
            return format_html(f'<span style="color:red">[не почався]</span>')
        if self.order_out and self.order_out.date < datetime.datetime.today().date() and\
                not self.order_in:
            return format_html(f'<span style="color:blue">на лікарняному</span>')
        elif self.order_out and self.order_out.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:green">на лікарняному (вибув)</span></b>')
        elif self.order_in and self.order_in.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:magenta">повернувся з лікарняного</span></b>')
        # elif not self.returned:
        #     return format_html(f'<b><span style="color:red">НЕ повернувся з лікарняного</span></b>')
        else:
            return 'закритий'

    status.fget.short_description = 'Статус'

    @property
    def type_rgb(self):
        if self.type == self.Type.INJURY:
            return format_html(f'<b><span style="color:red">{self.get_type_display()}</span></>')
        elif self.type == self.Type.COMMISSION:
            return format_html(f'<b><span style="color:brown">{self.get_type_display()}</span></>')
        else:
            return self.get_type_display()

    type_rgb.fget.short_description = 'Тип'

    @property
    def days(self):
        try:
            date_end = self.returned if self.returned else self.order_in.date if self.order_in else datetime.datetime.today().date()
            return abs((date_end - self.date_from).days) + 1
            # return abs((date_end - self.order_out.date).days) + 1 if self.order_out and date_end else 0
        except Exception as ex:
            print(f'Hospitalization::days, error: {ex}')
            return 0

    days.fget.short_description = 'дні'

    @property
    def verbose_date_from(self):
        return self.date_from.strftime("%d.%m.%Y")

    @property
    def date_from_short(self):
        return f'{self.date_from.strftime("%d.%m.%Y")}'

    @property
    def returned_date_short(self):
        return f'{self.returned.strftime("%d.%m.%Y") if self.returned else self.order_in.date_short if self.order_in else "??.??.????"}'

    @property
    def basis_out_verbose(self):
        return f'{"рапорт "+self.report_out.short_info if self.report_out else ""}' \
               f'{", " if self.report_out and self.basis_out else ""}' \
               f'{self.basis_out if self.basis_out else ""}'

    @property
    def basis_in_verbose(self):
        return f'{"рапорт "+self.report_in.short_info if self.report_in else ""}' \
               f'{", " if self.report_in and self.basis_in else ""}' \
               f'{self.basis_in if self.basis_in else ""}'

    @property
    def order_out_short_name(self):
        return f"{self.order_out.short_name}"

    @property
    def serviceman_staff_full_name(self):
        return self.serviceman.staff_full_name2

    @property
    def order_out_link(self):
        try:
            link = reverse("admin:documents_order_change", args=[self.order_out.id])
        except AttributeError as e:
            return '-'
        else:
            return format_html('<a href="%s">%s</a>' % (link, self.order_out.short_name))

    order_out_link.fget.short_description = 'наказ про вибуття'

    @property
    def order_in_link(self):
        try:
            link = reverse("admin:documents_order_change", args=[self.order_in.id])
        except AttributeError as e:
            return '-'
        else:
            return format_html('<a href="%s">%s</a>' % (link, self.order_in.short_name))

    order_in_link.fget.short_description = 'наказ про прибуття'


class Exemption(MissingBase):
    class Meta:
        verbose_name = "Відсутні: Звільнення від службових обов'язків"
        verbose_name_plural = "Відсутні: Звільнення від службових обов'язків"

    def __str__(self):
        return f'{self.id}, {self.issue_date.strftime("%d.%m.%Y")}, звільнення: {self.serviceman.title}' \
               f', з {self.date_from.strftime("%d.%m.%Y")}' \
               f'{" по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""} на {self.verbose_days_short}'


class MedicalCommission(MissingBase):
    class Meta:
        verbose_name = "Відсутні: Проходження ВЛК"
        verbose_name_plural = "Відсутні: Проходження ВЛК"

    def __str__(self):
        return f'{self.id}, {self.issue_date.strftime("%d.%m.%Y")}, ВЛК: {self.serviceman.title}' \
               f', з {self.date_from.strftime("%d.%m.%Y")}' \
               f'{" по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""} на {self.verbose_days_short}'


class Arrest(MissingBase):
    class Meta:
        verbose_name = "Відсутні: Арешт"
        verbose_name_plural = "Відсутні: Арешт"

    def __str__(self):
        return f'{self.id}, {self.issue_date.strftime("%d.%m.%Y")}, Арешт: {self.serviceman.title}' \
               f', з {self.date_from.strftime("%d.%m.%Y")}' \
               f'{" по " + self.date_to.strftime("%d.%m.%Y") if self.date_to else ""} на {self.verbose_days_short}'

    @property
    def must_return_date(self):
        return self.date_to + datetime.timedelta(days=1) if self.date_to else None

    @property
    def status(self):
        if not self.order_out:
            return format_html(f'<span style="color:red">[відсутній наказ]</span>')
        if self.order_out.date > datetime.datetime.today().date():
            return format_html(f'<span style="color:red">[не почався]</span>')
        if self.order_out and self.order_out.date < datetime.datetime.today().date() \
            and not self.order_in \
            and (not self.must_return_date or self.must_return_date > datetime.datetime.today().date()):
            return format_html(f'<span style="color:blue">під арештом</span>')
        elif self.order_out and self.order_out.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:green">під арештом (вибув)</span></b>')
        elif not self.order_in and self.must_return_date and self.must_return_date==datetime.datetime.today().date() and not self.order_in:
            return format_html(f'<b><span style="color:green">під арештом (має повернутися сьогодні)</span></b>')
        elif self.order_in and self.order_in.date==datetime.datetime.today().date():
            return format_html(f'<b><span style="color:magenta">прибув з під арешту (закритий)</span></b>')
        elif self.must_return_date and self.must_return_date < datetime.datetime.today().date() and not self.order_in:
            return format_html(f'<b><span style="color:red">НЕ прибув з під арешту</span></b>')
        else:
            return 'закритий'

    status.fget.short_description = 'Статус'


class Relation(DocumentBase):
    class Meta:
        verbose_name = 'Відношення'
        verbose_name_plural = 'Відношення'

    date = models.DateField(blank=False, null=False, default=django.utils.timezone.now, verbose_name='дата видачі')
    initiator = models.ForeignKey('personnel.Serviceman', on_delete=models.PROTECT, null=False, blank=False,
                                   verbose_name='ініціатор (відповідальний)')
    recipient = models.CharField(max_length=200, verbose_name='адресат (в/ч або військомат)')
    serviceman_rank = models.ForeignKey('personnel.Rank', on_delete=models.PROTECT, null=False, blank=False,
                                   verbose_name='звання кандидата')
    serviceman_name = models.CharField(max_length=200, blank=False, null=False, verbose_name='ПІБ кандидата')
    serviceman_birthday = models.DateField(blank=True, null=True, verbose_name='дата народження')
    serviceman_tax_id = models.PositiveBigIntegerField(unique=True, verbose_name='ІПН', blank=True, null=True)
    staff = models.ForeignKey('personnel.Staff', on_delete=models.DO_NOTHING, blank=False, null=False,
                              verbose_name='На штатну посаду', limit_choices_to={'serviceman__isnull': True})
    file = models.FileField(upload_to='Relation', verbose_name='файл', blank=True, null=True)

    def __str__(self):
        return f'{self.id}, {self.date.strftime("%d.%m.%Y")}, {self.serviceman_rank} {self.serviceman_name}, {self.recipient}'


class Signout(DocumentBase):
    class Meta:
        verbose_name = 'припис'
        verbose_name_plural = 'приписи'

    issue_date = models.DateField(auto_now_add=True, blank=True, null=True, verbose_name='дата видачі')
    index = models.CharField(max_length=32, blank=True, null=True, verbose_name='індекс')
    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.PROTECT, null=False, blank=False,
                                   verbose_name='військовослужбовець')
    date_out = models.DateField(verbose_name='дата вибуття', null=True)
    date_in = models.DateField(verbose_name='строк прибуття', null=True)
    destination = models.CharField(max_length=256, verbose_name='місце припису', help_text='вибути (куди?)')
    order = models.ForeignKey(Order, verbose_name='наказ', on_delete=models.SET_NULL, null=True, blank=True)
    reason = models.CharField(max_length=256, verbose_name='підстава', blank=True, null=True)
    signout_for = models.CharField(max_length=256, verbose_name='для', blank=True, null=True)

    def __str__(self):
        return f'{self.index}, {self.issue_date.strftime("%d.%m.%Y")}, {self.serviceman.title}'


class Extract(DocumentBase):
    class Meta:
        verbose_name = 'Накази: витяг'
        verbose_name_plural = 'Накази: витяги'

    date = models.DateField(verbose_name='дата', null=True, blank=True, default=django.utils.timezone.now)
    order = models.ForeignKey(Order, verbose_name='наказ', on_delete=models.SET_NULL, null=True, blank=True)
    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.SET_NULL, null=True, blank=True,
                                   verbose_name='військовослужбовець')
    file = models.FileField(upload_to='Extract', verbose_name='файл', blank=True, null=True)

    def __str__(self):
        return f'{self.id}, {self.date.strftime("%d.%m.%Y")}, {self.serviceman.title}'


class Awarding(DocumentBase):
    class Meta:
        verbose_name = 'Нагородження'
        verbose_name_plural = 'Нагородження'
        ordering = ['awarding_id']

    awarding_id = models.PositiveIntegerField(verbose_name='номер', unique=True, blank=False, null=False)
    date = models.DateField(verbose_name='дата', default=django.utils.timezone.now, blank=False, null=False)
    name = models.CharField(verbose_name='назва', max_length=256)
    participants = models.ManyToManyField('personnel.Serviceman', verbose_name='Список о/с на нагородження',
                                          related_name='awarding_participants', blank=True)
    file = models.FileField(upload_to='Awarding', verbose_name='файл подання', blank=True, null=True)
    order = models.ForeignKey(Order, verbose_name='наказ на нагородження', on_delete=models.SET_NULL,
                              blank=True, null=True)
    # type = models.CharField(verbose_name='тип', max_length=2, choices=Status.choices, default=Status.NEW)

    def __str__(self):
        return f'{self.awarding_id}, {self.date.strftime("%d.%m.%Y")}, {self.name}'


class TransferPlan(DocumentBase):
    class RankLevel(models.TextChoices):
        SOLDIER = "SS", "солдати та сержанти"
        OFFICER = "OF", "офіцери"
    class Type(models.TextChoices):
        BRIGADE = "BRI", "Командира 241 окремої бригади"
        REGION = "REG", "Начальника регіонального управління 'Північ'"
        TRO = "TRO", "Командувача Сил територіальної оборони"
        ZSU = "ZSU", "Головнокомандувача Збройних Сил України"
    class Meta:
        verbose_name = 'План переміщення'
        verbose_name_plural = 'Плани переміщення'
        ordering = ['-transfer_id']

    transfer_id = models.PositiveIntegerField(verbose_name='номер', unique=True, blank=False, null=False)
    date = models.DateField(verbose_name='дата', default=django.utils.timezone.now, blank=False, null=False)
    rank_level = models.CharField(verbose_name='склад', max_length=3, choices=RankLevel.choices, default=RankLevel.SOLDIER)
    type = models.CharField(verbose_name='номенклатура призначення', max_length=3, choices=Type.choices, default=Type.BRIGADE)
    serviceman = models.ForeignKey('personnel.Serviceman', on_delete=models.PROTECT, blank=False, null=False,
                                   verbose_name='військовослужбовець')
    staff = models.ForeignKey('personnel.Staff', on_delete=models.SET_NULL, blank=True, null=True,
                              verbose_name='На штатну посаду (якщо переміщення у межах в/ч)'
                              # , limit_choices_to={'serviceman__isnull': True}
                              )
    position_name = models.TextField(verbose_name='Найменування посади, що підлягає комплектуванню (якщо переміщення до іншої в/ч)',
                                     blank=True, null=True)
    file_plan = models.FileField(upload_to='Transfer', verbose_name='файл (план переміщення)', blank=True, null=True)
    file_request = models.FileField(upload_to='Transfer', verbose_name='файл (клопотання)', blank=True, null=True)

    def __str__(self):
        return f'{self.transfer_id}, {self.date.strftime("%d.%m.%Y")}, {self.serviceman.title}'

    @property
    def target_staff_name(self):
        if self.staff:
            return f'{self.staff.full_name_rs.capitalize()}' \
                   f' 204 окремого батальйону територіальної оборони 241 окремої бригади територіальної оборони' \
                   f' регіонального управління Сил територіальної оборони «Північ» Сил територіальної оборони' \
                   f' Збройних Сил України, штат №05/195-01,' \
                   f' ШПК - "{self.staff.position.position_category.name.lower()}", ВОС - ' \
                   f'{self.staff.position.milspec}, посадовий оклад - {self.staff.position.tariff.salary} грн, т.р. - ' \
                   f'{self.staff.position.tariff.tariff_no}'
        else:
            return self.position_name
    target_staff_name.fget.short_description = 'На посаду'

    @property
    def target_staff_short_name(self):
        if self.staff:
            link = reverse("admin:personnel_staff_change", args=[self.staff.id])
            return format_html('<a href="%s">%s</a>' % (link, self.staff.short_name))
        else:
            return self.position_name
    target_staff_short_name.fget.short_description = 'На посаду'

    @property
    def serviceman_staff_date(self):
        return get_short_date(self.serviceman.staff.staff_order.date)\
            if self.serviceman.staff and self.serviceman.staff.staff_order else '??.??.????'
    serviceman_staff_date.fget.short_description = 'Дата з якої на посаді'

    @property
    def serviceman_rank_date(self):
        if self.serviceman.rank_order:
            return self.serviceman.rank_order.date.strftime("%d.%m.%Y")
        elif self.serviceman.rank_order_ext_date:
            return self.serviceman.rank_order_ext_date.strftime("%d.%m.%Y")
        else:
            return '??.??.????'
    serviceman_rank_date.fget.short_description = 'Дата присвоєння звання'

    @property
    def serviceman_full_name(self):
        return f'{self.serviceman.rank.name.capitalize()}' \
               f' ({self.serviceman_rank_date})' \
               f' {self.serviceman.full_name_upper}, ' \
               f' {self.serviceman.tax_id}, {self.serviceman.staff_full_name_rs}' \
               f' 204 окремого батальйону територіальної оборони 241 окремої бригади територіальної оборони' \
               f' регіонального управління Сил територіальної оборони «Північ» Сил територіальної оборони' \
               f' Збройних Сил України'
    serviceman_full_name.fget.short_description = 'Військовослужбовець'

    @property
    def reason(self):
        if self.staff and self.staff.position.tariff.tariff_no < self.serviceman.staff_serviceman.position.tariff.tariff_no:
            return 'Подається до призначення на нижчу посаду за ініціативою військовослужбовця'
        elif self.staff and self.staff.position.tariff.tariff_no > self.serviceman.staff_serviceman.position.tariff.tariff_no:
            return 'Подається до призначення на вищу посаду в порядку просування по службі'
        return 'Організаційні заходи'


class Sample(DocumentBase):
    class Type(models.TextChoices):
        REPORT = "REP", "РАПОРТ"
        ORDER = "ORD", "НАКАЗ"
        OTHER = "OTH", "ІНШЕ"
    class Meta:
        verbose_name = 'зразок документу'
        verbose_name_plural = 'зразки документів'

    date = models.DateField(verbose_name='дата', null=True, blank=True, default=django.utils.timezone.now)
    type = models.CharField(max_length=3, verbose_name='Тип', choices=Type.choices, default=Type.REPORT)
    name = models.CharField(max_length=1000, verbose_name='Назва документу', null=True, blank=True)
    file1 = models.FileField(upload_to='Sample', verbose_name='файл (1)', blank=True, null=True)
    file2 = models.FileField(upload_to='Sample', verbose_name='файл (2)', blank=True, null=True)

    def __str__(self):
        return f'{self.id}, {self.date.strftime("%d.%m.%Y")}, {self.get_type_display()}, {self.name}'


