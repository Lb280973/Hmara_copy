import logging
import os
from datetime import datetime, timedelta

from admin_auto_filters.filters import AutocompleteFilter
from django.contrib import admin, messages
from django.db.models import Max, IntegerField
from django.db.models.functions import Cast
from django.urls import reverse
from django.utils.html import format_html
from import_export import resources
from import_export.admin import (
    ExportActionModelAdmin,
    ImportExportModelAdmin,
    ImportMixin,
)
from import_export.fields import Field
from import_export.widgets import DateWidget, ForeignKeyWidget

from personnel.models import *  # Serviceman, Unit, Acceptance

from utils import filter_name
from .mixins import PreservedFormDataMixin, DocFileMixin
from .models import Order, OrderType, Report, ReportStatus, Trip, Vacation, Hospitalization, Signout, \
    Extract, Awarding, ReportType, Relation, TransferPlan, Addressee, Sample, TripProlongation, Exemption, \
    MedicalCommission, Arrest
from django.conf import settings

logger = logging.getLogger(__name__)


class DocumentBaseAdmin(admin.ModelAdmin):
    list_per_page = 20
    list_max_show_all = 1000

    def save_model(self, request, obj, form, change):
        try:
            obj.user = request.user
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class NoEditBaseInline(admin.StackedInline):
    extra = 0

    def has_add_permission(self, request, obj):
        return False

    def has_change_permission(self, request, obj):
        return False

    def has_delete_permission(self, request, obj):
        return False


class ActionBaseInline(NoEditBaseInline):
    ordering = ['-action_date']

    def id_link(self, obj):
        try:
            link = reverse(f'admin:personnel_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id))

    id_link.allow_tags = True
    id_link.short_description = 'Номер'


class AcceptanceInline(ActionBaseInline):
    model = Acceptance
    fk_name = 'order_daily'
    verbose_name = 'Прийом на посаду'
    verbose_name_plural = 'Прийом на посаду'
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']

class AcceptanceRsInline(AcceptanceInline):
    fk_name = 'order_rs'
    verbose_name_plural = 'Прийом на посаду (РС)'


class MovementInline(ActionBaseInline):
    model = Movement
    fk_name = 'order_daily'
    verbose_name = 'переміщення'
    verbose_name_plural = 'переміщення'
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']

class MovementRsInline(MovementInline):
    fk_name = 'order_rs'
    verbose_name_plural = 'переміщення (РС)'


class TakeOutInline(ActionBaseInline):
    model = TakeOut
    fk_name = 'order_daily'
    verbose_name = 'Поза штат'
    verbose_name_plural = 'Поза штат'
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']

class TakeOutRsInline(TakeOutInline):
    fk_name = 'order_rs'
    verbose_name_plural = 'Поза штат (РС)'


class DismissalInline(ActionBaseInline):
    model = Dismissal
    fk_name = 'order_daily'
    verbose_name = 'Виключення зі списків'
    verbose_name_plural = 'Виключення зі списків'
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'reason', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'reason', 'status', 'user']

class DismissalRsInline(DismissalInline):
    fk_name = 'order_rs'
    verbose_name_plural = 'Виключення зі списків (РС)'


class TemporaryActingInline(ActionBaseInline):
    model = TemporaryActing
    fk_name = 'order_daily'
    verbose_name = 'Допуск до ТВО'
    verbose_name_plural = 'Допуск до ТВО'
    fields = [('id_link', 'daily_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'status', 'user']


class PayoutInline(ActionBaseInline):
    model = Payout
    fk_name = 'order_daily'
    verbose_name = 'Виплати'
    verbose_name_plural = 'Виплати'
    ordering = ['-action_date']
    fields = [('id_link', 'daily_order_link', 'type', 'amount', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'type', 'amount', 'status', 'user']


class AssignRankInline(ActionBaseInline):
    model = AssignRank
    fk_name = 'order_daily'
    verbose_name = 'Присвоєння звання'
    verbose_name_plural = 'Присвоєння звання'
    fields = [('id_link', 'daily_order_link', 'rs_order_link', 'status', 'user')]
    readonly_fields = ['id_link', 'daily_order_link', 'rs_order_link', 'status', 'user']


class MissingBaseInline(NoEditBaseInline):
    ordering = ['-date_from']

    def index_link(self, obj):
        try:
            link = reverse(f'admin:documents_{self.model.__name__.lower()}_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.id if self.model in [Hospitalization, Arrest] else obj.index))

    index_link.allow_tags = True
    index_link.short_description = 'Індекс/номер'


class VacationOutInline(MissingBaseInline):
    model = Vacation
    fk_name = 'order_out'
    verbose_name = 'Відпустка (вибуття)'
    verbose_name_plural = 'Відпустки (вибуття)'
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']


class VacationInInline(MissingBaseInline):
    model = Vacation
    fk_name = 'order_in'
    verbose_name = 'Відпустка (прибуття)'
    verbose_name_plural = 'Відпустки (прибуття)'
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']


class TripOutInline(MissingBaseInline):
    model = Trip
    fk_name = 'order_out'
    verbose_name = 'Відрядження (вибуття)'
    verbose_name_plural = 'Відрядження (вибуття)'
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']


class TripInInline(MissingBaseInline):
    model = Trip
    fk_name = 'order_in'
    verbose_name = 'Відрядження (прибуття)'
    verbose_name_plural = 'Відрядження (прибуття)'
    fields = [('index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']


class TripProlongationBaseInline(NoEditBaseInline):
    ordering = ['-date']
    model = TripProlongation
    verbose_name = 'Відрядження (продовження)'
    verbose_name_plural = 'Відрядження (продовження)'
    fields = [('date_link', 'date_to', 'days', 'user')]
    readonly_fields = ['date_link', 'date_to', 'days', 'user']

    def date_link(self, obj):
        try:
            link = reverse(f'admin:documents_tripprolongation_change', args=[obj.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.date.strftime("%d.%m.%Y")))

    date_link.allow_tags = True
    date_link.short_description = 'Дата'


class TripProlongationInline(TripProlongationBaseInline):
    pass


class TripProlongationOrderInline(TripProlongationBaseInline):
    fk_name = 'order_daily'

class TripProlongationOrderRsInline(TripProlongationBaseInline):
    fk_name = 'order_rs'
    verbose_name_plural = 'Відрядження (продовження) (РС)'


class HospitalizationOutline(MissingBaseInline):
    model = Hospitalization
    fk_name = 'order_out'
    verbose_name = 'Лікарняний (вибуття)'
    verbose_name_plural = 'Лікарняні (вибуття)'
    fields = [('index_link', 'date_from', 'returned', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'returned', 'order_out_link', 'order_in_link', 'user']


class HospitalizationInline(MissingBaseInline):
    model = Hospitalization
    fk_name = 'order_in'
    verbose_name = 'Лікарняний (прибуття)'
    verbose_name_plural = 'Лікарняні (прибуття)'
    fields = [('index_link', 'date_from', 'returned', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'returned', 'order_out_link', 'order_in_link', 'user']


class ServicemanAtDisposalOrAbsentBaseInline(ActionBaseInline):  #admin.StackedInline):
    extra = 0
    ordering = ['-date_from']
    fields = [('id_link', 'date_from', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['id_link', 'date_from', 'order_out_link', 'order_in_link', 'user']


class DisposalOutInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAtDisposal
    fk_name = 'order_out'
    verbose_name = 'У розпорядженні (початок)'
    verbose_name_plural = 'У розпорядженні (початок)'


class DisposalInInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAtDisposal
    fk_name = 'order_in'
    verbose_name = 'У розпорядженні (закінчення)'
    verbose_name_plural = 'У розпорядженні (закінчення)'


class AttachedOutInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAttached
    fk_name = 'order_out'
    verbose_name = 'Прикомандирований (початок)'
    verbose_name_plural = 'Прикомандирований (початок)'


class AttachedInInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanAttached
    fk_name = 'order_in'
    verbose_name = 'Прикомандирований (закінчення)'
    verbose_name_plural = 'Прикомандирований (закінчення)'


class IllegallyAbsentOutInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanIllegallyAbsent
    fk_name = 'order_out'
    verbose_name = 'СЗЧ (початок)'
    verbose_name_plural = 'СЗЧ (початок)'


class IllegallyAbsentInInline(ServicemanAtDisposalOrAbsentBaseInline):
    model = ServicemanIllegallyAbsent
    fk_name = 'order_in'
    verbose_name = 'СЗЧ (закінчення)'
    verbose_name_plural = 'СЗЧ (закінчення)'


class LossesOutInline(ActionBaseInline):
    model = Losses
    fk_name = 'order_daily'
    verbose_name = 'Втрати'
    verbose_name_plural = 'Втрати (початок)'
    fields = [('id_link', 'action_date', 'type', 'serviceman', 'daily_order_link', 'user')]
    readonly_fields = ['id_link', 'action_date', 'type', 'serviceman', 'daily_order_link', 'user']

class LossesInInline(ActionBaseInline):
    model = Losses
    fk_name = 'order_daily_in'
    verbose_name = 'Втрати'
    verbose_name_plural = 'Втрати (закінчення)'
    fields = [('id_link', 'action_date', 'type', 'serviceman', 'daily_order_in_link', 'user')]
    readonly_fields = ['id_link', 'action_date', 'type', 'serviceman', 'daily_order_in_link', 'user']


class ArrestOutInline(MissingBaseInline):
    model = Arrest
    fk_name = 'order_out'
    verbose_name = 'Арешт (початок)'
    verbose_name_plural = 'Арешт (початок)'
    fields = [('index_link', 'date_from', 'order_out_link', 'order_in_link', 'user')]
    readonly_fields = ['index_link', 'date_from', 'order_out_link', 'order_in_link', 'user']

class ArrestInInline(ArrestOutInline):
    fk_name = 'order_in'
    verbose_name = 'Арешт (закінчення)'
    verbose_name_plural = 'Арешт (закінчення)'


#
# Admin Classes
#
class AddresseeAdmin(DocumentBaseAdmin):
    list_display = ['id', 'type', 'name', 'address', 'contacts', 'link', 'comment', 'user']
    search_fields = ['name', 'address', 'contacts', 'comment']
    list_filter = ['type']
    ordering = ['name']
    fields = ['type', 'name', 'address', 'contacts', 'link', 'comment', 'user']
    readonly_fields = ['user']
    # actions = ['create_daily_order', 'create_rs_order']


class OrderResource(resources.ModelResource):
    class Meta:
        model = Order


class OrderAdmin(DocumentBaseAdmin, DocFileMixin, ExportActionModelAdmin):
    inlines = [AcceptanceInline, AcceptanceRsInline,
               MovementInline, MovementRsInline,
               TakeOutInline, TakeOutRsInline,
               DismissalInline, DismissalRsInline,
               TemporaryActingInline,
               AssignRankInline, PayoutInline,
               TripInInline, HospitalizationInline, VacationInInline,
               TripOutInline,
               TripProlongationOrderInline, TripProlongationOrderRsInline,
               HospitalizationOutline, VacationOutInline,
               DisposalOutInline, DisposalInInline,
               AttachedOutInline, AttachedInInline,
               IllegallyAbsentOutInline, IllegallyAbsentInInline,
               ArrestOutInline, ArrestInInline,
               LossesOutInline, LossesInInline,
               ]
    list_display = ['order_id', 'date', 'status_rgb', 'name_verbose', #'order_type', 'name', 'by',
                    'file_link', 'file_word_link', 'file_report_link',
                    'serviceman_count', 'comment', 'assigned_to', 'user']
    filter_horizontal = ['mentioned']
    search_fields = ['^order_id', 'name', 'comment']  # 'by',
    list_filter = [('status', filter_name('статусом')),
                   ('order_type', filter_name('типом')),
                   'by',
                   ('assigned_to', filter_name('виконавцем')),
                   ('date', filter_name('датою наказу'))]
    ordering = ['-date', '-order_id']
    fields = ['order_id', 'name', 'name_verbose', 'by', 'date', 'order_type', 'mentioned',
              'file', 'file_word', 'file_report',
              'comment', 'status', 'assigned_to', 'user']
    readonly_fields = ['user', 'name_verbose']
    actions = ['create_daily_order', 'create_rs_order']
    list_per_page = 20

    @staticmethod
    def get_default_input_id():
        try:
            last_daily_order = Order.objects.filter(order_type__id=1).order_by('-date').first()
            return "" if last_daily_order is None else str(int(last_daily_order.order_id) + 1)
        except Exception as ex:
            return ""

    def get_form(self, request, obj=None, **kwargs):
        form = super(OrderAdmin, self).get_form(request, obj, **kwargs)
        try:
            form.base_fields['order_id'].initial = self.get_default_input_id()
            form.base_fields['date'].initial = datetime.today()
            form.base_fields['by'].initial = f'командира військової частини {get_globals().military_unit_name_public}'
        except KeyError as e:
            logger.error(e)
        return form

    def get_inline_instances(self, request, obj=None):
        # print('>>> get_inline_instances')
        inline_instances = super().get_inline_instances(request, obj)
        if obj is None:
            return []  #inline_instances

        if obj.order_type.order_type_id == 1:
            return [inline for inline in inline_instances
                    if type(inline).__name__ not in ['AcceptanceRsInline',
                                                     'MovementRsInline',
                                                     'TakeOutRsInline',
                                                     'DismissalRsInline',
                                                     'TripProlongationOrderRsInline']]
        elif obj.order_type.order_type_id == 3:
            return [inline for inline in inline_instances
                    if type(inline).__name__ not in ['AcceptanceInline',
                                                     'MovementInline',
                                                     'TakeOutInline',
                                                     'DismissalInline',
                                                     'TemporaryActingInline',
                                                     'TripProlongationOrderInline']]
        else:
            return []

    def serviceman_count(self, obj):
        return obj.mentioned.count()

    serviceman_count.short_description = 'Кількість в/с'


class OrderTypeAdmin(admin.ModelAdmin):
    list_display = ['order_type_id', 'name', 'dsk']
    ordering = ['order_type_id']
    list_per_page = 20


class ServicemanFilter(AutocompleteFilter):
    title = 'військовослужбовцем'
    field_name = 'serviceman'


class OrderRsFilter(AutocompleteFilter):
    title = 'РС наказом'
    field_name = 'order_rs'
    parameter_name = 'order_rs'


class OrderDailyFilter(AutocompleteFilter):
    title = 'добовим наказом'
    field_name = 'order_daily'
    parameter_name = 'order_daily'


class OrderDailyOutFilter(AutocompleteFilter):
    title = 'добовим наказом (початок)'
    field_name = 'order_out'
    parameter_name = 'order_out'


class OrderDailyInFilter(AutocompleteFilter):
    title = 'добовим наказом (закінчення)'
    field_name = 'order_in'
    parameter_name = 'order_in'


class TripStatusFilter(admin.SimpleListFilter):
    title = 'статусом відрядження'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return (
            ('progress', 'У відрядженні'),
            ('out', 'У відрядженні (вибув)'),
            ('must_return', 'У відрядженні (має повернутися сьогодні)'),
            ('in', 'прибув з відрядження'),
            ('not_in', 'НЕ прибув з відрядження'),
            # ('no_order', '[відсутній наказ про вибуття]'),
            # ('not_started', '[не почалося]'),
            ('closed', 'закрите'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'progress':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   # returned__isnull=True,
                                   # must_return_date__isnull=False,
                                   # must_return_date__gte=datetime.today().date()
                                   )
        elif self.value() == 'out':
            return queryset.filter(order_out__date=datetime.today().date())
        elif self.value() == 'must_return':
            return queryset.filter(order_in__isnull=True,
                                   must_return_date=datetime.today().date())
        elif self.value() == 'in':
            return queryset.filter(order_in__date=datetime.today().date())
        elif self.value() == 'not_in':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   must_return_date__isnull=False,
                                   must_return_date__lt=datetime.today().date(),
                                   returned__isnull=True)
        # elif self.value() == 'no_order':
        #     return queryset.filter(order_out__date__isnull=True)
        # elif self.value() == 'not_started':
        #     return queryset.filter(order_out__date__gt=datetime.today().date())
        elif self.value() == 'closed':
            return queryset.filter(order_in__isnull=False,
                                   order_in__date__lte=datetime.today().date())
        else:
            return queryset.all()


class VacationStatusFilter(admin.SimpleListFilter):
    title = 'статусом відпустки'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return (
            ('progress', 'У відпустці'),
            ('out', 'У відпустці (вибув)'),
            ('must_return', 'У відпустці (має повернутися сьогодні)'),
            ('in', 'прибув з відпустки'),
            ('not_in', 'НЕ прибув з відпустки'),
            ('no_order', '[відсутній наказ про вибуття]'),
            ('not_started', '[не почалася]'),
            ('closed', 'закрита'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'progress':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   # returned__isnull=True,
                                   # must_return_date__isnull=False,
                                   # must_return_date__gte=datetime.today().date()
                                   )
        elif self.value() == 'out':
            return queryset.filter(order_out__date=datetime.today().date())
        elif self.value() == 'must_return':
            return queryset.filter(order_in__isnull=True,
                                   must_return_date=datetime.today().date())
        elif self.value() == 'in':
            return queryset.filter(order_in__date=datetime.today().date())
        elif self.value() == 'not_in':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   must_return_date__isnull=False,
                                   must_return_date__lt=datetime.today().date(),
                                   returned__isnull=True)
        elif self.value() == 'no_order':
            return queryset.filter(order_out__isnull=True)
        elif self.value() == 'not_started':
            return queryset.filter(order_out__date__gt=datetime.today().date())
        elif self.value() == 'closed':
            return queryset.filter(order_in__isnull=False,
                                   order_in__date__lte=datetime.today().date())
        else:
            return queryset.all()


class HospitalizationStatusFilter(admin.SimpleListFilter):
    title = 'статусом лікарняного'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return (
            ('progress', 'на лікарняному'),
            ('out', 'на лікарняному (вибув)'),
            ('in', 'повернувся з лікарняного'),
            # ('not_in', 'НЕ повернувся з лікарняного'),
            ('no_order', '[відсутній наказ про вибуття]'),
            ('not_started', '[не почався]'),
            ('closed', 'закритий'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'progress':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   # returned__isnull=True,
                                   )
        elif self.value() == 'out':
            return queryset.filter(order_out__date=datetime.today().date())
        elif self.value() == 'in':
            return queryset.filter(order_in__date=datetime.today().date())
        # elif self.value() == 'not_in':
        #     return queryset.filter(order_out__date__isnull=False,
        #                            order_out__date__lte=datetime.today().date(),
        #                            order_in__date__isnull=True,
        #                            returned__isnull=True)
        elif self.value() == 'no_order':
            return queryset.filter(order_out__date__isnull=True)
        elif self.value() == 'not_started':
            return queryset.filter(order_out__date__gt=datetime.today().date())
        elif self.value() == 'closed':
            return queryset.filter(order_in__date__isnull=False,
                                   order_in__date__lte=datetime.today().date())
        else:
            return queryset.all()


class ArrestStatusFilter(admin.SimpleListFilter):
    title = 'статусом арешту'
    parameter_name = 'status'

    def lookups(self, request, model_admin):
        return (
            ('progress', 'під арештом'),
            ('out', 'під арештом (вибув)'),
            ('must_return', 'під арештом (має повернутися сьогодні)'),
            ('in', 'прибув з під арешту'),
            ('not_in', 'НЕ прибув з під арешту'),
            ('no_order', '[відсутній наказ про вибуття]'),
            ('not_started', '[не почався]'),
            ('closed', 'закритий'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'progress':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   )
        elif self.value() == 'out':
            return queryset.filter(order_out__date=datetime.today().date())
        elif self.value() == 'must_return':
            return queryset.filter(order_in__isnull=True,
                                   date_to=datetime.today().date() - timedelta(days=1))
        elif self.value() == 'in':
            return queryset.filter(order_in__date=datetime.today().date())
        elif self.value() == 'not_in':
            return queryset.filter(order_out__isnull=False,
                                   order_out__date__lte=datetime.today().date(),
                                   order_in__isnull=True,
                                   date_to__isnull=False,
                                   date_to__lt=datetime.today().date())
        elif self.value() == 'no_order':
            return queryset.filter(order_out__isnull=True)
        elif self.value() == 'not_started':
            return queryset.filter(order_out__date__gt=datetime.today().date())
        elif self.value() == 'closed':
            return queryset.filter(order_in__isnull=False,
                                   order_in__date__lte=datetime.today().date())
        else:
            return queryset.all()


class ServicemanRankLevelFilter(admin.SimpleListFilter):
    title = 'РАНГОМ В/С'
    parameter_name = 'rank_level'

    def lookups(self, request, model_admin):
        return (
            ('soldier_sergeant', 'Солдати+Сержанти'),
            ('officer', 'Офіцери'),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == 'soldier_sergeant':
            return queryset.filter(serviceman__rank__rank_id__lte=12)
        elif value == 'officer':
            return queryset.filter(serviceman__rank__rank_id__gte=13)
        else:
            return queryset


class MissingDurationFilter(admin.SimpleListFilter):
    title = 'тривалістю'
    parameter_name = 'duration'

    def lookups(self, request, model_admin):
        return (
            ('lt_14', 'Less than 14 days'),  # Менше 14 днів
            ('14_30', '14 to 30 days'),  # Від 14 до 30 днів
            ('gt_30', 'More than 30 days'),  # Більше 30 днів
        )

    def queryset(self, request, queryset):
        if self.value() == 'lt_14':
            end_date = date.today()
            start_date = end_date - timedelta(days=14)
            return queryset.filter(order_out__date__gte=start_date, order_in__date__lte=end_date) | queryset.filter(order_out__date__gte=start_date, order_in__isnull=True)
        elif self.value() == '14_30':
            end_date = date.today()
            start_date = end_date - timedelta(days=30)
            return queryset.filter(order_out__date__gte=start_date, order_in__date__lte=end_date, order_in__date__gte=start_date + timedelta(days=14)) | queryset.filter(order_out__date__gte=start_date, order_in__isnull=True)
        elif self.value() == 'gt_30':
            end_date = date.today()
            start_date = end_date - timedelta(days=30)
            return queryset.filter(order_out__date__gte=start_date, order_in__date__lte=end_date, order_in__date__lt=start_date + timedelta(days=14)) | queryset.filter(order_out__date__gte=start_date, order_in__isnull=True)
        else:
            return queryset.all()


class StaffUnitCombatGroupFilter(admin.SimpleListFilter):   # duplicated in personnel admin module (refactor it!!!)
    title = 'підрозділом БЧС'
    parameter_name = 'unit_combat_group'

    def lookups(self, request, model_admin):
        units = UnitCombatGroup.objects.order_by('group_id')
        return [(c.id, c.name) for c in units]

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(serviceman__staff_serviceman__unit__combat_group__id__exact=self.value())
        else:
            return queryset.all()


# class MissingUnitFilter(admin.SimpleListFilter):
#     title = 'підрозділом'
#     parameter_name = 'unit_id'
#
#     def lookups(self, request, model_admin):
#         units = Unit.objects.order_by('unit_id')
#         return [(c.id, c.name) for c in units]
#
#     def queryset(self, request, queryset):
#         if self.value():
#             return queryset.filter(serviceman__staff_serviceman__unit__exact=self.value())
#         else:
#             return queryset.all()


class ReportFilesPresentFilter(admin.SimpleListFilter):
    title = 'наявністю файлів'
    parameter_name = 'files'

    def lookups(self, request, model_admin):
        return (
            ('Yes', 'ТАК'),
            ('No', 'НІ'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'Yes':
            return queryset.filter(Q(file__isnull=False) & ~Q(file=''))
        if self.value() == 'No':
            return queryset.filter(Q(file__isnull=True) | Q(file__exact=''))
        else:
            return queryset.all()


class ReportResource(resources.ModelResource):
    class Meta:
        model = Report


class ReportAdmin(PreservedFormDataMixin, DocumentBaseAdmin, ExportActionModelAdmin):
    list_display = ['input_id', 'date', 'serviceman_link', 'content', 'type', 'status', 'file', 'assigned_to', 'user']
    autocomplete_fields = ['serviceman', 'status']
    list_filter = [('status', filter_name('статусом')),
                   ('assigned_to', filter_name('виконавцем')),
                   ReportFilesPresentFilter,
                   'type', # not used
                   ServicemanFilter,
                   StaffUnitCombatGroupFilter,
                   ('date', filter_name('датою'))]
    search_fields = ['=input_id', 'serviceman__last_name', 'content', 'comment']
    fields = ['input_id', 'date', 'serviceman', 'content', 'type', 'status', 'assigned_to',
              'file', 'file2', 'comment', 'user']
    readonly_fields = ['user']
    ordering = ['-input_id']
    actions = ['get_free_numbers']

    def serviceman_link(self, obj):
        if obj.serviceman:
            link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))
        else:
            return '-'

    serviceman_link.allow_tags = True
    serviceman_link.admin_order_field = 'serviceman__last_name'
    serviceman_link.short_description = 'подавач'

    @staticmethod
    def get_default_input_id():
        max_found = Report.objects.aggregate(Max('input_id'))["input_id__max"]
        if max_found is None:
            return 1
        return max_found + 1

    def get_form(self, request, obj=None, **kwargs):
        form = super(ReportAdmin, self).get_form(request, obj, **kwargs)
        form.base_fields['input_id'].initial = self.get_default_input_id()
        form.base_fields['date'].initial = datetime.today()
        form.base_fields['status'].initial = ReportStatus.objects.get(name='зареєстровано')
        return form


class ReportTypeAdmin(admin.ModelAdmin):
    list_display = ['report_type_id', 'name']
    ordering = ['report_type_id']
    list_per_page = 20


class ReportStatusAdmin(admin.ModelAdmin):
    search_fields = ['name']


class MissingBaseAdmin(DocumentBaseAdmin, ExportActionModelAdmin):
    change_links = ['serviceman', 'order_out', 'order_in']
    autocomplete_fields = ['serviceman', 'order_out', 'order_in']
    readonly_fields = ['user']

    def serviceman_link(self, obj):
        if obj.serviceman:
            link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))
        else:
            return '-'

    serviceman_link.allow_tags = True
    serviceman_link.admin_order_field = 'serviceman__last_name'
    serviceman_link.short_description = 'військовослужбовець'

    def serviceman_staff(self, obj):
        return obj.serviceman.staff_short_name if obj.serviceman else '-'
        #return obj.serviceman.staff_link
    # serviceman_staff.admin_order_field = 'serviceman__staff__index'
    serviceman_staff.short_description = 'Штат'

    # def serviceman_unit(self, obj):
    #     return obj.serviceman.unit
    #
    # serviceman_unit.short_description = 'підрозділ'
    #
    # def position_verbose(self, obj):
    #     return obj.serviceman.position_verbose
    #
    # position_verbose.short_description = 'повна посада'

    # def order_out_link(self, obj):
    #     try:
    #         link = reverse("admin:documents_order_change", args=[obj.order_out.id])
    #     except AttributeError as e:
    #         pass
    #     else:
    #         return format_html('<a href="%s">%s</a>' % (link, obj.order_out.short_name))
    #
    # order_out_link.allow_tags = True
    # order_out_link.short_description = 'наказ про вибуття'
    #
    # def order_in_link(self, obj):
    #     try:
    #         link = reverse("admin:documents_order_change", args=[obj.order_in.id])
    #     except AttributeError as e:
    #         pass
    #     else:
    #         return format_html('<a href="%s">%s</a>' % (link, obj.order_in.short_name))
    #
    # order_in_link.allow_tags = True
    # order_in_link.short_description = 'наказ про прибуття'


class MissingResource(resources.ModelResource):
    serviceman_rank = Field(column_name='Звання', attribute='serviceman__rank',
                            widget=ForeignKeyWidget(Rank, field='name'))
    serviceman_full_name = Field(column_name='ПІБ')
    serviceman_staff_full_name = Field(column_name='Посада', attribute='serviceman_staff_full_name')
    issue_date = Field(column_name='Дата реєстрації', attribute='issue_date',
                       widget=DateWidget(format='%d.%m.%Y'))
    date_from = Field(column_name='Дата початку', attribute='date_from',
                      widget=DateWidget(format='%d.%m.%Y'))
    date_to = Field(column_name='Дата закінчення', attribute='date_to',
                    widget=DateWidget(format='%d.%m.%Y'))
    must_return_date = Field(column_name='Має повернутись', attribute='must_return_date',
                             widget=DateWidget(format='%d.%m.%Y'))
    days = Field(column_name='Дні', attribute='days')

    def dehydrate_serviceman_full_name(self, obj):
        return obj.serviceman.full_name_upper


class TripResource(MissingResource):
    index = Field(column_name='Індекс', attribute='index')
    returned = Field(column_name='Фактична дата повернення', attribute='returned',
                     widget=DateWidget(format='%d.%m.%Y'))
    by = Field(column_name='Транспортний засіб', attribute='by')
    weapon = Field(column_name='Зброя', attribute='weapon')
    destination = Field(column_name='Куди', attribute='destination')
    goal = Field(column_name='Мета', attribute='goal')
    reason = Field(column_name='Підстава', attribute='reason')
    order_out_short_name = Field(column_name='Наказ на вибуття', attribute='order_out_short_name')

    class Meta:
        model = Trip
        # fields = ['index', 'serviceman_rank', 'serviceman_full_name',
        #           'date_from', 'date_to',
        #           ]
        export_order = ['id', 'index', 'issue_date', 'serviceman_rank', 'serviceman_full_name', 'serviceman_staff_full_name',
                        'days', 'date_from', 'date_to', 'must_return_date', 'returned', 'by', 'weapon',
                        'destination', 'goal', 'order_out_short_name'
                        ]


@admin.register(Trip)
class TripAdmin(PreservedFormDataMixin, DocFileMixin, MissingBaseAdmin, ExportActionModelAdmin):  #, ImportExportModelAdmin):
    list_display = ['index', 'serviceman_link', 'serviceman_staff', 'status', 'serviceman_count', 'days_real_verbose',
                    'date_from', 'date_to_real_rgb', 'destination_rgb',
                    # 'must_return_date', 'returned',
                    'order_out_link', 'order_in', 'user']
                    # 'destination', 'goal', 'reason', 'weapon', 'by', 'user']
    list_editable = ['order_in']
    #'date_to', 'must_return_date', 'date_from', 'destination', 'goal', 'reason', 'weapon', 'by',
    ordering = ['-date_from', '-index']
    fields = ['index', 'serviceman',
              ('date_from', 'date_to'),
              ('must_return_date', 'returned'),
              'days_real_verbose', 'status',
              ('destination', 'abroad'),
              'goal', 'reason',
              ('by', 'weapon'),
              ('report', 'order_out'),
              ('report_in', 'order_in'),
              'accompanies',
              'comment', 'file', 'file2', 'user']
    search_fields = ['serviceman__last_name', 'index', 'destination', 'goal', 'comment']
    list_filter = [
        TripStatusFilter,
        OrderDailyOutFilter,
        OrderDailyInFilter,
        ('abroad', filter_name('кордон')),
        ServicemanRankLevelFilter,
        StaffUnitCombatGroupFilter,
        # MissingUnitFilter,
        ('must_return_date', filter_name('датою очікуваного повернення')),
        ('returned', filter_name('датою фактичного повернення')),
        ('order_in__date', filter_name('датою наказу про прибуття')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('date_from', filter_name('датою вибуття')),
        ('date_to', filter_name('датою прибуття')),
        ('user', filter_name('користувачем')),
    ]
    inlines = [TripProlongationInline]
    actions = ['create_doc_file']
    readonly_fields = ['must_return_date', 'status', 'days_real_verbose', 'serviceman_count', 'user']
    autocomplete_fields = ['report', 'order_out', 'report_in', 'order_in', 'serviceman']
    filter_horizontal = ['accompanies']
    resource_classes = [TripResource]
    document_verbose_name = 'квиток відрядження'
    template = 'trip_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Trip/{datetime.now().strftime("%d_%m")}')

    def save_model(self, request, obj, form, change):
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        import datetime
        try:
            # check_serviceman_trip_and_raise(obj.serviceman)
            obj.must_return_date = obj.date_to + datetime.timedelta(days=1) if obj.date_to else None
            if not obj.returned and obj.order_in:
                obj.returned = obj.order_in.date
            super().save_model(request, obj, form, change)
        except Exception as e:
            messages.error(request, f'Помилка! {e}')  # how to handle error correctly?
            logger.error(e)


@admin.register(TripProlongation)
class TripProlongationAdmin(DocumentBaseAdmin):
    list_display = ['date', 'trip_link', 'date_to', 'days', 'order_rs_link', 'order_daily_link',
                    'comment', 'user']
    autocomplete_fields = ['trip', 'report', 'order_rs', 'order_daily']
    readonly_fields = ['date_to_orig', 'days', 'user']
    search_fields = ['trip__serviceman__last_name', 'trip__index', 'comment']
    fields = ['date', 'trip', 'date_to_orig', 'date_to', 'days', 'report',
              ('order_rs', 'cause'),
              'order_daily', 'comment', 'user']
    list_filter = [
        OrderRsFilter,
        OrderDailyFilter,
        ('date', filter_name('датою')),
        ('user', filter_name('користувачем')),
    ]

    def save_model(self, request, obj, form, change):
        import datetime
        logger.info(f'[{request.user.username}] saving {self.model._meta.model_name} #{obj.id}')
        try:
            # +++ check active trip
            if obj.trip.date_to != obj.date_to:
                obj.date_to_orig = obj.trip.date_to
                obj.trip.date_to = obj.date_to
                obj.trip.must_return_date = obj.date_to + datetime.timedelta(days=1) if obj.date_to else None
            obj.trip.save()
            super().save_model(request, obj, form, change)
        except Exception as e:
            messages.error(request, f'Помилка! {e}')  # how to handle error correctly?
            logger.error(e)

    def trip_link(self, obj):
        try:
            link = reverse("admin:documents_trip_change", args=[obj.trip.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.trip))

    trip_link.allow_tags = True
    trip_link.short_description = 'Відрядження'

    def order_rs_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.order_rs.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.order_rs.short_name))

    order_rs_link.allow_tags = True
    order_rs_link.short_description = 'РС наказ'

    def order_daily_link(self, obj):
        try:
            link = reverse("admin:documents_order_change", args=[obj.order_daily.id])
        except AttributeError as e:
            pass
        else:
            return format_html('<a href="%s">%s</a>' % (link, obj.order_daily.short_name))

    order_daily_link.allow_tags = True
    order_daily_link.short_description = 'Добовий наказ'


class VacationResource(MissingResource):
    index = Field(column_name='Індекс', attribute='index')
    vtype_name = Field(column_name='Тип')
    returned = Field(column_name='Фактична дата повернення', attribute='returned',
                     widget=DateWidget(format='%d.%m.%Y'))
    location = Field(column_name='Буде перебувати', attribute='location')
    certificate = Field(column_name='Довідка', attribute='certificate')
    order_out_short_name = Field(column_name='Наказ на вибуття', attribute='order_out_short_name')

    def dehydrate_vtype_name(self, obj):
        return obj.get_vtype_display()

    class Meta:
        model = Vacation
        export_order = ['id', 'index', 'issue_date', 'vtype_name',
                        'serviceman_rank', 'serviceman_full_name', 'serviceman_staff_full_name',
                        'days', 'date_from', 'date_to', 'must_return_date', 'returned', 'location', 'certificate',
                        'order_out_short_name'
                        ]


@admin.register(Vacation)
class VacationAdmin(PreservedFormDataMixin, DocFileMixin, MissingBaseAdmin, ExportActionModelAdmin):
    list_display = ['index', 'serviceman_link', 'serviceman_staff', 'vtype', 'status', 'days_real_verbose',
                    'date_from', 'date_to_real_rgb', 'location_rgb', #'certificate',
                    # 'returned',
                    # 'order_out_link',
                    'order_out_link', 'order_in', 'user']
    list_editable = ['order_in']
    ordering = ['-date_from', '-index']
    fields = ['index', 'serviceman', ('date_from', 'date_to'), ('must_return_date', 'returned'), 'days_real_verbose',
              ('vtype', 'location', 'abroad'),
              'status', 'certificate',
              ('report', 'order_out'),
              ('report_in', 'order_in'),
              'comment', 'file', 'file2', 'user']
    search_fields = ['serviceman__last_name', 'index', 'comment']
    list_filter = [
        ('vtype', filter_name('Типом')),
        VacationStatusFilter,
        OrderDailyOutFilter,
        OrderDailyInFilter,
        ('abroad', filter_name('кордон')),
        ServicemanRankLevelFilter,
        StaffUnitCombatGroupFilter,
        # MissingUnitFilter,
        ('must_return_date', filter_name('датою очікуваного повернення')),
        ('returned', filter_name('датою фактичного повернення')),
        ('order_in__date', filter_name('датою наказу про прибуття')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('date_from', filter_name('датою вибуття')),
        ('date_to', filter_name('датою прибуття')),
        ('user', filter_name('користувачем')),
    ]
    readonly_fields = ['must_return_date', 'status', 'days_real_verbose', 'user']
    actions = ['create_doc_file']
    autocomplete_fields = ['report', 'order_out', 'report_in', 'order_in', 'serviceman']
    template = 'vacation_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Vacation/{datetime.now().strftime("%d_%m")}')
    resource_classes = [VacationResource]

    def save_model(self, request, obj, form, change):
        import datetime
        try:
            # 04.04.2023 free date_from. agreed with Bohdan
            # if obj.order_out:
            #     obj.date_from = obj.order_out.date
            obj.must_return_date = obj.date_to + datetime.timedelta(days=1) if obj.date_to else None
            if not obj.returned and obj.order_in:
                obj.returned = obj.order_in.date
            super().save_model(request, obj, form, change)
        except KeyError as e:
            messages.error(request, 'Помилка!')  # how to handle error correctly?
            logger.error(e)


class HospitalizationResource(MissingResource):
    type_name = Field(column_name='Тип')
    returned = Field(column_name='Фактична дата повернення', attribute='returned',
                     widget=DateWidget(format='%d.%m.%Y'))
    location = Field(column_name='Буде перебувати', attribute='location')
    details = Field(column_name='Деталі', attribute='details')
    order_out_short_name = Field(column_name='Наказ на вибуття', attribute='order_out_short_name')
    serviceman_staff_full_name = Field(column_name='Посада', attribute='serviceman_staff_full_name')

    def dehydrate_vtype_name(self, obj):
        return obj.get_type_display()

    class Meta:
        model = Hospitalization
        export_order = ['id', 'issue_date', 'type_name',
                        'serviceman_rank', 'serviceman_full_name', 'serviceman_staff_full_name',
                        'date_from', 'date_to', 'must_return_date', 'returned', 'location', 'details',
                        'order_out_short_name'
                        ]


class HospitalizationAdmin(MissingBaseAdmin):
    list_display = ['id', 'serviceman_link', 'serviceman_staff', 'type_rgb', 'status', 'days', 'date_from', 'location',
                    'order_out_link', 'order_in_link', 'returned', 'user']
    ordering = ['-id']
    fields = [('serviceman', 'serviceman_staff'),
              'type', 'status', 'days',
              ('date_from', 'location'),
              'returned', 'details',
              ('report_out', 'basis_out'),
              'order_out',
              ('report_in', 'basis_in'),
              'order_in',
              'comment', 'file', 'file2', 'user']
    readonly_fields = ['serviceman_staff', 'status', 'days', 'user']
    autocomplete_fields = ['serviceman', 'report_out', 'report_in', 'order_out', 'order_in']
    search_fields = ['serviceman__last_name', 'location', 'comment']
    list_filter = [
        ('type', filter_name('Типом')),
        HospitalizationStatusFilter,
        OrderDailyOutFilter,
        OrderDailyInFilter,
        MissingDurationFilter,
        ServicemanRankLevelFilter,
        StaffUnitCombatGroupFilter,
        # MissingUnitFilter,
        ('date_from', filter_name('датою госпіталізації')),
        ('returned', filter_name('датою фактичного повернення')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('order_in__date', filter_name('датою наказу про прибуття')),
        ('user', filter_name('користувачем')),
    ]
    resource_classes = [HospitalizationResource]


class ExemptionAdmin(MissingBaseAdmin):
    list_display = ['id', 'issue_date', 'serviceman_link', 'serviceman_staff', #'status',
                    'days', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']
    ordering = ['-id']
    fields = ['serviceman',
              'serviceman_staff', #'status',
              ('date_from', 'date_to'),
              'days',
              'report', 'order_out', 'report_in', 'order_in',
              'comment', 'user']
    readonly_fields = ['serviceman_staff', 'days', 'user']
    autocomplete_fields = ['serviceman', 'report', 'order_out', 'report_in', 'order_in']
    search_fields = ['serviceman__last_name', 'comment']
    list_filter = [
        OrderDailyOutFilter,
        OrderDailyInFilter,
        StaffUnitCombatGroupFilter,
        ('date_from', filter_name('датою початку')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('user', filter_name('користувачем')),
    ]
    # resource_classes = [ExemptionResource]


class MedicalCommissionAdmin(MissingBaseAdmin):
    list_display = ['id', 'issue_date', 'serviceman_link', 'serviceman_staff', #'status',
                    'days', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']
    ordering = ['-id']
    fields = ['serviceman',
              'serviceman_staff', #'status',
              ('date_from', 'date_to'),
              'days',
              'report', 'order_out', 'report_in', 'order_in',
              'comment', 'user']
    readonly_fields = ['serviceman_staff', 'days', 'user']
    autocomplete_fields = ['serviceman', 'report', 'order_out', 'report_in', 'order_in']
    search_fields = ['serviceman__last_name', 'comment']
    list_filter = [
        OrderDailyOutFilter,
        OrderDailyInFilter,
        StaffUnitCombatGroupFilter,
        ('date_from', filter_name('датою початку')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('user', filter_name('користувачем')),
    ]
    # resource_classes = [ExemptionResource]


class ArrestAdmin(MissingBaseAdmin):
    list_display = ['id', 'issue_date', 'serviceman_link', 'serviceman_staff', 'status',
                    'days', 'date_from', 'date_to', 'order_out_link', 'order_in_link', 'user']
    ordering = ['-id']
    fields = ['serviceman',
              'serviceman_staff', #'status',
              ('date_from', 'date_to'),
              'days',
              'report', 'order_out', 'report_in', 'order_in',
              'comment', 'user']
    readonly_fields = ['serviceman_staff', 'days', 'user']
    autocomplete_fields = ['serviceman', 'report', 'order_out', 'report_in', 'order_in']
    search_fields = ['serviceman__last_name', 'comment']
    list_filter = [
        ArrestStatusFilter,
        OrderDailyOutFilter,
        OrderDailyInFilter,
        StaffUnitCombatGroupFilter,
        ('date_from', filter_name('датою початку')),
        ('order_out__date', filter_name('датою наказу про вибуття')),
        ('user', filter_name('користувачем')),
    ]
    # resource_classes = [ExemptionResource]


class RelationAdmin(DocumentBaseAdmin, DocFileMixin):
    list_display = ['id', 'date', 'initiator_link', 'recipient', 'serviceman_rank', 'serviceman_name',
                    'target_staff_link', 'file', 'user']
    ordering = ['-id']
    fields = ['date', 'initiator', 'recipient', 'serviceman_rank', 'serviceman_name', 'serviceman_birthday',
              'serviceman_tax_id', 'staff', 'comment', 'file', 'user']
    readonly_fields = ['user']
    autocomplete_fields = ['initiator', 'serviceman_rank', 'staff']
    search_fields = ['initiator__last_name', 'serviceman_name', 'serviceman_tax_id']
    template = 'relation_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Relation/{datetime.now().strftime("%d_%m")}')
    actions = ['create_doc_file2']
    list_per_page = 20

    def initiator_link(self, obj):
        if obj.initiator:
            link = reverse("admin:personnel_serviceman_change", args=[obj.initiator.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.initiator))
        else:
            return '-'

    initiator_link.allow_tags = True
    initiator_link.admin_order_field = 'initiator__last_name'
    initiator_link.short_description = 'ініціатор (відповідальний)'

    def target_staff_link(self, obj):
        if obj.staff:
            link = reverse("admin:personnel_staff_change", args=[obj.staff.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.staff.short_name))
        else:
            return obj.position_name

    target_staff_link.admin_order_field = 'staff__staff_id'
    target_staff_link.short_description = 'На штатну посаду'

class SignoutAdmin(PreservedFormDataMixin, DocFileMixin, DocumentBaseAdmin):
    list_display = ['index', 'issue_date', 'serviceman', 'serviceman_staff', 'destination', 'date_out', 'date_in', 'user']
    autocomplete_fields = ['serviceman', 'order']
    fields = ['index', 'issue_date', 'serviceman', 'serviceman_staff', 'date_out', 'date_in', 'destination', 'order', 'reason',
              'signout_for', 'comment', 'user']
    readonly_fields = ['issue_date', 'serviceman_staff', 'user']
    document_verbose_name = 'припис'
    template = 'signout_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Signout/{datetime.now().strftime("%d_%m")}')
    actions = ['create_doc_file']
    list_per_page = 20

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['signout_for'].initial = 'для подальшого проходження служби'
        return form

    def serviceman_staff(self, obj):
        return obj.serviceman.staff_short_name

    serviceman_staff.short_description = 'Штат'


class ExtractAdmin(PreservedFormDataMixin, DocFileMixin, DocumentBaseAdmin):
    list_display = ['id', 'date', 'order', 'serviceman', 'file', 'user']
    autocomplete_fields = ['order', 'serviceman']
    fields = ['date', 'order', 'serviceman', 'serviceman_staff', 'file', 'comment', 'user']
    readonly_fields = ['serviceman_staff', 'user']
    template = 'extract_template.docx'
    save_to = os.path.join(settings.DOCUMENTS_DIR, f'Extract/{datetime.now().strftime("%d_%m")}')
    actions = ['create_doc_file']
    list_per_page = 20

    def serviceman_staff(self, obj):
        return obj.serviceman.staff_short_name

    serviceman_staff.short_description = 'Штат'


class AwardingAdmin(PreservedFormDataMixin, DocFileMixin, DocumentBaseAdmin):
    list_display = ['awarding_id', 'date', 'name', 'participants_count', 'order', 'user']
    filter_horizontal = ['participants']
    autocomplete_fields = ['order']
    fields = ['awarding_id', 'date', 'name', 'participants', 'comment', 'file', 'order', 'user']
    readonly_fields = ['user']
    actions = ['create_reward4wounding']

    def participants_count(self, obj):
        return obj.participants.count()

    participants_count.short_description = 'Кількість в/с'


class TransferPlanResource(resources.ModelResource):
    class Meta:
        model = TransferPlan


class TransferPlanAdmin(PreservedFormDataMixin, DocFileMixin, DocumentBaseAdmin, ExportActionModelAdmin):
    list_display = ['transfer_id', 'date', 'type', 'rank_level',
                    'serviceman_link',
                    'serviceman_staff', #'serviceman_staff_date',
                    'target_staff_short_name',
                    'comment', 'file_request', 'file_plan', 'user']
    autocomplete_fields = ['serviceman', 'staff']
    fields = ['transfer_id', 'date', 'rank_level', 'type', 'serviceman', 'staff', 'position_name', 'comment',
              'file_request', 'file_plan', 'user']
    readonly_fields = ['user']
    search_fields = ['serviceman__last_name']
    list_filter = [('rank_level', filter_name('Складом')),
                   ('type', filter_name('Номенклатурою')),
                   ('date', filter_name('Датою')),
                   ('user', filter_name('Користувачем'))]
    actions = ['create_transfer_plan']

    def serviceman_staff(self, obj):
        return obj.serviceman.staff_link

    serviceman_staff.short_description = 'З посади'

    def serviceman_link(self, obj):
        if obj.serviceman:
            link = reverse("admin:personnel_serviceman_change", args=[obj.serviceman.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.serviceman))
        else:
            return '-'

    serviceman_link.allow_tags = True
    serviceman_link.admin_order_field = 'serviceman__last_name'
    serviceman_link.short_description = 'військовослужбовець'

    def target_staff_link(self, obj):
        if obj.staff:
            link = reverse("admin:personnel_staff_change", args=[obj.staff.id])
            return format_html('<a href="%s">%s</a>' % (link, obj.staff.short_name))
        else:
            return obj.position_name

    target_staff_link.admin_order_field = 'staff__staff_id'
    target_staff_link.short_description = 'На штатну посаду'

    @staticmethod
    def get_default_input_id():
        max_found = TransferPlan.objects.aggregate(Max('transfer_id'))["transfer_id__max"]
        if max_found is None:
            return 1
        return max_found + 1

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields['transfer_id'].initial = self.get_default_input_id()
        return form


class SampleAdmin(PreservedFormDataMixin, DocFileMixin, DocumentBaseAdmin):
    list_display = ['id', 'date', 'type', 'name', 'file1', 'file2', 'comment', 'user']
    search_fields = ['name', 'comment']
    fields = ['id', 'date', 'type', 'name', 'file1', 'file2', 'comment', 'user']
    readonly_fields = ['id', 'user']
    list_filter = ['type']


admin.site.register(Addressee, AddresseeAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(OrderType, OrderTypeAdmin)
admin.site.register(Report, ReportAdmin)
admin.site.register(ReportType, ReportTypeAdmin)
admin.site.register(ReportStatus, ReportStatusAdmin)
admin.site.register(Hospitalization, HospitalizationAdmin)
admin.site.register(Exemption, ExemptionAdmin)
admin.site.register(MedicalCommission, MedicalCommissionAdmin)
admin.site.register(Arrest, ArrestAdmin)
admin.site.register(Relation, RelationAdmin)
admin.site.register(Signout, SignoutAdmin)
admin.site.register(Extract, ExtractAdmin)
admin.site.register(Awarding, AwardingAdmin)
admin.site.register(TransferPlan, TransferPlanAdmin)
admin.site.register(Sample, SampleAdmin)

admin.site.site_title = 'Хмара'
admin.site.site_header = 'Хмара 1.0.7'
