from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from .views import status_view, create_daily_report

urlpatterns = [
    path('status', status_view),
    path('report', create_daily_report),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
