#!/bin/bash

set -e

check_database_ready() {
  cat <<EOF | python manage.py shell
import socket
import time
res = False
for count in range(10):
  sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  print("Attempt " + str(count + 1) + " to connect to database")
  result = sock.connect_ex(("${DB_HOST}",${DB_PORT}))
  if result == 0:
     res = True
     print("Port ${DB_HOST}:${DB_PORT} is open")
     break
  else:
     print("Port ${DB_HOST}:${DB_PORT} is not open. Waiting for 10 seconds...")
     time.sleep(10)
  sock.close()
if not res:
  print("DB is not ready. Exiting")
  exit(1)
EOF
}

create_superuser () {
    local username="$1"
    local email="$2"
    local password="$3"
    cat <<EOF | python manage.py shell
from django.contrib.auth import get_user_model

User = get_user_model()

if not User.objects.filter(username="$username").exists():
    User.objects.create_superuser("$username", "$email", "$password")
else:
    print('User "{}" exists already, not created'.format("$username"))
EOF
}

# check if database is up and retry if need
check_database_ready

# run migrations at first
python manage.py migrate --noinput

# attempt to create superuser
if [[ -n "${DJANGO_SUPERUSER_USERNAME}" ]] && [[ -n "${DJANGO_SUPERUSER_PASSWORD}" ]]; then
  echo "create superuser '${DJANGO_SUPERUSER_USERNAME}' with password '${DJANGO_SUPERUSER_PASSWORD}'"
  create_superuser ${DJANGO_SUPERUSER_USERNAME} ${DJANGO_SUPERUSER_EMAIL} ${DJANGO_SUPERUSER_PASSWORD}
fi

# run web server
# binded port is 8000, spawn 5 workers. Adjust as needed
# timout 300 seconds

gunicorn conf.wsgi --bind 0.0.0.0:8000 -w 5 -t 300
